# Nila Social — README

## Quick start (Windows)

1. Install **Python 3.10+** and tick **Add to PATH**.
2. Double-click **`INSTALL.bat`** (one-click setup).
3. Open **http://127.0.0.1:5000**

**Demo login:** `ananya@kerala.app` / `password123`

Or use the control panel: **`NilaSocial.bat`**

| File | Purpose |
|------|---------|
| `INSTALL.bat` | One-click install + seed media + DB + start |
| `NilaSocial.bat` | Menu: start / install / reset DB / repair / seed media |
| `START.bat` | Start server only |
| `RESET_DATABASE.bat` | Wipe DB + reseed |
| `REPAIR.bat` | Clean junk + reinstall packages |
| `INSTALL.txt` | Full local/offline guide (why feeds need installer) |

## College documentation

Full project report with **ER diagram**, **use cases**, **architecture**, and **database catalog**:

- [docs/PROJECT_REPORT.md](docs/PROJECT_REPORT.md)
- [docs/DATABASE.md](docs/DATABASE.md)
- [docs/MINI_PROJECT_SLIDES.md](docs/MINI_PROJECT_SLIDES.md)
- [docs/Instagram_Pro_Mini_Project.pptx](docs/Instagram_Pro_Mini_Project.pptx)
- [docs/PROJECT_PHASES.md](docs/PROJECT_PHASES.md) — **incremental review order**
- Diagrams: [docs/images/](docs/images/)

## Phase 1 / Progress demo (~30%) — for sir’s review

Show **Social Lite** when you need a smaller build that still uses real code from the completed project:

- Folder: [`social_lite/`](social_lite/)
- Guide: [`docs/PROGRESS_DEMO.md`](docs/PROGRESS_DEMO.md)
- Installer: `social_lite/INSTALL.bat` → `START.bat`
- Demo: `demo@social.lite` / `password123` → http://127.0.0.1:5001
- Includes: auth, feed, posts, likes, and Local AI APIs (`/api/ai/caption`, hashtags, bilingual, …)

This repo root (**Nila Social**, port 5000) is the **final 100%** project.

## Offline

After the first install, the app runs **without internet**:
- Local SQLite DB (`instance/instagram_clone.db`)
- Bootstrap & icons under `app/static/vendor/`
- AI uses rule-based fallbacks (or cached Hugging Face models if previously downloaded)

To prepare an offline package: `InstagramPro.bat` → **Download wheels**.

## Features

Feed, stories, reels, DMs, private accounts, block/mute/restrict, AI comment moderation,
Local AI Studio, Kerala place intel, festival modes, journey maps, and more.

## Develop

```bash
python tools/installer.py install
python tools/installer.py start
```

## Repository

- GitHub: https://github.com/anandhx/instagram-pro
- Branches: `main`, `docs/college-project`

## Optional: Real Instagram (read-only)

You can view **your** Instagram timeline/posts inside the app using `instagrapi`.
This is **view-only** (no likes, comments, follows, or uploads).

1. `pip install -r requirements-instagram.txt`
2. Copy `.env.example` → `.env`
3. Set:

```env
INSTAGRAM_LIVE=1
INSTAGRAM_USERNAME=your_ig_username
INSTAGRAM_PASSWORD=your_ig_password
```

4. Restart the app → sidebar shows **Live Instagram**

Keep `INSTAGRAM_LIVE=0` for normal local demo (recommended).
Unofficial Instagram APIs can break or risk account limits — educational use only.
