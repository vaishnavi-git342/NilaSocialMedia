@echo off
title Nila Social - One Click Installer
cd /d "%~dp0"
echo.
echo  Nila Social - One-Click Install
echo  --------------------------------
echo  Installs Python packages (incl. AI), copies seed photos,
echo  and creates the local database so the feed is not empty.
echo.
python tools\installer.py install
if errorlevel 1 (
  echo.
  echo Install finished with errors. Try Repair from NilaSocial.bat
  pause
  exit /b 1
)
echo.
echo Starting app...
python tools\installer.py start
pause
