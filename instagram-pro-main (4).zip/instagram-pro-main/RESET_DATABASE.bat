@echo off
title Instagram Pro - Reset Database
cd /d "%~dp0"
echo This will DELETE all data and restore Kerala demo accounts.
python tools\installer.py reset-db
pause
