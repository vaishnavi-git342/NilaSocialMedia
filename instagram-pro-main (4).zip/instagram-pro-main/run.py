"""Entry point for the Instagram Pro application."""
import os

# Transformers otherwise imports TensorFlow, which crashes this Windows process.
os.environ["USE_TF"] = "0"
os.environ["TRANSFORMERS_NO_TF"] = "1"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

from app import create_app

app = create_app()

if __name__ == "__main__":
    debug = os.environ.get("FLASK_DEBUG", "1") == "1"
    host = os.environ.get("FLASK_HOST", "127.0.0.1")
    port = int(os.environ.get("FLASK_PORT", "5000"))
    print(f"Instagram Pro -> http://{host}:{port}")
    print("Sign up to create your account.")
    app.run(debug=debug, host=host, port=port, use_reloader=False)
