"""Reset database and load Kerala-themed seed data."""
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

# Prefer the installer path (supports --yes)
if __name__ == "__main__":
    from tools.installer import init_database
    yes = "--yes" in sys.argv or "-y" in sys.argv
    if not yes:
        print("This will DELETE all data and restore Kerala demo accounts.")
        if input("Type YES to reset: ").strip() != "YES":
            print("Cancelled.")
            raise SystemExit(0)
    raise SystemExit(init_database(force_reset=True))
