"""Seed the database with Kerala-themed users, posts, stories, and reels."""
import re
from datetime import datetime, timedelta
from app.extensions import db
from app.models.user import User
from app.models.profile import Profile
from app.models.post import Post, PostImage
from app.models.story import Story
from app.models.reel import Reel
from app.models.follow import Follow
from app.models.mood import Mood, PostMood
from app.models.hashtag import Hashtag, PostHashtag
from app.models.comment import Comment
from app.models.like import Like
from app.models.message import Conversation, Message


# Kerala-themed demo accounts (password for all: password123)
# Media paths are local under app/static/uploads (populated by tools/refresh_seed_media.py)
SAMPLE_USERS = [
    {
        "username": "ananya_kochi",
        "email": "ananya@kerala.app",
        "password": "password123",
        "full_name": "Ananya Nair",
        "bio": "Kochi nights & Malabar mornings | Food & culture from God's Own Country",
        "website": "https://keralatourism.org",
        "profile_photo": "uploads/profiles/seed_profile_ananya.png",
    },
    {
        "username": "arjun_alleppey",
        "email": "arjun@kerala.app",
        "password": "password123",
        "full_name": "Arjun Menon",
        "bio": "Houseboat days on the backwaters | Alappuzha forever",
        "website": "",
        "profile_photo": "uploads/profiles/seed_profile_arjun.png",
    },
    {
        "username": "meera_munnar",
        "email": "meera@kerala.app",
        "password": "password123",
        "full_name": "Meera Krishnan",
        "bio": "Tea gardens, mist & Western Ghats trails | Munnar",
        "website": "",
        "profile_photo": "uploads/profiles/seed_profile_meera.png",
    },
    {
        "username": "rahul_tvm",
        "email": "rahul@kerala.app",
        "password": "password123",
        "full_name": "Rahul Pillai",
        "bio": "Thiruvananthapuram stories | Temples, beaches & tech",
        "website": "",
        "profile_photo": "uploads/profiles/seed_profile_rahul.png",
    },
    {
        "username": "priya_wayanad",
        "email": "priya@kerala.app",
        "password": "password123",
        "full_name": "Priya Thomas",
        "bio": "Wayanad wild | Waterfalls, wildlife & monsoon magic",
        "website": "",
        "profile_photo": "uploads/profiles/seed_profile_priya.png",
    },
    {
        "username": "vishnu_calicut",
        "email": "vishnu@kerala.app",
        "password": "password123",
        "full_name": "Vishnu Das",
        "bio": "Malabar flavours from Kozhikode | Biryani & beach sunsets",
        "website": "",
        "profile_photo": "uploads/profiles/seed_profile_vishnu.png",
    },
    {
        "username": "lekha_thrissur",
        "email": "lekha@kerala.app",
        "password": "password123",
        "full_name": "Lekha Suresh",
        "bio": "Thrissur Pooram spirit | Culture, elephants & festivals",
        "website": "",
        "profile_photo": "uploads/profiles/seed_profile_lekha.png",
    },
    {
        "username": "nithin_varkala",
        "email": "nithin@kerala.app",
        "password": "password123",
        "full_name": "Nithin Jose",
        "bio": "Cliff views & Arabian Sea | Varkala cliff diaries",
        "website": "",
        "profile_photo": "uploads/profiles/seed_profile_nithin.png",
    },
]

SAMPLE_POSTS = [
    {
        "user": "ananya_kochi",
        "caption": "fort evenings hit different #kochi #fortkochi #kerala",
        "location": "Fort Kochi, Kerala",
        "mood": "relaxed",
        "image": "uploads/posts/seed_post_kochi.png",
    },
    {
        "user": "arjun_alleppey",
        "caption": "drifting, on purpose #alleppey #backwaters #kerala",
        "location": "Alappuzha, Kerala",
        "mood": "relaxed",
        "image": "uploads/posts/seed_post_backwaters.png",
    },
    {
        "user": "meera_munnar",
        "caption": "green on green on green #munnar #teagarden #kerala",
        "location": "Munnar, Kerala",
        "mood": "inspired",
        "image": "uploads/posts/seed_post_munnar.png",
    },
    {
        "user": "rahul_tvm",
        "caption": "worth every bite #trivandrum #foodie #dosa",
        "location": "Thiruvananthapuram, Kerala",
        "mood": "happy",
        "image": "uploads/posts/seed_post_dosa.png",
    },
    {
        "user": "priya_wayanad",
        "caption": "rain mood unlocked #wayanad #monsoon #kerala",
        "location": "Wayanad, Kerala",
        "mood": "adventurous",
        "image": "uploads/posts/seed_post_waterfall.png",
    },
    {
        "user": "vishnu_calicut",
        "caption": "flavor first, captions second #calicut #malabar #foodie",
        "location": "Kozhikode, Kerala",
        "mood": "happy",
        "image": "uploads/posts/seed_post_biryani.png",
    },
    {
        "user": "lekha_thrissur",
        "caption": "colour, sound, and heart #thrissur #pooram #kerala",
        "location": "Thrissur, Kerala",
        "mood": "energetic",
        "image": "uploads/posts/seed_post_pooram.png",
    },
    {
        "user": "nithin_varkala",
        "caption": "golden hour did the work #varkala #beach #kerala",
        "location": "Varkala, Kerala",
        "mood": "romantic",
        "image": "uploads/posts/seed_post_varkala.png",
    },
    {
        "user": "ananya_kochi",
        "caption": "comfort on a plate #onam #sadya #keralafood",
        "location": "Ernakulam, Kerala",
        "mood": "happy",
        "image": "uploads/posts/seed_post_sadya.png",
    },
    {
        "user": "arjun_alleppey",
        "caption": "petrichor and pause #monsoon #chai #kerala",
        "location": "Alappuzha Backwaters",
        "mood": "relaxed",
        "image": "uploads/posts/seed_post_chai.png",
    },
    {
        "user": "meera_munnar",
        "caption": "higher up, quieter mind #munnar #travel #kerala",
        "location": "Munnar Hills, Kerala",
        "mood": "inspired",
        "image": "uploads/posts/seed_post_munnar.png",
    },
    {
        "user": "priya_wayanad",
        "caption": "this pace feels right #camping #wayanad #adventure",
        "location": "Wayanad, Kerala",
        "mood": "adventurous",
        "image": "uploads/posts/seed_post_waterfall.png",
    },
    {
        "user": "rahul_tvm",
        "caption": "salt air and slower thoughts #kovalam #beach #kerala",
        "location": "Kovalam, Kerala",
        "mood": "happy",
        "image": "uploads/posts/seed_post_varkala.png",
    },
    {
        "user": "vishnu_calicut",
        "caption": "city light, soft edges #kozhikode #streetfood #kerala",
        "location": "SM Street, Kozhikode",
        "mood": "energetic",
        "image": "uploads/posts/seed_post_biryani.png",
    },
    {
        "user": "nithin_varkala",
        "caption": "soft focus, loud feeling #varkala #wellness #kerala",
        "location": "Varkala Cliff, Kerala",
        "mood": "relaxed",
        "image": "uploads/posts/seed_post_backwaters.png",
    },
]

SAMPLE_REELS = [
    {
        "user": "arjun_alleppey",
        "caption": "slow boat, soft sky #backwaters #kerala #reels",
        "video": "uploads/reels/seed_reel_houseboat.png",
        "thumbnail": "uploads/reels/seed_reel_houseboat.png",
        "audio": "Kerala Rain Ambience",
        "mood": "relaxed",
    },
    {
        "user": "meera_munnar",
        "caption": "mist over everything that matters #munnar #kerala",
        "video": "uploads/reels/seed_reel_tea.png",
        "thumbnail": "uploads/reels/seed_reel_tea.png",
        "audio": "Mountain Breeze",
        "mood": "inspired",
    },
    {
        "user": "nithin_varkala",
        "caption": "somewhere between waves and quiet #varkala #beach",
        "video": "uploads/reels/seed_reel_beach.png",
        "thumbnail": "uploads/reels/seed_reel_beach.png",
        "audio": "Arabian Sea Waves",
        "mood": "romantic",
    },
    {
        "user": "lekha_thrissur",
        "caption": "living for this energy #thrissur #pooram",
        "video": "uploads/reels/seed_post_pooram.png",
        "thumbnail": "uploads/reels/seed_post_pooram.png",
        "audio": "Chenda Melam Vibes",
        "mood": "energetic",
    },
    {
        "user": "ananya_kochi",
        "caption": "flavor first, captions second #kochi #foodie",
        "video": "uploads/reels/seed_post_dosa.png",
        "thumbnail": "uploads/reels/seed_post_dosa.png",
        "audio": "Malabar Beats",
        "mood": "happy",
    },
]

SAMPLE_STORIES = [
    {"user": "ananya_kochi", "caption": "morning light", "image": "uploads/stories/seed_post_kochi.png"},
    {"user": "arjun_alleppey", "caption": "soft breeze", "image": "uploads/stories/seed_post_backwaters.png"},
    {"user": "meera_munnar", "caption": "tea mist", "image": "uploads/stories/seed_post_munnar.png"},
    {"user": "nithin_varkala", "caption": "cliff light", "image": "uploads/stories/seed_post_varkala.png"},
    {"user": "priya_wayanad", "caption": "trail notes", "image": "uploads/stories/seed_post_waterfall.png"},
    {"user": "vishnu_calicut", "caption": "lunch run", "image": "uploads/stories/seed_post_biryani.png"},
]

SAMPLE_COMMENTS = [
    "Sundari alle! Absolute Kerala vibes",
    "Miss this place already",
    "God's Own Country indeed",
    "Taking notes for my next trip",
    "This is stunning!",
    "Onam energy detected",
]

MOODS = [
    {"name": "happy", "emoji": "😊", "description": "Feeling joyful and positive", "color": "#FFD700"},
    {"name": "sad", "emoji": "😢", "description": "Feeling melancholic", "color": "#6495ED"},
    {"name": "energetic", "emoji": "⚡", "description": "Full of energy and motivation", "color": "#FF4500"},
    {"name": "relaxed", "emoji": "😌", "description": "Calm and peaceful", "color": "#90EE90"},
    {"name": "inspired", "emoji": "✨", "description": "Feeling creative and inspired", "color": "#9370DB"},
    {"name": "adventurous", "emoji": "🏔️", "description": "Ready for adventure", "color": "#20B2AA"},
    {"name": "romantic", "emoji": "❤️", "description": "In a romantic mood", "color": "#FF69B4"},
    {"name": "nostalgic", "emoji": "📷", "description": "Feeling nostalgic", "color": "#DAA520"},
]

SEED_MARKER_USERNAME = "ananya_kochi"


def remove_demo_accounts() -> int:
    """Delete bundled Kerala demo users so a fresh clone starts empty."""
    from app.utils.helpers import delete_user_account

    names = [u["username"] for u in SAMPLE_USERS]
    users = User.query.filter(User.username.in_(names)).all()
    if not users:
        return 0
    for user in users:
        delete_user_account(user)
    db.session.commit()
    return len(users)


def run_seed(force: bool = False):
    """Seed Kerala-themed sample data. Skips if already seeded unless force=True."""
    if not force and User.query.filter_by(username=SEED_MARKER_USERNAME).first():
        print("Database already seeded with Kerala data. Skipping.")
        return

    # Avoid UNIQUE crashes when marker user was deleted but other sample users remain
    if not force:
        sample_emails = [u["email"] for u in SAMPLE_USERS]
        if User.query.filter(User.email.in_(sample_emails)).first():
            print("Partial Kerala seed detected. Skipping to avoid duplicates.")
            return

    print("Seeding Kerala-themed database...")

    mood_map = {}
    for m in MOODS:
        existing = Mood.query.filter_by(name=m["name"]).first()
        if existing:
            mood_map[m["name"]] = existing
            continue
        mood = Mood(name=m["name"], emoji=m["emoji"], description=m["description"], color=m["color"])
        db.session.add(mood)
        db.session.flush()
        mood_map[m["name"]] = mood
    db.session.commit()

    user_map = {}
    for u in SAMPLE_USERS:
        user = User(username=u["username"], email=u["email"])
        user.set_password(u["password"])
        user.email_verified = True
        db.session.add(user)
        db.session.flush()
        profile = Profile(
            user_id=user.id,
            full_name=u["full_name"],
            bio=u["bio"],
            website=u["website"] or None,
            profile_photo=u["profile_photo"],
        )
        db.session.add(profile)
        user_map[u["username"]] = user
    db.session.commit()

    user_map["ananya_kochi"].is_admin = True
    user_map["ananya_kochi"].is_super_admin = True
    db.session.commit()

    try:
        from app.services.feature_flags import ensure_feature_flags
        ensure_feature_flags()
    except Exception:
        pass

    usernames = list(user_map.keys())
    for i, u1 in enumerate(usernames):
        for j, u2 in enumerate(usernames):
            if i != j:
                db.session.add(Follow(follower_id=user_map[u1].id, followed_id=user_map[u2].id, accepted=True))
    db.session.commit()

    posts_created = []
    for idx, p in enumerate(SAMPLE_POSTS):
        user = user_map[p["user"]]
        post = Post(
            user_id=user.id,
            caption=p["caption"],
            location=p["location"],
            is_video=False,
            created_at=datetime.utcnow() - timedelta(hours=idx * 3),
        )
        db.session.add(post)
        db.session.flush()
        posts_created.append(post)

        db.session.add(PostImage(post_id=post.id, filename=p["image"], position=0, is_video=False))

        mood = mood_map.get(p["mood"])
        if mood:
            db.session.add(PostMood(post_id=post.id, mood_id=mood.id))

        for tag_name in set(re.findall(r"#(\w+)", p["caption"])):
            tag = Hashtag.query.filter_by(name=tag_name.lower()).first()
            if not tag:
                tag = Hashtag(name=tag_name.lower())
                db.session.add(tag)
                db.session.flush()
            db.session.add(PostHashtag(post_id=post.id, hashtag_id=tag.id))

        # Partial likes so like/unlike demos are visible
        for u_name in usernames:
            if u_name != p["user"] and hash(u_name + p["caption"]) % 3 != 0:
                db.session.add(Like(user_id=user_map[u_name].id, post_id=post.id))

        commenter = user_map[usernames[(usernames.index(p["user"]) + 1) % len(usernames)]]
        body = SAMPLE_COMMENTS[idx % len(SAMPLE_COMMENTS)]
        db.session.add(Comment(user_id=commenter.id, post_id=post.id, body=body))

    db.session.commit()

    for s in SAMPLE_STORIES:
        user = user_map[s["user"]]
        db.session.add(
            Story(
                user_id=user.id,
                filename=s["image"],
                is_video=False,
                caption=s["caption"],
                created_at=datetime.utcnow() - timedelta(hours=2),
            )
        )
    db.session.commit()

    for r in SAMPLE_REELS:
        user = user_map[r["user"]]
        db.session.add(
            Reel(
                user_id=user.id,
                filename=r["video"],
                thumbnail=r.get("thumbnail"),
                caption=r["caption"],
                audio_name=r["audio"],
                views=1000 + hash(r["caption"]) % 5000,
            )
        )
    db.session.commit()

    # Seed sample DM threads
    threads = [
        ("ananya_kochi", "arjun_alleppey", [
            ("ananya_kochi", "Eda, backwaters trip this weekend?"),
            ("arjun_alleppey", "Yes! Houseboat from Alappuzha. Pack light."),
            ("ananya_kochi", "Perfect. I'll bring homemade chips."),
        ]),
        ("meera_munnar", "priya_wayanad", [
            ("meera_munnar", "Wayanad trails were unreal yesterday."),
            ("priya_wayanad", "Come again for the waterfall trek!"),
        ]),
        ("rahul_tvm", "nithin_varkala", [
            ("rahul_tvm", "Cliff yoga at sunrise?"),
            ("nithin_varkala", "6:30 sharp. Bring water."),
        ]),
    ]
    for u1n, u2n, msgs in threads:
        a, b = user_map[u1n], user_map[u2n]
        uid1, uid2 = sorted([a.id, b.id])
        conv = Conversation(user_id=uid1, partner_id=uid2)
        db.session.add(conv)
        db.session.flush()
        for sender_name, body in msgs:
            db.session.add(
                Message(conversation_id=conv.id, sender_id=user_map[sender_name].id, body=body)
            )
    db.session.commit()

    print(
        f"Seed complete! {len(SAMPLE_USERS)} Kerala users, {len(SAMPLE_POSTS)} posts, "
        f"{len(SAMPLE_REELS)} reels, {len(SAMPLE_STORIES)} stories."
    )
    print("Demo login: ananya@kerala.app / password123 (admin)")
