"""Predict relative engagement potential before posting (local heuristics + AI signals)."""
from __future__ import annotations

import re


def predict_engagement(caption: str = "", image_path: str = "", has_location: bool = False) -> dict:
    """Return an engagement score 0..100 with tips."""
    score = 35.0
    tips = []
    factors = {}

    text = caption or ""
    length = len(text.strip())
    tags = re.findall(r"#\w+", text)
    mentions = re.findall(r"@\w+", text)
    emoji_count = len(re.findall(r"[\U0001F300-\U0001FAFF]", text))

    # Caption length sweet spot
    if 40 <= length <= 180:
        score += 12
        factors["caption_length"] = "optimal"
    elif length < 15:
        score += 2
        tips.append("Add a short story to your caption for more engagement.")
        factors["caption_length"] = "too_short"
    else:
        score += 6
        factors["caption_length"] = "ok"

    # Hashtags
    n_tags = len(tags)
    if 3 <= n_tags <= 10:
        score += 14
        factors["hashtags"] = "good"
    elif n_tags == 0:
        tips.append("Add 3–8 relevant hashtags (e.g. #kerala #munnar).")
        factors["hashtags"] = "missing"
    elif n_tags > 15:
        score -= 5
        tips.append("Too many hashtags can look spammy — trim to under 12.")
        factors["hashtags"] = "stuffed"
    else:
        score += 7
        factors["hashtags"] = "ok"

    if has_location:
        score += 8
        factors["location"] = True
    else:
        tips.append("Add a location tag to boost discoverability.")
        factors["location"] = False

    if emoji_count:
        tips.append("Skip emojis in captions — keep the text clean and stylish.")
        score -= min(4, emoji_count)
    if mentions:
        score += 3

    # Image signals
    if image_path:
        try:
            from app.services.ai_quality import analyze_image_quality
            from app.services.ai_face_recognition import face_count
            from app.services.ai_nsfw import nsfw_score

            q = analyze_image_quality(image_path)
            q_score = q.get("score") or 50
            score += (q_score / 100) * 20
            factors["image_quality"] = q.get("verdict")
            if q.get("verdict") in ("poor", "fair"):
                tips.extend(q.get("tips") or ["Improve image sharpness/lighting."])

            faces = face_count(image_path)
            factors["faces"] = faces
            if faces > 0:
                score += 6  # people content often performs well

            if nsfw_score(image_path) > 0.5:
                score -= 25
                tips.append("Content may be flagged — keep it community-safe.")
        except Exception:
            pass

    # Mood / positivity
    try:
        from app.services.ai_mood import detect_mood_from_text
        mood = detect_mood_from_text(text)
        factors["mood"] = mood
        if mood in ("happy", "inspired", "adventurous", "romantic"):
            score += 5
    except Exception:
        pass

    score = max(0, min(100, round(score, 1)))
    band = "high" if score >= 70 else "medium" if score >= 45 else "low"
    return {
        "score": score,
        "band": band,
        "factors": factors,
        "tips": tips[:5],
        "message": f"Estimated engagement potential: {score}/100 ({band})",
    }
