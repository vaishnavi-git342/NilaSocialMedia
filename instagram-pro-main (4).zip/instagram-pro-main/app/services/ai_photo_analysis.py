"""Advanced photo analysis combining BLIP + CLIP + OpenCV faces."""
from __future__ import annotations

from app.services.ai_engine import generate_image_caption, generate_hashtags_from_image, analyze_image
from app.services.ai_vision import zero_shot_classify, detect_faces_opencv, clip_status
from app.services.ai_nsfw import nsfw_score


def analyze_photo(image_path: str) -> dict:
    base = analyze_image(image_path or "")
    clip_tags = zero_shot_classify(image_path or "", top_k=6)
    faces = detect_faces_opencv(image_path or "")
    return {
        **base,
        "clip_tags": clip_tags,
        "faces": faces,
        "face_count": len(faces),
        "nsfw_score": nsfw_score(image_path or ""),
        "clip": clip_status(),
    }


def get_photo_tags(image_path: str, count: int = 8) -> list[str]:
    tags = zero_shot_classify(image_path or "", top_k=count)
    return [t["label"] for t in tags]


def aesthetic_hint(image_path: str) -> dict:
    """Lightweight aesthetic heuristics from CLIP top labels + caption."""
    caption = generate_image_caption(image_path or "")
    tags = zero_shot_classify(image_path or "", top_k=3)
    score = 0.55
    if tags:
        score = 0.5 + min(0.45, tags[0]["score"])
    return {
        "aesthetic_score": round(score, 2),
        "caption": caption,
        "top_tags": tags,
        "suggested_hashtags": generate_hashtags_from_image(image_path or "", caption=caption),
    }
