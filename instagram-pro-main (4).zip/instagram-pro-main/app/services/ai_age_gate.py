"""Age-gated content rating and profile-photo authenticity checks.

Uses open-source local AI (not filename/caption keyword matching as primary):
  - EXIF / image metadata (Pillow)
  - OpenAI CLIP via HuggingFace transformers (openai/clip-vit-base-patch32)
  - OpenCV Haar face detection + skin / smoothness heuristics
  - Optional BLIP captioning for context when available

All inference is local; falls back to EXIF + OpenCV when torch is missing.
"""
from __future__ import annotations

import os
import tempfile
from datetime import date, datetime
from io import BytesIO
from pathlib import Path
from typing import Any


EDIT_SOFTWARE_HEAVY = (
    "photoshop", "adobe photoshop", "facetune", "meitu", "beautyplus",
    "perfect365", "youcam", "airbrush",
)
EDIT_SOFTWARE_MILD = (
    "lightroom", "snapseed", "vsco", "picsart", "gimp", "affinity", "canva",
)
AI_SOFTWARE_HINTS = (
    "stable diffusion", "midjourney", "dall-e", "dalle", "novelai",
    "leonardo", "firefly", "generative", "synthetic", "comfyui", "automatic1111",
)


def parse_birth_date(value) -> date | None:
    if value is None:
        return None
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    if isinstance(value, datetime):
        return value.date()
    text = str(value).strip()
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def age_from_birth_date(birth: date | None, today: date | None = None) -> int | None:
    if not birth:
        return None
    today = today or date.today()
    years = today.year - birth.year
    if (today.month, today.day) < (birth.month, birth.day):
        years -= 1
    return max(0, years)


def is_adult_age(birth: date | None) -> bool:
    years = age_from_birth_date(birth)
    return bool(years is not None and years >= 18)


def _read_exif(img) -> dict[str, str]:
    """Extract human-readable EXIF tags from a Pillow image."""
    try:
        from PIL import ExifTags
        exif = img.getexif() or {}
        out = {}
        for k, v in exif.items():
            name = ExifTags.TAGS.get(k, str(k))
            try:
                out[name] = str(v)
            except Exception:
                continue
        return out
    except Exception:
        return {}


def extract_image_metadata(path_or_bytes) -> dict[str, Any]:
    """Rich metadata probe: EXIF camera fields + format/size."""
    from PIL import Image

    if isinstance(path_or_bytes, (bytes, bytearray)):
        img = Image.open(BytesIO(path_or_bytes))
        source = "bytes"
    else:
        img = Image.open(path_or_bytes)
        source = str(path_or_bytes)

    try:
        img.load()
        exif = _read_exif(img)
        software = (exif.get("Software") or "").lower()
        artist = (exif.get("Artist") or "").lower()
        desc = (exif.get("ImageDescription") or "").lower()
        make = (exif.get("Make") or "").strip()
        model = (exif.get("Model") or "").strip()
        meta_blob = f"{software} {artist} {desc}"

        return {
            "source": source,
            "format": img.format,
            "mode": img.mode,
            "width": img.size[0],
            "height": img.size[1],
            "make": make,
            "model": model,
            "software": exif.get("Software") or "",
            "datetime": exif.get("DateTime") or exif.get("DateTimeOriginal") or "",
            "has_camera_exif": bool(make or model),
            "exif": exif,
            "meta_blob": meta_blob,
            "heavy_edit_software": any(h in meta_blob for h in EDIT_SOFTWARE_HEAVY),
            "mild_edit_software": any(h in meta_blob for h in EDIT_SOFTWARE_MILD),
            "ai_software": any(h in meta_blob for h in AI_SOFTWARE_HINTS),
        }
    finally:
        try:
            img.close()
        except Exception:
            pass


def _opencv_skin_ratio(image_path: str) -> dict[str, Any]:
    """OpenCV YCrCb skin-color ratio — used as visual adult heuristic (not keywords)."""
    try:
        import cv2
        import numpy as np

        img = cv2.imread(image_path)
        if img is None:
            return {"skin_ratio": 0.0, "smoothness": 0.0}
        img = cv2.resize(img, (320, 320))
        ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
        # Classic skin range in YCrCb
        mask = cv2.inRange(ycrcb, (0, 133, 77), (255, 173, 127))
        skin_ratio = float(np.count_nonzero(mask)) / float(mask.size)

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # High smoothness (low Laplacian variance) on skin-heavy images → beauty filter
        skin_pixels = gray[mask > 0] if np.count_nonzero(mask) > 500 else gray
        if skin_pixels.size > 100:
            # Sample neighborhood variance via Laplacian on full image weighted by skin
            lap = cv2.Laplacian(gray, cv2.CV_64F)
            skin_lap = lap[mask > 0] if np.count_nonzero(mask) > 500 else lap
            smoothness = float(1.0 / (1.0 + np.var(skin_lap)))
        else:
            smoothness = 0.0

        return {
            "skin_ratio": round(skin_ratio, 4),
            "smoothness": round(smoothness, 4),
        }
    except Exception:
        return {"skin_ratio": 0.0, "smoothness": 0.0}


def _faces_and_quality(image_path: str) -> dict[str, Any]:
    faces = []
    quality = {}
    try:
        from app.services.ai_vision import detect_faces_opencv
        faces = detect_faces_opencv(image_path)
    except Exception:
        pass
    try:
        from app.services.ai_quality import analyze_image_quality
        quality = analyze_image_quality(image_path)
    except Exception:
        pass
    skin = _opencv_skin_ratio(image_path)
    return {"faces": faces, "face_count": len(faces), "quality": quality, **skin}


def _temp_path_from_storage(file_storage) -> tuple[str | None, bytes]:
    """Persist upload bytes to a temp file for CLIP/OpenCV (caller must unlink)."""
    try:
        raw = file_storage.read()
        try:
            file_storage.stream.seek(0)
        except Exception:
            pass
    except Exception:
        raw = b""
    if not raw:
        return None, b""
    suffix = Path(getattr(file_storage, "filename", "") or "upload.jpg").suffix.lower() or ".jpg"
    if suffix not in {".jpg", ".jpeg", ".png", ".webp", ".gif"}:
        suffix = ".jpg"
    fd, path = tempfile.mkstemp(prefix="ig_profile_", suffix=suffix)
    os.close(fd)
    with open(path, "wb") as fh:
        fh.write(raw)
    return path, raw


def analyze_profile_photo(file_storage) -> dict[str, Any]:
    """
    Inspect an uploaded profile photo with metadata + open-source vision AI.

    Returns:
      allowed: False if heavily edited (blocked)
      is_ai_generated: True if AI-generation signals (allowed but labeled)
      reasons: human-readable notes
    """
    reasons: list[str] = []
    is_edited = False
    is_ai = False
    signals: dict[str, Any] = {}

    tmp_path, raw = _temp_path_from_storage(file_storage)
    if not raw or not tmp_path:
        return {
            "allowed": False,
            "is_edited": True,
            "is_ai_generated": False,
            "reasons": ["Could not read the uploaded image."],
            "label": None,
            "signals": {},
        }

    if len(raw) < 2048:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        return {
            "allowed": False,
            "is_edited": True,
            "is_ai_generated": False,
            "reasons": ["Image file is too small or corrupt."],
            "label": None,
            "signals": {},
        }

    try:
        # --- 1) EXIF / metadata ---
        meta = extract_image_metadata(tmp_path)
        signals["metadata"] = {
            "make": meta["make"],
            "model": meta["model"],
            "software": meta["software"],
            "format": meta["format"],
            "size": f"{meta['width']}x{meta['height']}",
            "has_camera_exif": meta["has_camera_exif"],
        }
        if meta["heavy_edit_software"]:
            is_edited = True
            reasons.append(
                f"EXIF Software indicates heavy editing ({meta['software'] or 'editor'})."
            )
        elif meta["mild_edit_software"]:
            reasons.append(f"Mild edit tool in EXIF ({meta['software']}) — allowed.")
        if meta["ai_software"]:
            is_ai = True
            reasons.append(f"EXIF indicates AI generation ({meta['software'] or 'AI tool'}).")
        if meta["has_camera_exif"]:
            reasons.append(f"Camera EXIF present ({meta['make']} {meta['model']}).".strip())

        # --- 2) OpenCV faces + quality + skin smoothness ---
        visual = _faces_and_quality(tmp_path)
        signals["opencv"] = {
            "face_count": visual["face_count"],
            "skin_ratio": visual["skin_ratio"],
            "smoothness": visual["smoothness"],
            "quality": visual.get("quality", {}).get("verdict"),
            "blur": visual.get("quality", {}).get("blur_variance"),
        }
        # Ultra-smooth skin + no camera EXIF → beauty-filter / heavy retouch signal
        if (
            visual["smoothness"] >= 0.35
            and visual["skin_ratio"] >= 0.28
            and not meta["has_camera_exif"]
            and visual["face_count"] >= 1
        ):
            is_edited = True
            reasons.append(
                "OpenCV analysis: face region is unnaturally smooth without camera EXIF "
                "(likely heavy beauty filter / retouch)."
            )

        # --- 3) Open-source CLIP authenticity (transformers) ---
        try:
            from app.services.ai_vision import classify_authenticity, clip_status

            auth = classify_authenticity(tmp_path)
            signals["clip_authenticity"] = auth
            status = clip_status()
            signals["clip_status"] = {
                "available": status.get("available"),
                "model": status.get("model"),
                "device": status.get("device"),
            }

            # Decision thresholds tuned for zero-shot CLIP
            if auth["edited_score"] >= 0.28 and auth["edited_score"] >= auth["real_score"] * 0.95:
                is_edited = True
                reasons.append(
                    f"CLIP (open-source) flags heavy edit "
                    f"(edited={auth['edited_score']:.2f}, real={auth['real_score']:.2f})."
                )
            if auth["ai_score"] >= 0.28 and auth["ai_score"] >= auth["real_score"] * 0.9:
                is_ai = True
                reasons.append(
                    f"CLIP (open-source) flags AI-generated portrait "
                    f"(ai={auth['ai_score']:.2f}, real={auth['real_score']:.2f})."
                )
            if auth["real_score"] >= 0.35 and auth["real_score"] > max(auth["ai_score"], auth["edited_score"]):
                reasons.append(
                    f"CLIP leans natural photo (real={auth['real_score']:.2f})."
                )
            if auth.get("engine") == "fallback":
                reasons.append("CLIP model unavailable — used EXIF + OpenCV only.")
        except Exception as exc:
            reasons.append(f"Vision model probe skipped: {exc}")

        # --- 4) Soft AI export pattern: large PNG, no camera, high AI/edit scores already handled ---
        if (
            not meta["has_camera_exif"]
            and meta["format"] in {"PNG", "WEBP"}
            and meta["width"] >= 1024
            and not is_edited
            and signals.get("clip_authenticity", {}).get("ai_score", 0) >= 0.22
        ):
            is_ai = True
            if "AI-generated" not in " ".join(reasons):
                reasons.append("Export looks like synthetic PNG/WEBP without camera EXIF.")

    finally:
        try:
            if tmp_path and os.path.isfile(tmp_path):
                os.unlink(tmp_path)
        except OSError:
            pass

    allowed = not is_edited
    label = None
    if is_ai:
        label = "AI-generated profile photo"
    if is_edited:
        label = "Heavily edited photo (not allowed)"

    if not reasons:
        reasons = ["Looks like a natural photo (metadata + vision)."]

    return {
        "allowed": allowed,
        "is_edited": is_edited,
        "is_ai_generated": is_ai,
        "reasons": reasons,
        "label": label,
        "signals": signals,
    }


def _analysis_image_path(path: str | None) -> str | None:
    """For videos, extract a middle frame; otherwise return the image path."""
    if not path or not os.path.isfile(path):
        return None
    ext = Path(path).suffix.lower()
    if ext in {".mp4", ".webm", ".mov", ".mkv", ".avi"}:
        try:
            from app.services.ai_vision import extract_video_frame
            frame = extract_video_frame(path)
            return frame
        except Exception:
            return None
    return path


def rate_image_quick(path: str | None) -> dict[str, Any]:
    """OpenCV-only adult check. Does not load CLIP or TensorFlow."""
    skin = _opencv_skin_ratio(path) if path else {"skin_ratio": 0.0, "smoothness": 0.0}
    is_adult = skin["skin_ratio"] >= 0.70 and skin["smoothness"] >= 0.30
    return {
        "is_adult_content": is_adult,
        "rating": "18+" if is_adult else "general",
    }


def rate_media_file(path: str | None, caption: str = "") -> dict[str, Any]:
    """
    Rate post/reel media as adult or general using open-source vision AI.

    Primary: CLIP NSFW zero-shot on the actual pixels (+ video frame).
    Secondary: OpenCV skin-ratio heuristic when CLIP is unavailable.
    Caption is NOT used as the primary adult detector.
    """
    analysis_path = _analysis_image_path(path)
    signals: list[str] = []
    nsfw = 0.0
    engine = "none"

    if analysis_path:
        try:
            from app.services.ai_nsfw import nsfw_score
            from app.services.ai_vision import clip_status, zero_shot_classify

            nsfw = float(nsfw_score(analysis_path))
            status = clip_status()
            engine = "clip" if status.get("available") else "opencv-fallback"
            signals.append(f"nsfw_score={nsfw:.3f}")

            # Extra zero-shot context (open-source CLIP)
            try:
                tags = zero_shot_classify(
                    analysis_path,
                    [
                        "a safe everyday photo",
                        "an explicit adult nude photo",
                        "a beach photo with swimwear",
                        "a food photo",
                        "a landscape photo",
                    ],
                    top_k=3,
                )
                if tags:
                    signals.append("clip_top=" + ", ".join(f"{t['label']}({t['score']:.2f})" for t in tags[:2]))
            except Exception:
                pass
        except Exception as exc:
            signals.append(f"clip_error={exc}")

        # OpenCV visual fallback only when CLIP is unavailable
        skin = _opencv_skin_ratio(analysis_path)
        signals.append(f"skin_ratio={skin['skin_ratio']:.3f}")
        if engine != "clip":
            if skin["skin_ratio"] >= 0.70 and skin["smoothness"] >= 0.30:
                nsfw = max(nsfw, 0.60)
                signals.append("opencv_skin_heuristic=elevated")
                engine = "opencv-skin"

        # Cleanup extracted video frame temp sibling if created next to video
        if path and analysis_path != path and analysis_path.endswith("_frame.jpg"):
            pass  # keep frame for debugging thumbs; harmless

    is_adult = nsfw >= 0.55
    return {
        "is_adult_content": is_adult,
        "rating": "18+" if is_adult else "general",
        "nsfw_score": round(nsfw, 4),
        "engine": engine,
        "signals": signals,
        "summary": (
            f"Flagged as 18+ by vision AI ({engine}, score={nsfw:.2f})"
            if is_adult
            else f"Suitable for all ages (vision AI {engine}, score={nsfw:.2f})"
        ),
        "caption_ignored": True,
    }


# Back-compat stub — caption keywords are no longer the adult detector
def rate_text_content(caption: str = "", extra: str = "") -> dict[str, Any]:
    """Deprecated for adult gating; returns general unless vision path is used."""
    return {
        "is_adult_content": False,
        "rating": "general",
        "signals": [],
        "summary": "Text-only rating disabled — use rate_media_file for vision AI.",
    }
