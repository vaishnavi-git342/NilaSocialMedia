"""Suggest Kerala / travel locations from image using CLIP zero-shot."""
from __future__ import annotations

KERALA_PLACES = [
    "Fort Kochi, Kerala",
    "Alappuzha Backwaters, Kerala",
    "Munnar Tea Gardens, Kerala",
    "Varkala Cliff, Kerala",
    "Kovalam Beach, Kerala",
    "Wayanad Forests, Kerala",
    "Thrissur, Kerala",
    "Kozhikode Beach, Kerala",
    "Thekkady, Kerala",
    "Athirappilly Waterfalls, Kerala",
    "Padmanabhaswamy Temple, Thiruvananthapuram",
    "Bekal Fort, Kerala",
]


def suggest_locations(image_path: str, top_k: int = 3) -> list[dict]:
    """Return likely locations with confidence scores."""
    from app.services.ai_vision import zero_shot_classify

    labels = [f"a photo of {p}" for p in KERALA_PLACES]
    results = zero_shot_classify(image_path or "", labels=labels, top_k=top_k)
    mapped = []
    for r in results:
        # strip "a photo of "
        place = r["label"].replace("a photo of ", "").strip()
        mapped.append({"location": place, "score": round(float(r["score"]), 4)})
    if not mapped:
        # filename fallback
        name = (image_path or "").lower()
        for p in KERALA_PLACES:
            key = p.split(",")[0].split()[0].lower()
            if key in name:
                mapped.append({"location": p, "score": 0.4})
        if not mapped:
            mapped = [{"location": "Kerala, India", "score": 0.2}]
    return mapped[:top_k]
