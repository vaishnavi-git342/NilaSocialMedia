"""AI services package.

Local engine uses Salesforce BLIP (Hugging Face) for image captions and
hashtag generation. See app.services.ai_engine.
"""
