"""Home feed ranking — Instagram-like following timeline with visibility rules."""
from __future__ import annotations

from app.models.follow import Follow
from app.models.post import Post
from app.models.user import User


def get_recommended_posts(user_id: int, limit: int = 12, offset: int = 0) -> list[Post]:
    """Chronological following feed (own posts included), with privacy / mute / age filters.

    Cold-start: recent public posts when the following timeline is empty.
    """
    from flask_login import current_user
    from app.utils.helpers import filter_visible_posts

    following_ids = [
        f.followed_id
        for f in Follow.query.filter_by(follower_id=user_id, accepted=True).all()
    ]
    following_ids.append(user_id)

    viewer = current_user if getattr(current_user, "is_authenticated", False) else None
    base = filter_visible_posts(Post.query, viewer=viewer)

    posts = (
        base.filter(Post.user_id.in_(following_ids))
        .order_by(Post.created_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )

    if posts or offset > 0:
        return posts

    # Cold-start: public recent posts (still age/privacy filtered via filter_visible_posts)
    return (
        filter_visible_posts(Post.query, viewer=viewer)
        .filter(User.is_private.is_(False), Post.user_id != user_id)
        .order_by(Post.created_at.desc())
        .limit(limit)
        .all()
    )
