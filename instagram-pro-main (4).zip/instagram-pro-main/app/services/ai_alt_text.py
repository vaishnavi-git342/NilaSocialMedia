"""Generate accessibility alt-text and multi-style captions from local BLIP."""
from __future__ import annotations

from app.services.ai_engine import (
    _describe_image,
    strip_caption_emojis,
    suggest_image_captions,
)


def generate_alt_text(image_path: str) -> str:
    """Short accessibility-friendly alt text (descriptive, not stylish)."""
    caption = strip_caption_emojis(_describe_image(image_path or ""))
    if len(caption) > 125:
        caption = caption[:122].rstrip() + "..."
    return caption or "Photograph shared on Nila Social"


def generate_caption_styles(image_path: str) -> dict:
    """Return captions in multiple stylish styles — no emojis, no alt-text voice."""
    variants = suggest_image_captions(image_path or "", count=4)
    base = variants[0] if variants else "caught in the moment"
    short = variants[1] if len(variants) > 1 else base
    poetic = variants[2] if len(variants) > 2 else "soft light, quieter thoughts"
    travel = variants[3] if len(variants) > 3 else "somewhere worth remembering"
    return {
        "descriptive": base,
        "short": short,
        "poetic": poetic,
        "travel": travel,
        "alt_text": generate_alt_text(image_path),
        "variants": variants,
    }
