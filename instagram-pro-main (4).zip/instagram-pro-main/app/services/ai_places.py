"""Kerala Place Intelligence — nearby spots, tips, and routes."""
from __future__ import annotations

from app.services.ai_location import suggest_locations, KERALA_PLACES

PLACE_GUIDE = {
    "Fort Kochi, Kerala": {
        "nearby": ["Chinese Fishing Nets", "Jew Town", "Santa Cruz Basilica", "Fort Kochi Beach"],
        "tips": ["Best light around sunset", "Try local toddy shop snacks", "Walk Jew Town lanes early morning"],
        "route": ["Ernakulam", "Fort Kochi", "Mattancherry"],
        "best_season": "Oct–Mar",
    },
    "Alappuzha Backwaters, Kerala": {
        "nearby": ["Houseboat jetties", "Pathiramanal Island", "Ambalapuzha Temple"],
        "tips": ["Book overnight houseboat for sunrise", "Carry mosquito repellent", "Try karimeen pollichathu"],
        "route": ["Alappuzha", "Punnamada", "Kuttanad"],
        "best_season": "Sep–Feb",
    },
    "Munnar Tea Gardens, Kerala": {
        "nearby": ["Eravikulam National Park", "Tea Museum", "Mattupetty Dam", "Top Station"],
        "tips": ["Wear a light jacket", "Visit at sunrise for mist", "Try local tea tasting"],
        "route": ["Adimali", "Munnar town", "Tea estates", "Top Station"],
        "best_season": "Sep–May",
    },
    "Varkala Cliff, Kerala": {
        "nearby": ["Varkala Beach", "Janardanaswamy Temple", "Black Beach"],
        "tips": ["Cliff cafes for sunset", "Avoid cliff edge during monsoon", "Morning yoga vibes"],
        "route": ["Thiruvananthapuram", "Varkala", "Cliff walk"],
        "best_season": "Oct–Mar",
    },
    "Kovalam Beach, Kerala": {
        "nearby": ["Lighthouse Beach", "Hawah Beach", "Samudra Beach"],
        "tips": ["Lighthouse viewpoint at dusk", "Ayurveda massages nearby"],
        "route": ["Trivandrum", "Kovalam"],
        "best_season": "Oct–Mar",
    },
    "Wayanad Forests, Kerala": {
        "nearby": ["Edakkal Caves", "Banasura Sagar", "Soochipara Falls", "Chembra Peak"],
        "tips": ["Trek early morning", "Leech socks in monsoon", "Book forest permits ahead"],
        "route": ["Kalpetta", "Meppadi", "Chembra / Soochipara"],
        "best_season": "Oct–May",
    },
    "Thrissur, Kerala": {
        "nearby": ["Vadakkunnathan Temple", "Athirappilly", "Guruvayur"],
        "tips": ["Visit during Pooram if possible", "Try Thrissur sadya"],
        "route": ["Thrissur city", "Temple grounds"],
        "best_season": "Apr–May (Pooram)",
    },
    "Kozhikode Beach, Kerala": {
        "nearby": ["SM Street", "Mananchira", "Kappad Beach"],
        "tips": ["Malabar biryani is a must", "Evening beach promenade"],
        "route": ["Kozhikode city", "Beach road", "SM Street"],
        "best_season": "Oct–Mar",
    },
    "Athirappilly Waterfalls, Kerala": {
        "nearby": ["Vazhachal Falls", "Thumboormuzhi", "Charpa Falls"],
        "tips": ["Best after rains", "Wear non-slip shoes", "Keep drone rules in mind"],
        "route": ["Chalakudy", "Athirappilly", "Vazhachal"],
        "best_season": "Jun–Nov",
    },
}


def place_intelligence(image_path: str = "", location_hint: str = "") -> dict:
    """Combine CLIP location guess with local travel intelligence."""
    locations = []
    if image_path:
        locations = suggest_locations(image_path, top_k=3)
    primary = location_hint.strip() if location_hint else None
    if not primary and locations:
        primary = locations[0]["location"]
    if not primary:
        primary = "Kerala, India"

    # Fuzzy match guide key
    guide = None
    for key, data in PLACE_GUIDE.items():
        if key.lower() in primary.lower() or primary.lower() in key.lower() or key.split(",")[0].lower() in primary.lower():
            guide = {"place": key, **data}
            break
    if not guide:
        guide = {
            "place": primary,
            "nearby": ["Local markets", "Scenic viewpoints", "Traditional eateries"],
            "tips": ["Ask locals for hidden spots", "Carry water", "Respect temple dress codes"],
            "route": [primary],
            "best_season": "Oct–Mar",
        }

    return {
        "detected_locations": locations,
        "primary": guide["place"],
        "nearby": guide["nearby"],
        "tips": guide["tips"],
        "route": guide["route"],
        "best_season": guide["best_season"],
        "caption_idea": f"Exploring {guide['place']} — {guide['tips'][0]}",
    }
