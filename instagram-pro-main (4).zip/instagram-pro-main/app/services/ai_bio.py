"""AI bio generator for profile setup / edit."""
from __future__ import annotations


TEMPLATES = [
    "{name} | Exploring Kerala one frame at a time 🌿",
    "Based in {place} | Stories from God's Own Country",
    "{name} · Photographer · {place}",
    "Food, festivals & backwaters | {place}",
    "Sharing monsoon moods from {place} ☔",
    "{name} | Travel · Culture · Kerala diaries",
]


def generate_bios(full_name: str = "", location_hint: str = "Kerala", count: int = 5) -> list[str]:
    name = (full_name or "Creator").strip() or "Creator"
    place = (location_hint or "Kerala").strip() or "Kerala"
    bios = [t.format(name=name, place=place) for t in TEMPLATES]
    # unique trim
    return bios[:count]
