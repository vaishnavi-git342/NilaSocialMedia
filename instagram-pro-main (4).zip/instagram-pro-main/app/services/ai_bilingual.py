"""Bilingual English + Malayalam (Manglish) caption helpers for Instagram Pro."""
from __future__ import annotations

import re

# Common English -> Manglish / Malayalam transliteration phrases for social captions
PHRASE_MAP = [
    (r"\bbeautiful\b", "sundaram"),
    (r"\blove\b", "sneham"),
    (r"\bthank you\b", "nanni"),
    (r"\bthanks\b", "nanni"),
    (r"\bhello\b", "namaskaram"),
    (r"\bhi\b", "hai"),
    (r"\bgood morning\b", "suprabhatham"),
    (r"\bgood night\b", "shubha rathri"),
    (r"\bfriend\b", "koottukaran"),
    (r"\bhome\b", "veedu"),
    (r"\brain\b", "mazha"),
    (r"\bbeach\b", "kadappuram"),
    (r"\bfood\b", "bhakshanam"),
    (r"\btravel\b", "yathra"),
    (r"\bsunset\b", "asthyamayam"),
    (r"\bmountain\b", "mala"),
    (r"\bhappy\b", "santhosham"),
    (r"\bfestival\b", "ulsavam"),
]

MALAYALAM_HASHTAGS = ["#kerala", "#malayalam", "#godowncountry", "#mallu", "#onam", "#mazha"]

GREETINGS = {
    "happy": "Santhaasham! ",
    "relaxed": "Shaantiyaaya oru nimisham. ",
    "adventurous": "Yathra thudarunnu! ",
    "romantic": "Sneham niranja sandhya. ",
    "energetic": "Ulsavam mood! ",
    "inspired": "Prerana tharunna kazhcha. ",
    "nostalgic": "Orma thirichuvarunnu. ",
    "sad": "Oru soft moment. ",
}


def to_manglish(text: str) -> str:
    """Light English -> Manglish phrasing for bilingual captions."""
    if not text:
        return ""
    out = text
    for pattern, repl in PHRASE_MAP:
        out = re.sub(pattern, repl, out, flags=re.IGNORECASE)
    return out


def bilingual_caption(english_caption: str, mood: str | None = None) -> dict:
    """Return EN + Manglish bilingual caption pack."""
    from app.services.ai_engine import strip_caption_emojis

    en = strip_caption_emojis((english_caption or "").strip())
    if not en:
        en = "caught in the moment"
    ml = to_manglish(en)
    greeting = GREETINGS.get((mood or "").lower(), "")
    bilingual = f"{en}\n\n— {greeting}{ml}".strip()
    tags = list(MALAYALAM_HASHTAGS)
    if mood:
        tags.append(f"#{mood.lower()}")
    return {
        "english": en,
        "manglish": ml,
        "bilingual": bilingual,
        "hashtags": tags,
        "mood": mood,
    }


def generate_bilingual_from_image(image_path: str) -> dict:
    from app.services.ai_engine import generate_image_caption
    from app.services.ai_mood import detect_mood_from_text

    caption = generate_image_caption(image_path or "")
    mood = detect_mood_from_text(caption)
    return bilingual_caption(caption, mood=mood)
