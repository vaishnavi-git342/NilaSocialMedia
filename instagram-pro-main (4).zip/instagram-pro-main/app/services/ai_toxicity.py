"""AI Comment Toxicity Detection — local keyword + pattern engine."""
import re


TOXIC_PATTERNS = [
    r"\bhate\b",
    r"\bstupid\b",
    r"\bidiot\b",
    r"\bkill\b",
    r"\bdumb\b",
    r"\bshut\s*up\b",
    r"\bf+u+c+k+\b",
    r"\basshole\b",
    r"\btrash\b",
    r"\bworse?\s*than\b",
]


def is_toxic(text: str) -> bool:
    if not text:
        return False
    text_lower = text.lower()
    return any(re.search(p, text_lower) for p in TOXIC_PATTERNS)


def toxicity_score(text: str) -> float:
    if not text:
        return 0.0
    text_lower = text.lower()
    hits = sum(1 for p in TOXIC_PATTERNS if re.search(p, text_lower))
    return min(1.0, hits * 0.35)
