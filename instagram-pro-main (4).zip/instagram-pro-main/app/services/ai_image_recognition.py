"""AI Image Recognition — labels from local BLIP caption analysis."""
from app.services.ai_engine import analyze_image, _extract_labels, generate_image_caption


def recognize_image(image_path: str) -> dict:
    result = analyze_image(image_path or "")
    return {
        "labels": result.get("labels", []),
        "caption": result.get("caption", ""),
        "engine": result.get("engine"),
    }


def detect_objects(image_path: str) -> list[str]:
    caption = generate_image_caption(image_path or "")
    return _extract_labels(caption)
