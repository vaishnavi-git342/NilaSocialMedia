"""Advanced local AI toolkit: CLIP zero-shot, video frames, OpenCV faces.

Models (downloaded on first use, then cached locally):
- Salesforce/blip-image-captioning-base  (captions) — via ai_engine
- openai/clip-vit-base-patch32          (zero-shot tags / NSFW)
- OpenCV Haar cascades                  (face detection, no download)

All inference is local CPU/GPU — no cloud APIs.
"""
from __future__ import annotations

import os
import threading
from typing import Any

_torch = None
_clip_model = None
_clip_processor = None
_clip_device = "cpu"
_clip_error: str | None = None
_clip_lock = threading.Lock()

CLIP_MODEL_ID = "openai/clip-vit-base-patch32"

# Zero-shot label bank for Instagram / Kerala content
CLIP_CANDIDATE_LABELS = [
    "a beach", "a mountain", "a forest", "a lake", "a waterfall",
    "a city street", "a temple", "a festival", "a boat", "a houseboat",
    "tea plantation", "food on a plate", "people smiling", "a sunset",
    "a portrait photo", "an animal", "flowers", "architecture",
    "kerala backwaters", "monsoon rain", "street food", "a selfie",
]

NSFW_LABELS = [
    "a normal safe everyday photograph",
    "a clothed person portrait photo",
    "a food photograph on a plate",
    "a nature landscape or travel photo",
    "an explicit nude or pornographic photograph",
    "a sexually explicit adult image",
]


# Profile authenticity — CLIP zero-shot (open-source openai/clip-vit-base-patch32)
AUTHENTICITY_LABELS = [
    "a natural unedited smartphone portrait photo",
    "a real camera photograph of a person",
    "an AI-generated synthetic digital portrait",
    "a heavily photoshopped beauty-filtered portrait",
    "a Facetune or Snapchat beauty filter selfie",
    "an illustrated anime or CGI character",
]


def classify_authenticity(image_path: str) -> dict[str, Any]:
    """Return CLIP authenticity scores for edit / AI / real photo gates."""
    scored = zero_shot_classify(image_path, AUTHENTICITY_LABELS, top_k=6)
    by_label = {r["label"]: r["score"] for r in scored}
    real = max(
        by_label.get("a natural unedited smartphone portrait photo", 0.0),
        by_label.get("a real camera photograph of a person", 0.0),
    )
    ai = max(
        by_label.get("an AI-generated synthetic digital portrait", 0.0),
        by_label.get("an illustrated anime or CGI character", 0.0),
    )
    edited = max(
        by_label.get("a heavily photoshopped beauty-filtered portrait", 0.0),
        by_label.get("a Facetune or Snapchat beauty filter selfie", 0.0),
    )
    return {
        "real_score": float(real),
        "ai_score": float(ai),
        "edited_score": float(edited),
        "top": scored[:3],
        "engine": "clip" if clip_available() else "fallback",
    }


def nsfw_probability(image_path: str) -> float:
    """CLIP-based NSFW probability (0..1) from open-source CLIP zero-shot.

    Softmax is over a balanced set of safe + unsafe labels so normal portraits,
    food, and landscapes do not falsely dominate the adult class.
    """
    if not image_path or not os.path.isfile(image_path):
        return 0.0

    if _ensure_clip():
        results = zero_shot_classify(image_path, NSFW_LABELS, top_k=len(NSFW_LABELS))
        if not results:
            return 0.0
        risky = 0.0
        safe = 0.0
        top = results[0]
        for r in results:
            label = r["label"].lower()
            score = float(r["score"])
            if any(k in label for k in ("nude", "pornographic", "sexually explicit", "adult image")):
                risky += score
            else:
                safe += score
        # Top label must be unsafe, or unsafe mass must clearly beat safe mass
        top_unsafe = any(
            k in top["label"].lower()
            for k in ("nude", "pornographic", "sexually explicit", "adult image")
        )
        if top_unsafe and float(top["score"]) >= 0.34:
            return float(min(1.0, float(top["score"])))
        if risky >= 0.40 and risky >= safe * 1.15:
            return float(min(1.0, risky))
        # Otherwise treat as safe — return low residual score for logging only
        return float(min(0.25, risky))

    # OpenCV skin heuristic when CLIP weights are not loaded
    try:
        import cv2
        import numpy as np
        img = cv2.imread(image_path)
        if img is None:
            return 0.0
        img = cv2.resize(img, (256, 256))
        ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
        mask = cv2.inRange(ycrcb, (0, 133, 77), (255, 173, 127))
        ratio = float(np.count_nonzero(mask)) / float(mask.size)
        if ratio >= 0.72:
            return 0.68
        if ratio >= 0.60:
            return 0.45
        return float(min(0.22, ratio * 0.3))
    except Exception:
        return 0.0


def _block_tensorflow():
    """Keep TensorFlow out of this process. Importing it crashes the app on Windows."""
    os.environ["USE_TF"] = "0"
    os.environ["TRANSFORMERS_NO_TF"] = "1"
    os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
    os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"


def _try_torch():
    global _torch
    if _torch is not None:
        return True
    _block_tensorflow()
    try:
        import torch as t
        _torch = t
        return True
    except Exception:
        return False


def _ensure_clip() -> bool:
    global _clip_model, _clip_processor, _clip_device, _clip_error
    if _clip_model is not None:
        return True
    if not _try_torch():
        _clip_error = "torch not installed"
        return False
    with _clip_lock:
        if _clip_model is not None:
            return True
        try:
            from transformers import CLIPProcessor, CLIPModel
            _clip_device = "cuda" if _torch.cuda.is_available() else "cpu"
            _clip_processor = CLIPProcessor.from_pretrained(CLIP_MODEL_ID)
            _clip_model = CLIPModel.from_pretrained(CLIP_MODEL_ID)
            _clip_model.to(_clip_device)
            _clip_model.eval()
            return True
        except Exception as exc:  # noqa: BLE001
            _clip_error = str(exc)
            _clip_model = None
            _clip_processor = None
            return False


def clip_available() -> bool:
    return _ensure_clip()


def clip_status() -> dict[str, Any]:
    return {
        "available": _try_torch(),
        "loaded": _clip_model is not None,
        "model": CLIP_MODEL_ID,
        "device": _clip_device,
        "error": _clip_error,
    }


def _open_image(path: str):
    from PIL import Image
    img = Image.open(path).convert("RGB")
    img.thumbnail((384, 384))
    return img


def zero_shot_classify(image_path: str, labels: list[str] | None = None, top_k: int = 5) -> list[dict]:
    """CLIP zero-shot classification — returns [{label, score}, ...]."""
    if not image_path or not os.path.isfile(image_path):
        return []
    if not _ensure_clip():
        return _fallback_classify(image_path, labels or CLIP_CANDIDATE_LABELS, top_k)
    labels = labels or CLIP_CANDIDATE_LABELS
    try:
        image = _open_image(image_path)
        inputs = _clip_processor(
            text=labels,
            images=image,
            return_tensors="pt",
            padding=True,
        ).to(_clip_device)
        with _torch.no_grad():
            outputs = _clip_model(**inputs)
            probs = outputs.logits_per_image.softmax(dim=1)[0]
        scored = [
            {"label": labels[i], "score": float(probs[i])}
            for i in range(len(labels))
        ]
        scored.sort(key=lambda x: x["score"], reverse=True)
        return scored[:top_k]
    except Exception as exc:  # noqa: BLE001
        _clip_error = str(exc)
        return _fallback_classify(image_path, labels, top_k)


def extract_video_frame(video_path: str, out_path: str | None = None) -> str | None:
    """Extract a middle frame from a video for AI analysis. Uses OpenCV."""
    if not video_path or not os.path.isfile(video_path):
        return None
    try:
        import cv2
    except ImportError:
        return None
    try:
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            return None
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        mid = max(total // 2, 0)
        cap.set(cv2.CAP_PROP_POS_FRAMES, mid)
        ok, frame = cap.read()
        if not ok:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            ok, frame = cap.read()
        cap.release()
        if not ok or frame is None:
            return None
        if out_path is None:
            base, _ = os.path.splitext(video_path)
            out_path = f"{base}_frame.jpg"
        cv2.imwrite(out_path, frame)
        return out_path if os.path.isfile(out_path) else None
    except Exception:
        return None


def detect_faces_opencv(image_path: str) -> list[dict]:
    """Detect faces with OpenCV Haar cascades (bundled, fully local)."""
    if not image_path or not os.path.isfile(image_path):
        return []
    try:
        import cv2
    except ImportError:
        return []
    try:
        img = cv2.imread(image_path)
        if img is None:
            return []
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        cascade_path = os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml")
        cascade = cv2.CascadeClassifier(cascade_path)
        faces = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40))
        results = []
        for (x, y, w, h) in faces:
            results.append({
                "x": int(x),
                "y": int(y),
                "width": int(w),
                "height": int(h),
                "confidence": 0.85,
            })
        return results
    except Exception:
        return []


def _fallback_classify(image_path: str, labels: list[str], top_k: int) -> list[dict]:
    name = os.path.basename(image_path).lower()
    scored = []
    for label in labels:
        score = 0.15
        for token in label.lower().split():
            if token in name:
                score += 0.35
        scored.append({"label": label, "score": min(score, 0.95)})
    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored[:top_k]
