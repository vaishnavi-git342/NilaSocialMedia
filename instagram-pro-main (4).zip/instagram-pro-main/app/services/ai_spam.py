"""Advanced local spam detection (heuristics + pattern analysis)."""
from __future__ import annotations

import re
from collections import Counter


SPAM_PHRASES = [
    "buy now", "click here", "free money", "limited offer", "act now",
    "make money fast", "work from home $$$", "crypto giveaway",
    "dm for promo", "follow for follow", "f4f", "l4l", "gain followers",
]


def spam_score(text: str) -> float:
    if not text or not text.strip():
        return 0.0
    t = text.strip()
    lower = t.lower()
    score = 0.0

    for phrase in SPAM_PHRASES:
        if phrase in lower:
            score += 0.35

    # Excessive URLs
    urls = re.findall(r"https?://|www\.", lower)
    if len(urls) >= 2:
        score += 0.3
    elif len(urls) == 1 and len(t) < 40:
        score += 0.25

    # Repeated characters (heyyyyyy)
    if re.search(r"(.)\1{5,}", lower):
        score += 0.2

    # All caps shouting
    letters = [c for c in t if c.isalpha()]
    if letters and sum(1 for c in letters if c.isupper()) / len(letters) > 0.7 and len(letters) > 12:
        score += 0.2

    # Hashtag stuffing
    tags = re.findall(r"#\w+", t)
    if len(tags) >= 15:
        score += 0.35
    elif len(tags) >= 10:
        score += 0.2

    # Repeated words
    words = re.findall(r"[a-z0-9]+", lower)
    if words:
        common = Counter(words).most_common(1)[0]
        if common[1] >= 5 and common[0] not in {"the", "and", "a"}:
            score += 0.25

    # Phone / promo patterns
    if re.search(r"\b\d{10}\b", t) or re.search(r"whats?app", lower):
        score += 0.2

    return min(1.0, score)


def is_spam(text: str, threshold: float = 0.5) -> bool:
    return spam_score(text) >= threshold
