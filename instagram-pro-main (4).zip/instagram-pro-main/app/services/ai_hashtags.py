"""AI Hashtag Recommendation — image + caption based via local BLIP."""
from app.services.ai_engine import (
    generate_hashtags_from_image,
    recommend_hashtags_text,
)


def recommend_hashtags(image_path: str, caption: str = "", count: int = 10) -> list[str]:
    if image_path:
        return generate_hashtags_from_image(image_path, caption=caption, count=count)
    return recommend_hashtags_text(caption=caption, count=count)
