"""Privacy Clarity Meter — explain who can see content before posting."""
from __future__ import annotations


def privacy_clarity(user, audience: str = "auto") -> dict:
    """
    audience: auto | public | followers | close_friends
    """
    is_private = bool(getattr(user, "is_private", False))
    if audience == "auto":
        audience = "followers" if is_private else "public"

    matrix = {
        "public": {
            "label": "Public",
            "who": "Anyone on Instagram Pro (even non-followers)",
            "risk": "high" if not is_private else "medium",
            "score": 25 if not is_private else 45,
            "tips": ["Avoid sharing exact home address", "Review tagged people", "Consider Close Friends for personal moments"],
        },
        "followers": {
            "label": "Followers only",
            "who": "Only approved followers can see this",
            "risk": "medium",
            "score": 65,
            "tips": ["Audit follower list regularly", "Private account recommended for tighter control"],
        },
        "close_friends": {
            "label": "Close Friends",
            "who": "Only people in your Close Friends list",
            "risk": "low",
            "score": 90,
            "tips": ["Best for personal / family moments", "Keep the list small and updated"],
        },
    }
    data = matrix.get(audience, matrix["public"])
    return {
        "audience": audience,
        "account_private": is_private,
        "label": data["label"],
        "who_can_see": data["who"],
        "risk": data["risk"],
        "clarity_score": data["score"],
        "tips": data["tips"],
        "summary": f"{data['label']}: {data['who']} (privacy score {data['score']}/100)",
    }
