"""Find similar posts using caption/hashtag overlap + optional CLIP labels."""
from __future__ import annotations

import re
from app.models.post import Post


def _tokens(text: str) -> set[str]:
    tags = {t.lower() for t in re.findall(r"#(\w+)", text or "")}
    words = {w.lower() for w in re.findall(r"[a-zA-Z]{4,}", text or "")}
    return tags | words


def find_similar_posts(caption: str = "", image_path: str = "", limit: int = 6, exclude_post_id: int | None = None) -> list[dict]:
    """Return similar posts with a similarity score."""
    query_tokens = _tokens(caption)

    # Enrich with CLIP labels if image provided
    if image_path:
        try:
            from app.services.ai_vision import zero_shot_classify
            for t in zero_shot_classify(image_path, top_k=5):
                for part in re.findall(r"[a-zA-Z]{4,}", t["label"]):
                    query_tokens.add(part.lower())
        except Exception:
            pass

    if not query_tokens:
        posts = Post.query.order_by(Post.created_at.desc()).limit(limit).all()
        return [{"post_id": p.id, "caption": p.caption, "score": 0.1, "user": p.user.username} for p in posts]

    candidates = Post.query.order_by(Post.created_at.desc()).limit(80).all()
    scored = []
    for p in candidates:
        if exclude_post_id and p.id == exclude_post_id:
            continue
        toks = _tokens(p.caption or "")
        if not toks:
            continue
        overlap = len(query_tokens & toks)
        if overlap == 0:
            continue
        union = len(query_tokens | toks) or 1
        score = overlap / union
        scored.append({
            "post_id": p.id,
            "caption": (p.caption or "")[:120],
            "score": round(score, 3),
            "user": p.user.username if p.user else None,
            "likes": p.like_count,
        })
    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored[:limit]
