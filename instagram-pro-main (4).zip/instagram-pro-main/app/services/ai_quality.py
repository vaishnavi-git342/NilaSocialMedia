"""Local image quality analysis (blur, brightness, contrast) via OpenCV/Pillow."""
from __future__ import annotations

import os


def analyze_image_quality(image_path: str) -> dict:
    """Return quality metrics and a 0..100 score."""
    if not image_path or not os.path.isfile(image_path):
        return {"score": 0, "blur": None, "brightness": None, "contrast": None, "verdict": "no_image"}

    try:
        import cv2
        import numpy as np

        img = cv2.imread(image_path)
        if img is None:
            return _pillow_quality(image_path)

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        blur = float(cv2.Laplacian(gray, cv2.CV_64F).var())
        brightness = float(np.mean(gray))
        contrast = float(np.std(gray))
        h, w = gray.shape[:2]
        megapixels = (h * w) / 1_000_000.0

        # Normalize into a simple quality score
        blur_score = min(blur / 100.0, 1.0) * 40  # sharper = better
        bright_score = max(0, 1 - abs(brightness - 128) / 128) * 25
        contrast_score = min(contrast / 70.0, 1.0) * 25
        res_score = min(megapixels / 1.5, 1.0) * 10
        score = round(blur_score + bright_score + contrast_score + res_score, 1)

        if blur < 40:
            sharpness = "blurry"
        elif blur < 100:
            sharpness = "acceptable"
        else:
            sharpness = "sharp"

        if brightness < 60:
            lighting = "dark"
        elif brightness > 190:
            lighting = "overexposed"
        else:
            lighting = "balanced"

        verdict = "excellent" if score >= 75 else "good" if score >= 55 else "fair" if score >= 35 else "poor"
        tips = []
        if sharpness == "blurry":
            tips.append("Image looks soft — try a sharper shot or better focus.")
        if lighting == "dark":
            tips.append("Scene is dark — use more light or edit brightness.")
        if lighting == "overexposed":
            tips.append("Highlights may be blown out — reduce exposure.")
        if contrast < 35:
            tips.append("Low contrast — a slight edit could help.")

        return {
            "score": score,
            "blur_variance": round(blur, 2),
            "brightness": round(brightness, 2),
            "contrast": round(contrast, 2),
            "width": int(w),
            "height": int(h),
            "sharpness": sharpness,
            "lighting": lighting,
            "verdict": verdict,
            "tips": tips,
        }
    except Exception:
        return _pillow_quality(image_path)


def _pillow_quality(image_path: str) -> dict:
    from PIL import Image, ImageStat
    import statistics

    img = Image.open(image_path).convert("L")
    stat = ImageStat.Stat(img)
    brightness = float(stat.mean[0])
    contrast = float(stat.stddev[0])
    w, h = img.size
    score = round(min(contrast / 70.0, 1.0) * 50 + max(0, 1 - abs(brightness - 128) / 128) * 50, 1)
    return {
        "score": score,
        "blur_variance": None,
        "brightness": round(brightness, 2),
        "contrast": round(contrast, 2),
        "width": w,
        "height": h,
        "sharpness": "unknown",
        "lighting": "dark" if brightness < 60 else "overexposed" if brightness > 190 else "balanced",
        "verdict": "good" if score >= 55 else "fair",
        "tips": [],
    }


def suggest_filter(image_path: str) -> dict:
    """Suggest a simple edit/filter based on lighting/color mood."""
    q = analyze_image_quality(image_path)
    lighting = q.get("lighting")
    if lighting == "dark":
        suggestion = {"filter": "Clarendon", "reason": "Boosts midtones for darker shots"}
    elif lighting == "overexposed":
        suggestion = {"filter": "Ludwig", "reason": "Softens bright highlights"}
    elif (q.get("contrast") or 0) < 40:
        suggestion = {"filter": "Moon", "reason": "Adds contrast and cinematic tone"}
    else:
        suggestion = {"filter": "Juno", "reason": "Warm Kerala-friendly color pop"}
    return {**suggestion, "quality": q}
