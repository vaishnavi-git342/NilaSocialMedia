"""AI Story Ideas based on user's recent posts, mood, and Kerala themes."""
from __future__ import annotations


KERALA_STORY_PROMPTS = [
    "Share a 15s clip of today's Kerala sky",
    "Poll: Putzu or Biryani tonight?",
    "Behind the scenes of your latest photo",
    "Morning filter coffee ritual",
    "Monsoon window view — rain ASMR",
    "Onam memory throwback",
    "One tip for first-time Kerala travellers",
    "Show your favourite local snack",
]


def generate_story_ideas(user_id: int) -> list[str]:
    ideas = list(KERALA_STORY_PROMPTS)
    try:
        from app.models.post import Post
        from app.services.ai_mood import detect_user_mood

        recent = Post.query.filter_by(user_id=user_id).order_by(Post.created_at.desc()).limit(5).all()
        mood = detect_user_mood(user_id)
        if mood == "adventurous":
            ideas.insert(0, "Post a quick trek/waterfall teaser from Wayanad")
        elif mood == "relaxed":
            ideas.insert(0, "Share a calm backwaters sunset story")
        elif mood == "happy":
            ideas.insert(0, "Celebrate a small win from today with a sticker")
        elif mood == "inspired":
            ideas.insert(0, "Show your creative process in 3 slides")

        for p in recent:
            if p.location:
                ideas.insert(0, f"Add a story from {p.location}")
                break
            if p.caption and "#" in p.caption:
                tag = p.caption.split("#")[1].split()[0]
                ideas.insert(0, f"Continue your #{tag} series in Stories")
                break
    except Exception:
        pass

    # unique
    seen = set()
    out = []
    for i in ideas:
        if i not in seen:
            seen.add(i)
            out.append(i)
        if len(out) >= 8:
            break
    return out


def generate_story_caption(image_path: str) -> str:
    from app.services.ai_engine import suggest_image_captions, strip_caption_emojis
    captions = suggest_image_captions(image_path or "", count=1)
    return strip_caption_emojis(captions[0] if captions else "caught in the moment")
