"""AI Mood-Based Feed service.

Returns posts and reels filtered by mood.
Future: use collaborative filtering + mood embeddings for smarter recommendations.
"""
from app.models.post import Post
from app.models.reel import Reel
from app.models.mood import PostMood, Mood
from app.utils.helpers import filter_visible_posts, filter_visible_reels


def get_mood_posts(mood_name: str, limit: int = 12, offset: int = 0) -> list[Post]:
    """Return posts matching a mood. Falls back to recent visible posts if none tagged."""
    mood = Mood.query.filter_by(name=mood_name).first()
    if mood:
        post_ids = (
            PostMood.query
            .filter_by(mood_id=mood.id)
            .with_entities(PostMood.post_id)
            .all()
        )
        post_ids = [pid[0] for pid in post_ids]
        if post_ids:
            return (
                filter_visible_posts(Post.query.filter(Post.id.in_(post_ids)))
                .order_by(Post.created_at.desc())
                .offset(offset)
                .limit(limit)
                .all()
            )
    # Fallback: return recent visible posts
    return (
        filter_visible_posts(Post.query)
        .order_by(Post.created_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )


def get_mood_reels(mood_name: str, limit: int = 10, offset: int = 0) -> list[Reel]:
    """Return reels matching a mood. Falls back to recent visible reels."""
    return (
        filter_visible_reels(Reel.query)
        .order_by(Reel.created_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )


def auto_tag_post_mood(post: Post):
    """Automatically tag a post with a mood based on its caption."""
    from app.services.ai_mood import detect_mood_from_text
    mood_name = detect_mood_from_text(post.caption or "")
    if mood_name:
        mood = Mood.query.filter_by(name=mood_name).first()
        if mood:
            existing = PostMood.query.filter_by(post_id=post.id, mood_id=mood.id).first()
            if not existing:
                link = PostMood(post_id=post.id, mood_id=mood.id)
                from app.extensions import db
                db.session.add(link)
                db.session.commit()
