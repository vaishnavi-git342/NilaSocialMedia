"""Optional READ-ONLY Instagram viewer via instagrapi.

Env:
  INSTAGRAM_LIVE=0  → disabled (default)
  INSTAGRAM_LIVE=1  → enabled (needs INSTAGRAM_USERNAME + INSTAGRAM_PASSWORD)

Only GET-style calls (timeline / user medias). Never like, follow, comment, or upload.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from flask import current_app

logger = logging.getLogger(__name__)

_client = None
_client_error: str | None = None


def is_live_enabled() -> bool:
    try:
        return bool(current_app.config.get("INSTAGRAM_LIVE"))
    except RuntimeError:
        return False


def live_status() -> dict[str, Any]:
    return {
        "enabled": is_live_enabled(),
        "credentials_set": bool(
            current_app.config.get("INSTAGRAM_USERNAME")
            and current_app.config.get("INSTAGRAM_PASSWORD")
        ),
        "library": _instagrapi_available(),
        "error": _client_error,
        "mode": "read_only",
        "logged_in_as": current_app.config.get("INSTAGRAM_USERNAME") or "",
    }


def _instagrapi_available() -> bool:
    try:
        import instagrapi  # noqa: F401

        return True
    except ImportError:
        return False


def _url(val: Any) -> str:
    if val is None:
        return ""
    return str(val)


def _get_client():
    """Login once, reuse session file. Read-only usage only."""
    global _client, _client_error

    if not is_live_enabled():
        _client_error = "INSTAGRAM_LIVE is 0"
        return None
    if not _instagrapi_available():
        _client_error = "instagrapi not installed — run: pip install -r requirements-instagram.txt"
        return None

    username = (current_app.config.get("INSTAGRAM_USERNAME") or "").strip()
    password = (current_app.config.get("INSTAGRAM_PASSWORD") or "").strip()
    if not username or not password:
        _client_error = "Set INSTAGRAM_USERNAME and INSTAGRAM_PASSWORD in .env"
        return None

    if _client is not None:
        return _client

    try:
        from instagrapi import Client
        from instagrapi.exceptions import (
            BadPassword,
            ChallengeRequired,
            LoginRequired,
            TwoFactorRequired,
        )

        session_file = Path(
            current_app.config.get("INSTAGRAM_SESSION_FILE")
            or (Path.cwd() / "instance" / "ig_session.json")
        )
        session_file.parent.mkdir(parents=True, exist_ok=True)

        cl = Client()
        # Slow down a bit to reduce challenge risk
        try:
            cl.delay_range = [1, 3]
        except Exception:
            pass

        logged_in = False
        if session_file.exists():
            try:
                cl.load_settings(session_file)
                cl.login(username, password)
                cl.account_info()  # light check that session works
                logged_in = True
            except Exception:
                cl = Client()
                try:
                    cl.delay_range = [1, 3]
                except Exception:
                    pass

        if not logged_in:
            cl.login(username, password)

        try:
            cl.dump_settings(session_file)
        except Exception:
            pass

        _client = cl
        _client_error = None
        return _client

    except TwoFactorRequired:
        _client_error = (
            "2FA is enabled on this Instagram account. "
            "Disable 2FA temporarily for this demo account, or log in once "
            "outside the app and reuse a session file."
        )
        _client = None
        return None
    except ChallengeRequired:
        _client_error = (
            "Instagram requested a security challenge (email/SMS). "
            "Complete it in the official Instagram app, then retry."
        )
        _client = None
        return None
    except BadPassword:
        _client_error = "Wrong Instagram username or password."
        _client = None
        return None
    except LoginRequired as exc:
        _client_error = f"Login required: {exc}"
        _client = None
        return None
    except Exception as exc:  # noqa: BLE001
        _client_error = str(exc)
        logger.exception("Instagram live login failed")
        _client = None
        return None


def _media_to_card(media) -> dict[str, Any] | None:
    """Normalize instagrapi Media / dict item to a display card."""
    if media is None:
        return None

    # Timeline raw dict shape: {"media_or_ad": {...}} or Media object
    if isinstance(media, dict):
        if "media_or_ad" in media:
            media = media["media_or_ad"]
        elif "media" in media:
            media = media["media"]
        if isinstance(media, dict):
            return _dict_media_to_card(media)
        # else fall through if Media object unwrapped

    user = getattr(media, "user", None)
    username = getattr(user, "username", None) or "instagram"
    full_name = getattr(user, "full_name", None) or username
    profile_pic = ""
    if user is not None:
        profile_pic = _url(getattr(user, "profile_pic_url", "") or "")

    caption = str(getattr(media, "caption_text", None) or "")

    image_url = ""
    for attr in ("thumbnail_url", "image_url"):
        val = getattr(media, attr, None)
        if val:
            image_url = _url(val)
            break
    if not image_url:
        resources = getattr(media, "resources", None) or []
        if resources:
            first = resources[0]
            image_url = _url(
                getattr(first, "thumbnail_url", None)
                or getattr(first, "image_url", None)
                or ""
            )

    media_type = getattr(media, "media_type", 1)
    kind = {1: "photo", 2: "video", 8: "album"}.get(int(media_type or 1), "photo")
    taken = getattr(media, "taken_at", None)
    code = getattr(media, "code", None) or ""

    return {
        "id": str(getattr(media, "pk", "") or getattr(media, "id", "") or ""),
        "username": username,
        "full_name": full_name,
        "profile_pic": profile_pic,
        "caption": caption,
        "image_url": image_url,
        "like_count": int(getattr(media, "like_count", 0) or 0),
        "comment_count": int(getattr(media, "comment_count", 0) or 0),
        "media_type": kind,
        "taken_at": taken.isoformat() if hasattr(taken, "isoformat") else str(taken or ""),
        "code": code,
        "permalink": f"https://www.instagram.com/p/{code}/" if code else "",
    }


def _dict_media_to_card(d: dict) -> dict[str, Any] | None:
    """Parse raw timeline dict media (when Media objects are not returned)."""
    user = d.get("user") or {}
    username = user.get("username") or "instagram"
    full_name = user.get("full_name") or username
    profile_pic = _url(user.get("profile_pic_url") or "")

    caption_obj = d.get("caption") or {}
    if isinstance(caption_obj, dict):
        caption = caption_obj.get("text") or ""
    else:
        caption = str(caption_obj or "")

    image_url = ""
    candidates = d.get("image_versions2", {}).get("candidates") or []
    if candidates:
        image_url = _url(candidates[0].get("url"))
    if not image_url:
        carousel = d.get("carousel_media") or []
        if carousel:
            cands = (carousel[0].get("image_versions2") or {}).get("candidates") or []
            if cands:
                image_url = _url(cands[0].get("url"))

    mt = int(d.get("media_type") or 1)
    kind = {1: "photo", 2: "video", 8: "album"}.get(mt, "photo")
    code = d.get("code") or ""

    return {
        "id": str(d.get("pk") or d.get("id") or ""),
        "username": username,
        "full_name": full_name,
        "profile_pic": profile_pic,
        "caption": caption,
        "image_url": image_url,
        "like_count": int(d.get("like_count") or 0),
        "comment_count": int(d.get("comment_count") or 0),
        "media_type": kind,
        "taken_at": str(d.get("taken_at") or ""),
        "code": code,
        "permalink": f"https://www.instagram.com/p/{code}/" if code else "",
    }


def _extract_timeline_items(raw: Any) -> list:
    """Normalize get_timeline_feed() response across instagrapi versions."""
    if raw is None:
        return []
    if isinstance(raw, list):
        return raw
    if isinstance(raw, dict):
        items = raw.get("feed_items") or raw.get("items") or []
        return list(items)
    # Some versions return an object with feed_items attr
    items = getattr(raw, "feed_items", None) or getattr(raw, "items", None)
    if items:
        return list(items)
    return []


def fetch_timeline_posts(limit: int | None = None) -> dict[str, Any]:
    """Fetch following timeline (view only). Falls back to own posts."""
    if not is_live_enabled():
        return {"ok": False, "posts": [], "error": "INSTAGRAM_LIVE=0 (local mode)"}

    limit = limit or int(current_app.config.get("INSTAGRAM_FEED_LIMIT") or 12)
    cl = _get_client()
    if cl is None:
        return {"ok": False, "posts": [], "error": _client_error or "Login failed"}

    posts: list[dict] = []
    try:
        try:
            raw = cl.get_timeline_feed()
            for item in _extract_timeline_items(raw):
                card = _media_to_card(item)
                if not card or not card.get("id"):
                    continue
                posts.append(card)
                if len(posts) >= limit:
                    break
        except Exception:
            logger.exception("Timeline fetch failed; falling back to own medias")
            posts = []

        if not posts:
            medias = cl.user_medias(cl.user_id, amount=limit)
            for media in medias or []:
                card = _media_to_card(media)
                if card:
                    posts.append(card)

        return {
            "ok": True,
            "posts": posts[:limit],
            "count": len(posts[:limit]),
            "source": "instagram_live",
            "warning": "Read-only unofficial API — educational use only.",
        }
    except Exception as exc:  # noqa: BLE001
        logger.exception("Failed fetching Instagram timeline")
        return {"ok": False, "posts": [], "error": str(exc)}


def fetch_own_posts(limit: int | None = None) -> dict[str, Any]:
    """Fetch the logged-in Instagram account's own posts (view only)."""
    if not is_live_enabled():
        return {"ok": False, "posts": [], "error": "INSTAGRAM_LIVE=0 (local mode)"}

    limit = limit or int(current_app.config.get("INSTAGRAM_FEED_LIMIT") or 12)
    cl = _get_client()
    if cl is None:
        return {"ok": False, "posts": [], "error": _client_error or "Login failed"}

    try:
        medias = cl.user_medias(cl.user_id, amount=limit)
        posts = [c for m in (medias or []) if (c := _media_to_card(m))]
        return {
            "ok": True,
            "posts": posts,
            "count": len(posts),
            "source": "instagram_own",
            "warning": "Read-only unofficial API — educational use only.",
        }
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "posts": [], "error": str(exc)}


def fetch_user_posts(ig_username: str, limit: int | None = None) -> dict[str, Any]:
    """Fetch another Instagram user's public posts (view only)."""
    if not is_live_enabled():
        return {"ok": False, "posts": [], "error": "INSTAGRAM_LIVE=0 (local mode)"}

    ig_username = (ig_username or "").strip().lstrip("@")
    if not ig_username:
        return {"ok": False, "posts": [], "error": "Username required"}

    limit = limit or int(current_app.config.get("INSTAGRAM_FEED_LIMIT") or 12)
    cl = _get_client()
    if cl is None:
        return {"ok": False, "posts": [], "error": _client_error or "Login failed"}

    try:
        user_id = cl.user_id_from_username(ig_username)
        medias = cl.user_medias(user_id, amount=limit)
        posts = [c for m in (medias or []) if (c := _media_to_card(m))]
        return {
            "ok": True,
            "posts": posts,
            "count": len(posts),
            "source": f"instagram_user:{ig_username}",
            "warning": "Read-only unofficial API — educational use only.",
        }
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "posts": [], "error": str(exc)}


def reset_client() -> None:
    """Clear cached client (e.g. after credential change)."""
    global _client, _client_error
    _client = None
    _client_error = None
