"""Festival / seasonal modes for Instagram Pro (Kerala calendar aware)."""
from __future__ import annotations

from datetime import datetime


MODES = {
    "default": {
        "id": "default",
        "name": "Classic",
        "emoji": "✨",
        "theme_class": "",
        "accent": "#0095f6",
        "banner": "Share your moments",
        "stickers": ["✨", "💚", "📷"],
    },
    "onam": {
        "id": "onam",
        "name": "Onam",
        "emoji": "🌸",
        "theme_class": "theme-onam",
        "accent": "#f4a261",
        "banner": "Onam ashamsakal — celebrate with pookalam vibes",
        "stickers": ["🌸", "🪔", "🍌", "💛"],
    },
    "pooram": {
        "id": "pooram",
        "name": "Pooram",
        "emoji": "🥁",
        "theme_class": "theme-pooram",
        "accent": "#e63946",
        "banner": "Pooram pulse — drums, colour, celebration",
        "stickers": ["🥁", "🐘", "🔥", "🎉"],
    },
    "monsoon": {
        "id": "monsoon",
        "name": "Monsoon",
        "emoji": "🌧️",
        "theme_class": "theme-monsoon",
        "accent": "#457b9d",
        "banner": "Monsoon mode — mazha, chai, and misty frames",
        "stickers": ["🌧️", "☔", "🌿", "☕"],
    },
    "christmas": {
        "id": "christmas",
        "name": "Christmas",
        "emoji": "🎄",
        "theme_class": "theme-festive",
        "accent": "#2a9d8f",
        "banner": "Kerala Christmas lights & cake vibes",
        "stickers": ["🎄", "⭐", "🍰"],
    },
}


def detect_seasonal_mode(now: datetime | None = None) -> str:
    """Auto-detect a Kerala-relevant seasonal mode from the calendar."""
    now = now or datetime.utcnow()
    m, d = now.month, now.day
    # Rough windows (educational approximation)
    if m == 8 or (m == 9 and d <= 15):
        return "onam"
    if m == 4 or (m == 5 and d <= 15):
        return "pooram"
    if m in (6, 7):
        return "monsoon"
    if m == 12:
        return "christmas"
    if m in (6, 7, 8, 9) and m not in (8,):  # leftover monsoon feel
        return "monsoon"
    return "default"


def get_mode(mode_id: str | None = None) -> dict:
    if mode_id and mode_id in MODES:
        return MODES[mode_id]
    return MODES[detect_seasonal_mode()]


def list_modes() -> list[dict]:
    return list(MODES.values())
