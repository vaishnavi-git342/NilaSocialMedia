"""Feature flag helpers — super admin controls Instagram Pro capabilities."""
from __future__ import annotations

from typing import Any

from flask_login import current_user

from app.extensions import db
from app.models.feature_flag import FeatureFlag, UserFeatureOverride

# Catalog of controllable Instagram Pro features
FEATURE_CATALOG: list[dict[str, str]] = [
    {"key": "festival", "name": "Festival Mode", "description": "Onam / festival UI themes"},
    {"key": "ai_studio", "name": "AI Studio", "description": "Local AI captions, hashtags, privacy tools"},
    {"key": "mood_feed", "name": "AI Mood Feed", "description": "Mood-based feed page"},
    {"key": "live_instagram", "name": "Live Instagram", "description": "Read-only real Instagram viewer"},
    {"key": "reels", "name": "Reels", "description": "Create and watch reels"},
    {"key": "stories", "name": "Stories", "description": "Create and view stories"},
    {"key": "messages", "name": "Direct Messages", "description": "Private messaging"},
    {"key": "close_friends", "name": "Close Friends", "description": "Close friends list"},
    {"key": "broadcasts", "name": "Broadcast Channels", "description": "Broadcast channels"},
    {"key": "explore", "name": "Explore", "description": "Explore / discover page"},
    {"key": "comment_moderation", "name": "AI Comment Filter", "description": "Auto-filter toxic comments"},
    {"key": "posting", "name": "Create Posts", "description": "Upload new posts"},
]


def ensure_feature_flags() -> None:
    """Create missing catalog rows (all enabled by default)."""
    existing = {f.key for f in FeatureFlag.query.all()}
    added = False
    for item in FEATURE_CATALOG:
        if item["key"] not in existing:
            db.session.add(
                FeatureFlag(
                    key=item["key"],
                    name=item["name"],
                    description=item["description"],
                    enabled=True,
                )
            )
            added = True
    if added:
        db.session.commit()


def feature_enabled(key: str, user=None) -> bool:
    """Resolve feature: user override → global flag → default True."""
    if user is None:
        try:
            if current_user.is_authenticated:
                user = current_user
        except Exception:
            user = None

    # Super admins always see features (so they can manage the app)
    if user is not None and getattr(user, "is_super_admin", False):
        # Still respect global for live_instagram? No — super admin bypasses for admin UX
        # Actually for live_instagram we also need INSTAGRAM_LIVE env — checked separately
        pass

    if user is not None and getattr(user, "id", None):
        override = UserFeatureOverride.query.filter_by(
            user_id=user.id, feature_key=key
        ).first()
        if override is not None:
            return bool(override.enabled)

    flag = FeatureFlag.query.filter_by(key=key).first()
    if flag is not None:
        return bool(flag.enabled)
    return True


def features_for_user(user=None) -> dict[str, bool]:
    """Map of all catalog keys → enabled for this user."""
    return {item["key"]: feature_enabled(item["key"], user=user) for item in FEATURE_CATALOG}


def set_global_feature(key: str, enabled: bool) -> FeatureFlag | None:
    flag = FeatureFlag.query.filter_by(key=key).first()
    if not flag:
        meta = next((c for c in FEATURE_CATALOG if c["key"] == key), None)
        if not meta:
            return None
        flag = FeatureFlag(key=key, name=meta["name"], description=meta["description"])
        db.session.add(flag)
    flag.enabled = bool(enabled)
    db.session.commit()
    return flag


def set_user_feature(user_id: int, key: str, enabled: bool | None) -> None:
    """Set per-user override. Pass enabled=None to clear override (use global)."""
    row = UserFeatureOverride.query.filter_by(user_id=user_id, feature_key=key).first()
    if enabled is None:
        if row:
            db.session.delete(row)
            db.session.commit()
        return
    if row is None:
        row = UserFeatureOverride(user_id=user_id, feature_key=key, enabled=bool(enabled))
        db.session.add(row)
    else:
        row.enabled = bool(enabled)
    db.session.commit()


def catalog_with_status() -> list[dict[str, Any]]:
    ensure_feature_flags()
    flags = {f.key: f for f in FeatureFlag.query.all()}
    out = []
    for item in FEATURE_CATALOG:
        flag = flags.get(item["key"])
        out.append(
            {
                **item,
                "enabled": bool(flag.enabled) if flag else True,
                "flag_id": flag.id if flag else None,
            }
        )
    return out


def user_overrides_map(user_id: int) -> dict[str, bool]:
    rows = UserFeatureOverride.query.filter_by(user_id=user_id).all()
    return {r.feature_key: bool(r.enabled) for r in rows}
