"""AI Music Recommender — mood + Kerala-themed local track lists."""

MOOD_MUSIC = {
    "happy": ["Malabar Beats", "Onam Dance Mix", "Good Vibes Kerala"],
    "sad": ["Monsoon Window Rain", "Quiet Kayal Nights", "Soft Violin - Kerala"],
    "energetic": ["Chenda Melam Vibes", "Pooram Pulse", "Temple Festival Drums"],
    "relaxed": ["Kerala Rain Ambience", "Backwater Drift", "Sunset Lover - Soft"],
    "inspired": ["Mountain Breeze - Munnar", "Tea Estate Morning", "Western Ghats Air"],
    "adventurous": ["Wayanad Trail", "Cliff Wind - Varkala", "Forest Trek Loops"],
    "romantic": ["Arabian Sea Waves", "Varkala Golden Hour", "Houseboat Lanterns"],
    "nostalgic": ["Old Kochi Alleys", "Thiruvananthapuram Nights", "Cassette Rain"],
}


def recommend_music_for_mood(mood_name: str, count: int = 3) -> list[str]:
    return MOOD_MUSIC.get(mood_name, MOOD_MUSIC["happy"])[:count]


def recommend_music_for_reel(caption: str = "", mood: str = "", image_path: str = "") -> list[str]:
    if not mood and caption:
        from app.services.ai_mood import detect_mood_from_text
        mood = detect_mood_from_text(caption) or "happy"
    if not mood and image_path:
        try:
            from app.services.ai_vision import zero_shot_classify
            tags = zero_shot_classify(image_path, top_k=1)
            label = (tags[0]["label"] if tags else "").lower()
            if "beach" in label or "sunset" in label:
                mood = "romantic"
            elif "festival" in label or "temple" in label:
                mood = "energetic"
            elif "forest" in label or "mountain" in label:
                mood = "adventurous"
            else:
                mood = "relaxed"
        except Exception:
            mood = "relaxed"
    return recommend_music_for_mood(mood or "happy")
