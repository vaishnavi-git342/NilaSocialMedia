"""Smart reply suggestions for comments / DMs (local template + context)."""
from __future__ import annotations

import re


TEMPLATES = {
    "praise": [
        "Thank you so much! 🙏",
        "Glad you liked it!",
        "Means a lot, thank you!",
        "Nanni! Appreciate you 💚",
    ],
    "question": [
        "Great question — I'll share more soon!",
        "It was in Kerala — happy to tell you more!",
        "Thanks for asking! Dropping details in my next post.",
    ],
    "travel": [
        "You should visit — God's Own Country never disappoints!",
        "Kerala monsoon hits different 🌧️",
        "Add this to your travel list!",
    ],
    "food": [
        "Kerala flavours hit different 🍽️",
        "You need to try this next time!",
        "Homemade vibes only!",
    ],
    "default": [
        "Thank you!",
        "Appreciate it 🙌",
        "Thanks for stopping by!",
        "Love this energy!",
    ],
}


def suggest_replies(comment_text: str, post_caption: str = "", count: int = 4) -> list[str]:
    text = f"{comment_text} {post_caption}".lower()
    bucket = "default"

    if any(w in text for w in ("?", "where", "how", "which", "what", "when")):
        bucket = "question"
    elif any(w in text for w in ("beautiful", "amazing", "stunning", "love", "wow", "fire", "awesome", "super")):
        bucket = "praise"
    elif any(w in text for w in ("kerala", "munnar", "beach", "travel", "trip", "backwater", "trek")):
        bucket = "travel"
    elif any(w in text for w in ("food", "biryani", "sadya", "tasty", "yummy", "recipe")):
        bucket = "food"

    replies = list(TEMPLATES.get(bucket, TEMPLATES["default"]))

    # Personalize lightly
    if "kerala" in text and bucket != "travel":
        replies.insert(0, "Kerala magic never gets old ✨")

    # Dedupe preserve order
    seen = set()
    out = []
    for r in replies:
        if r not in seen:
            seen.add(r)
            out.append(r)
        if len(out) >= count:
            break
    return out
