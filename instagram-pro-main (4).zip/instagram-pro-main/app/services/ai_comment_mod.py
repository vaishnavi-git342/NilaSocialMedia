"""AI comment moderation — detect and remove unwanted Instagram-style comments."""
from __future__ import annotations

import re

from app.services.ai_toxicity import toxicity_score, is_toxic
from app.services.ai_spam import spam_score, is_spam


# Extra unwanted patterns (harassment, scams, self-promo dumps)
UNWANTED_PATTERNS = [
    r"\b(kill\s*yourself|kys)\b",
    r"\b(go\s*die|die\s*bitch)\b",
    r"\b(slut|whore|rape)\b",
    r"\b(nigger|nigga)\b",
    r"\b(send\s*nudes?|nudes?\s*pls)\b",
    r"\b(onlyfans|telegram\.me|t\.me/)\b",
    r"\b(crypto\s*airdrop|free\s*nft)\b",
    r"\b(dm\s*me\s*for\s*(sex|promo|followers))\b",
    r"(.)\1{8,}",  # aaaaaaaaa
]


def _unwanted_hits(text: str) -> list[str]:
    lower = (text or "").lower()
    hits = []
    for p in UNWANTED_PATTERNS:
        if re.search(p, lower, flags=re.IGNORECASE):
            hits.append(p)
    return hits


def moderate_comment(text: str) -> dict:
    """
    Score a comment and decide action: allow | reject.
    Reject = do not save / delete if already saved.
    """
    body = (text or "").strip()
    if not body:
        return {
            "action": "reject",
            "reason": "empty",
            "message": "Comment can't be empty.",
            "toxicity": 0.0,
            "spam": 0.0,
            "score": 1.0,
        }

    tox = toxicity_score(body)
    spam = spam_score(body)
    hits = _unwanted_hits(body)
    severe = bool(hits) or is_toxic(body)

    # Combined risk 0..1
    score = min(1.0, tox * 0.55 + spam * 0.35 + (0.5 if hits else 0.0) + (0.25 if severe else 0.0))

    reasons = []
    if tox >= 0.35 or is_toxic(body):
        reasons.append("offensive language")
    if spam >= 0.5 or is_spam(body):
        reasons.append("spam / promo")
    if hits:
        reasons.append("harassment or policy violation")

    if score >= 0.45 or severe or is_spam(body, 0.55):
        label = ", ".join(reasons) or "community guidelines"
        return {
            "action": "reject",
            "reason": label,
            "message": f"Comment removed by AI moderation ({label}).",
            "toxicity": round(tox, 3),
            "spam": round(spam, 3),
            "score": round(score, 3),
            "reasons": reasons,
        }

    return {
        "action": "allow",
        "reason": "ok",
        "message": "Looks fine.",
        "toxicity": round(tox, 3),
        "spam": round(spam, 3),
        "score": round(score, 3),
        "reasons": [],
    }


def should_delete_comment(text: str) -> bool:
    return moderate_comment(text)["action"] == "reject"
