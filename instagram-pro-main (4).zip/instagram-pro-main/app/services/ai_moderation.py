"""AI Content Moderation service.

Combines NSFW, spam, and toxicity detection for comprehensive moderation.
"""


def moderate_content(text: str, image_path: str = None) -> dict:
    """Return a moderation report for content."""
    from app.services.ai_nsfw import is_nsfw, nsfw_score
    from app.services.ai_spam import is_spam, spam_score
    from app.services.ai_toxicity import is_toxic, toxicity_score

    report = {
        "is_safe": True,
        "spam": is_spam(text) if text else False,
        "toxic": is_toxic(text) if text else False,
        "nsfw": is_nsfw(image_path) if image_path else False,
        "spam_score": spam_score(text) if text else 0.0,
        "toxicity_score": toxicity_score(text) if text else 0.0,
        "nsfw_score": nsfw_score(image_path) if image_path else 0.0,
    }
    report["is_safe"] = not (report["spam"] or report["toxic"] or report["nsfw"])
    return report


def should_flag_content(text: str, image_path: str = None) -> bool:
    """Return True if content should be flagged for review."""
    report = moderate_content(text, image_path)
    return not report["is_safe"]
