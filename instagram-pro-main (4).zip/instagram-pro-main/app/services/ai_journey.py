"""Travel Companion / Journey Maps from stories & posts with locations."""
from __future__ import annotations

from collections import OrderedDict
from datetime import datetime, timedelta


# Canonical journey stop order for Kerala coastal/hill circuits
KNOWN_STOPS = [
    "Thiruvananthapuram", "Kovalam", "Varkala", "Kollam", "Alappuzha", "Allepppey",
    "Kottayam", "Kochi", "Fort Kochi", "Thrissur", "Palakkad", "Malappuram",
    "Kozhikode", "Calicut", "Wayanad", "Kannur", "Kasargod", "Munnar", "Thekkady",
    "Athirappilly", "Idukki",
]


def _normalize_place(location: str) -> str:
    if not location:
        return ""
    loc = location.strip()
    # Prefer longer place names first (Fort Kochi before Kochi)
    for stop in sorted(KNOWN_STOPS, key=len, reverse=True):
        if stop.lower() in loc.lower():
            return stop
    # first token before comma
    return loc.split(",")[0].strip()


def build_journey_map(user_id: int, days: int = 14) -> dict:
    """Build an ordered journey from recent geo-tagged posts and stories."""
    from app.models.post import Post
    from app.models.story import Story

    try:
        days = int(days)
    except (TypeError, ValueError):
        days = 14
    days = max(1, min(days, 90))
    cutoff = datetime.utcnow() - timedelta(days=days)
    stops = OrderedDict()

    posts = (
        Post.query.filter(Post.user_id == user_id, Post.created_at >= cutoff, Post.location.isnot(None))
        .order_by(Post.created_at.asc())
        .all()
    )
    for p in posts:
        place = _normalize_place(p.location)
        if not place:
            continue
        entry = stops.setdefault(place, {"place": place, "posts": [], "stories": [], "first_seen": p.created_at})
        entry["posts"].append({"id": p.id, "caption": (p.caption or "")[:80], "at": p.created_at.isoformat()})

    stories = (
        Story.query.filter(Story.user_id == user_id, Story.created_at >= cutoff)
        .order_by(Story.created_at.asc())
        .all()
    )
    for s in stories:
        # stories may encode place in caption
        place = _normalize_place(s.caption or "")
        if not place:
            continue
        entry = stops.setdefault(place, {"place": place, "posts": [], "stories": [], "first_seen": s.created_at})
        entry["stories"].append({"id": s.id, "caption": (s.caption or "")[:80], "at": s.created_at.isoformat()})

    path = list(stops.keys())
    return {
        "user_id": user_id,
        "days": days,
        "stop_count": len(path),
        "path": path,
        "stops": list(stops.values()),
        "title": " → ".join(path) if path else "No journey yet — add locations to posts!",
        "suggestion": _suggest_next(path),
    }


def _suggest_next(path: list[str]) -> str | None:
    if not path:
        return "Start with Fort Kochi or Varkala and tag locations on your posts."
    last = path[-1]
    suggestions = {
        "Kochi": "Next stop idea: Alappuzha backwaters",
        "Fort Kochi": "Next stop idea: sail toward Alappuzha",
        "Alappuzha": "Next stop idea: climb to Munnar tea hills",
        "Allepppey": "Next stop idea: Munnar",
        "Munnar": "Next stop idea: Thekkady wildlife",
        "Varkala": "Next stop idea: Kovalam or Trivandrum culture",
        "Wayanad": "Next stop idea: Kozhikode coast",
        "Kozhikode": "Next stop idea: Wayanad forests",
        "Thrissur": "Next stop idea: Athirappilly waterfalls",
    }
    for key, tip in suggestions.items():
        if key.lower() in last.lower():
            return tip
    return "Keep tagging Kerala places to grow your travel map."
