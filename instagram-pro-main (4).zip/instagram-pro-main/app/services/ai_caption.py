"""AI Caption Generator — uses local BLIP via ai_engine."""
from app.services.ai_engine import (
    generate_image_caption,
    suggest_image_captions,
)


def generate_caption(image_path: str) -> str:
    return generate_image_caption(image_path or "")


def suggest_captions(image_path: str, count: int = 3) -> list[str]:
    return suggest_image_captions(image_path or "", count=count)
