"""AI Mood Detection service.

Analyzes user activity, captions, and interactions to detect mood.
Returns a mood that can be used to personalize the feed.
Future: use NLP sentiment analysis on user's recent captions/comments.
"""

MOOD_KEYWORDS = {
    "happy": ["happy", "joy", "excited", "love", "amazing", "great", "fun", "smile", "laugh", "wonderful", "beautiful", "celebrate", "onam", "sadya", "festival"],
    "sad": ["sad", "lonely", "cry", "miss", "broken", "hurt", "alone", "tears", "gone", "lost", "empty"],
    "energetic": ["energy", "workout", "run", "gym", "active", "sport", "fitness", "strong", "power", "move", "dance", "pooram", "chenda"],
    "relaxed": ["calm", "chill", "relax", "peace", "quiet", "cozy", "rest", "coffee", "book", "nature", "sunset", "backwaters", "houseboat", "ayurveda"],
    "inspired": ["inspire", "create", "art", "design", "idea", "dream", "goal", "future", "motivation", "passion", "mist", "tea", "munnar"],
    "adventurous": ["adventure", "travel", "explore", "hike", "mountain", "beach", "road", "trip", "journey", "discover", "wayanad", "trek", "western"],
    "romantic": ["love", "romantic", "date", "couple", "together", "valentine", "heart", "kiss", "sweet", "varkala", "cliff"],
    "nostalgic": ["memories", "throwback", "old", "remember", "childhood", "back", "those days", "miss", "heritage", "temple"],
}


def detect_mood_from_text(text: str) -> str | None:
    """Detect mood from a piece of text (caption, comment, etc.)."""
    if not text:
        return None
    text_lower = text.lower()
    scores = {}
    for mood, keywords in MOOD_KEYWORDS.items():
        scores[mood] = sum(1 for kw in keywords if kw in text_lower)
    best = max(scores, key=scores.get) if scores else None
    return best if scores.get(best, 0) > 0 else None


def detect_user_mood(user_id: int) -> str:
    """Detect a user's mood from their recent activity."""
    from app.models.post import Post
    from app.models.comment import Comment

    recent_posts = Post.query.filter_by(user_id=user_id).order_by(Post.created_at.desc()).limit(5).all()
    recent_comments = Comment.query.filter_by(user_id=user_id).order_by(Comment.created_at.desc()).limit(5).all()

    all_text = " ".join([p.caption or "" for p in recent_posts] + [c.body or "" for c in recent_comments])
    mood = detect_mood_from_text(all_text)
    return mood or "happy"


def get_mood_color(mood_name: str) -> str:
    """Return a color for a mood."""
    colors = {
        "happy": "#FFD700",
        "sad": "#6495ED",
        "energetic": "#FF4500",
        "relaxed": "#90EE90",
        "inspired": "#9370DB",
        "adventurous": "#20B2AA",
        "romantic": "#FF69B4",
        "nostalgic": "#DAA520",
    }
    return colors.get(mood_name, "#0095f6")


def get_mood_emoji(mood_name: str) -> str:
    """Return an emoji for a mood."""
    emojis = {
        "happy": "😊",
        "sad": "😢",
        "energetic": "⚡",
        "relaxed": "😌",
        "inspired": "✨",
        "adventurous": "🏔️",
        "romantic": "❤️",
        "nostalgic": "📷",
    }
    return emojis.get(mood_name, "😊")
