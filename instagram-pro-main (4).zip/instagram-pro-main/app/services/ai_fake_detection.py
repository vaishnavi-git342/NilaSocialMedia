"""Local fake-account risk scoring from profile / activity signals."""
from __future__ import annotations


def fake_account_score(user_id: int) -> float:
    """Heuristic risk score 0..1 (higher = more suspicious)."""
    from app.models.user import User
    from app.models.post import Post
    from app.models.follow import Follow

    user = User.query.get(user_id)
    if not user:
        return 1.0

    score = 0.0
    profile = user.profile

    if not profile or not profile.bio:
        score += 0.15
    if not profile or not profile.profile_photo:
        score += 0.2
    if not user.email_verified:
        score += 0.1

    posts = Post.query.filter_by(user_id=user_id).count()
    followers = Follow.query.filter_by(followed_id=user_id, accepted=True).count()
    following = Follow.query.filter_by(follower_id=user_id, accepted=True).count()

    if posts == 0:
        score += 0.15
    if following > 50 and followers < 5:
        score += 0.25
    if following > 0 and followers / max(following, 1) < 0.05 and following > 30:
        score += 0.2

    # Very new account with mass following
    from datetime import datetime, timedelta
    if user.created_at and user.created_at > datetime.utcnow() - timedelta(days=1) and following > 20:
        score += 0.25

    return min(1.0, score)


def is_fake_account(user_id: int, threshold: float = 0.65) -> bool:
    return fake_account_score(user_id) >= threshold
