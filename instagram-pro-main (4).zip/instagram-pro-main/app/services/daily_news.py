"""Refresh a small daily news list from a public RSS feed."""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from email.utils import parsedate_to_datetime
from html import unescape
from urllib.request import Request, urlopen

from app.extensions import db
from app.models.news import NewsItem

FEED_URL = "https://www.thehindu.com/news/national/kerala/feeder/default.rss"
SOURCE = "The Hindu"
MAX_ITEMS = 12


def _plain(value: str) -> str:
    text = unescape(value or "")
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _parse_date(value: str | None):
    if not value:
        return None
    try:
        return parsedate_to_datetime(value).replace(tzinfo=None)
    except Exception:
        return None


def _kerala_items() -> list[NewsItem]:
    return (
        NewsItem.query.filter_by(source=SOURCE)
        .order_by(NewsItem.published_at.desc())
        .limit(MAX_ITEMS)
        .all()
    )


def refresh_news_if_stale(max_age_hours: int = 6) -> list[NewsItem]:
    """Fetch Kerala headlines when the cache is older than max_age_hours."""
    latest = NewsItem.query.filter_by(source=SOURCE).order_by(NewsItem.fetched_at.desc()).first()
    fresh = latest and latest.fetched_at and latest.fetched_at > datetime.utcnow() - timedelta(hours=max_age_hours)
    if fresh:
        return _kerala_items()

    try:
        request = Request(FEED_URL, headers={"User-Agent": "NilaSocial/1.0"})
        with urlopen(request, timeout=8) as response:
            raw = response.read()
        root = ET.fromstring(raw)
    except Exception:
        return _kerala_items()

    now = datetime.utcnow()
    parsed = []
    for item in root.findall("./channel/item")[:MAX_ITEMS]:
        title = _plain(item.findtext("title") or "")
        link = (item.findtext("link") or "").strip()
        summary = _plain(item.findtext("description") or "")
        if not title or not link:
            continue
        parsed.append((title, link, summary, _parse_date(item.findtext("pubDate")) or now))
    if not parsed:
        return _kerala_items()

    NewsItem.query.delete()
    for title, link, summary, published in parsed:
        db.session.add(NewsItem(
            url=link[:500],
            title=title[:300],
            summary=summary[:500],
            source=SOURCE,
            published_at=published,
            fetched_at=now,
        ))
    db.session.commit()
    return _kerala_items()
