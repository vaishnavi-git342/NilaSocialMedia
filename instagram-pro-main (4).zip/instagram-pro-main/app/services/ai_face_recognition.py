"""Local face detection using OpenCV Haar cascades."""
from app.services.ai_vision import detect_faces_opencv


def detect_faces(image_path: str) -> list[dict]:
    return detect_faces_opencv(image_path or "")


def recognize_faces(image_path: str, known_faces: dict | None = None) -> list[dict]:
    """Detect faces; recognition against known embeddings is not enabled locally yet."""
    faces = detect_faces(image_path)
    for f in faces:
        f["identity"] = "unknown"
    return faces


def face_count(image_path: str) -> int:
    return len(detect_faces(image_path))
