"""Local NSFW detection via CLIP zero-shot classification."""
from app.services.ai_vision import nsfw_probability


def nsfw_score(image_path: str) -> float:
    if not image_path:
        return 0.0
    return float(nsfw_probability(image_path))


def is_nsfw(image_path: str, threshold: float = 0.55) -> bool:
    return nsfw_score(image_path) >= threshold
