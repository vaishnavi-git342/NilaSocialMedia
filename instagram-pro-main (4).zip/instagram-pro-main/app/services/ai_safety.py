"""Community Safety Score with explainable reasons."""
from __future__ import annotations

from app.services.ai_moderation import moderate_content
from app.services.ai_spam import spam_score
from app.services.ai_toxicity import toxicity_score, is_toxic
from app.services.ai_nsfw import nsfw_score


def community_safety_score(text: str = "", image_path: str = "") -> dict:
    """Return 0..100 safety score with human-readable reasons."""
    report = moderate_content(text, image_path or None)
    s_spam = spam_score(text) if text else 0.0
    s_tox = toxicity_score(text) if text else 0.0
    s_nsfw = nsfw_score(image_path) if image_path else 0.0

    # Start safe, subtract weighted risks
    score = 100.0
    reasons = []
    deductions = []

    if s_spam >= 0.5:
        cut = min(35, s_spam * 40)
        score -= cut
        deductions.append({"type": "spam", "points": round(cut, 1), "detail": "Promotional / repetitive / link-heavy language detected"})
    elif s_spam >= 0.25:
        cut = s_spam * 20
        score -= cut
        deductions.append({"type": "spam", "points": round(cut, 1), "detail": "Mild spam signals (hashtags or promo tone)"})

    if s_tox >= 0.35 or is_toxic(text or ""):
        cut = min(40, max(20, s_tox * 45))
        score -= cut
        deductions.append({"type": "toxicity", "points": round(cut, 1), "detail": "Potentially offensive or abusive language"})
    elif s_tox > 0:
        cut = s_tox * 15
        score -= cut
        deductions.append({"type": "toxicity", "points": round(cut, 1), "detail": "Slightly harsh wording"})

    if s_nsfw >= 0.55:
        cut = min(45, s_nsfw * 50)
        score -= cut
        deductions.append({"type": "nsfw", "points": round(cut, 1), "detail": "Visual content may violate community guidelines"})
    elif s_nsfw >= 0.35:
        cut = s_nsfw * 20
        score -= cut
        deductions.append({"type": "nsfw", "points": round(cut, 1), "detail": "Borderline visual sensitivity"})

    score = max(0, min(100, round(score, 1)))
    if score >= 85:
        band = "safe"
        summary = "Looks community-safe to post."
    elif score >= 60:
        band = "review"
        summary = "Mostly okay — review flagged items before posting."
    else:
        band = "risky"
        summary = "High risk of being flagged — revise caption or media."

    if not deductions:
        reasons.append("No spam, toxicity, or NSFW signals detected.")
    else:
        reasons = [d["detail"] for d in deductions]

    return {
        "score": score,
        "band": band,
        "summary": summary,
        "reasons": reasons,
        "deductions": deductions,
        "raw": {
            "spam_score": round(s_spam, 3),
            "toxicity_score": round(s_tox, 3),
            "nsfw_score": round(s_nsfw, 3),
            "is_safe": report.get("is_safe", True),
        },
    }
