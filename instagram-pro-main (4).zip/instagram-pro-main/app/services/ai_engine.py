"""Local AI engine using Salesforce BLIP (Hugging Face Transformers).

Model: Salesforce/blip-image-captioning-base
GitHub / HF: https://huggingface.co/Salesforce/blip-image-captioning-base
Used by projects such as abdulsamad00529/image-caption-ai and AutoTag-AI.

Lazy-loads once, runs on CPU (GPU if available). Falls back to rule-based
Kerala-themed captions/hashtags when torch/transformers are not installed.
"""
from __future__ import annotations

import os
import re
import threading
from functools import lru_cache
from typing import Any

# Soft import — app still runs without AI deps
_torch = None
_transformers = None
_model = None
_processor = None
_device = "cpu"
_load_error: str | None = None
_lock = threading.Lock()

BLIP_MODEL_ID = "Salesforce/blip-image-captioning-base"

KERALA_HASHTAGS = [
    "#kerala", "#godowncountry", "#keralatourism", "#malayalam", "#kochi",
    "#munnar", "#alleppey", "#backwaters", "#wayanad", "#varkala",
    "#malabar", "#onam", "#sadya", "#ayurveda", "#monsoon",
    "#teaestate", "#houseboat", "#keraladiaries", "#incredibleindia",
]

CATEGORY_TAGS = {
    "beach": ["#beach", "#seaside", "#ocean", "#sunset", "#travel"],
    "nature": ["#nature", "#green", "#forest", "#hills", "#outdoors"],
    "food": ["#food", "#foodie", "#keralafood", "#homecooked", "#delicious"],
    "temple": ["#temple", "#culture", "#heritage", "#spiritual", "#india"],
    "tea": ["#tea", "#teagarden", "#munnar", "#plantation", "#hills"],
    "water": ["#backwaters", "#houseboat", "#lake", "#boat", "#peaceful"],
    "city": ["#citylife", "#street", "#urban", "#kochi", "#explore"],
    "people": ["#portrait", "#people", "#smile", "#lifestyle", "#mood"],
}


def _try_imports() -> bool:
    global _torch, _transformers, _load_error
    if _torch is not None and _transformers is not None:
        return True
    try:
        os.environ["USE_TF"] = "0"
        os.environ["TRANSFORMERS_NO_TF"] = "1"
        os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
        import torch as _t
        import transformers as _tr
        _torch = _t
        _transformers = _tr
        return True
    except Exception as exc:  # noqa: BLE001
        _load_error = str(exc)
        return False


def is_ai_available() -> bool:
    return _try_imports()


def get_ai_status() -> dict[str, Any]:
    available = _try_imports()
    return {
        "available": available,
        "model": BLIP_MODEL_ID if available else None,
        "device": _device if available else None,
        "loaded": _model is not None,
        "error": _load_error,
    }


def _ensure_model():
    """Lazy-load BLIP once (thread-safe)."""
    global _model, _processor, _device, _load_error
    if _model is not None:
        return True
    if not _try_imports():
        return False
    with _lock:
        if _model is not None:
            return True
        try:
            from transformers import BlipProcessor, BlipForConditionalGeneration

            _device = "cuda" if _torch.cuda.is_available() else "cpu"
            _processor = BlipProcessor.from_pretrained(BLIP_MODEL_ID)
            _model = BlipForConditionalGeneration.from_pretrained(BLIP_MODEL_ID)
            _model.to(_device)
            _model.eval()
            return True
        except Exception as exc:  # noqa: BLE001
            _load_error = str(exc)
            _model = None
            _processor = None
            return False


def _open_image(image_path: str):
    from PIL import Image
    img = Image.open(image_path).convert("RGB")
    # Downscale for faster CPU inference
    img.thumbnail((512, 512))
    return img


_EMOJI_RE = re.compile(
    "["
    "\U0001F300-\U0001FAFF"
    "\U00002700-\U000027BF"
    "\U0001F1E0-\U0001F1FF"
    "\U00002600-\U000026FF"
    "\U0000FE0F"
    "]+",
    flags=re.UNICODE,
)


def strip_caption_emojis(text: str) -> str:
    """Remove emojis from user-facing captions (Instagram-style text only)."""
    cleaned = _EMOJI_RE.sub("", text or "")
    return re.sub(r"\s{2,}", " ", cleaned).strip()


def generate_image_caption(image_path: str) -> str:
    """One natural caption that describes this image. Nothing is stored here."""
    return suggest_image_captions(image_path, count=1)[0]


def _describe_image(image_path: str) -> str:
    """Internal BLIP/fallback description used only to pick a caption vibe."""
    if image_path and os.path.isfile(image_path) and _ensure_model():
        try:
            image = _open_image(image_path)
            inputs = _processor(images=image, return_tensors="pt").to(_device)
            with _torch.no_grad():
                out = _model.generate(**inputs, max_new_tokens=40)
            caption = _processor.decode(out[0], skip_special_tokens=True).strip()
            if caption:
                return strip_caption_emojis(_kerala_flavor_caption(caption))
        except Exception as exc:  # noqa: BLE001
            _load_error = str(exc)
    return strip_caption_emojis(_fallback_caption(image_path))


def _caption_vibe(description: str, image_path: str = "") -> str:
    text = f"{description} {os.path.basename(image_path or '')}".lower()
    if any(k in text for k in ("beach", "sea", "coast", "varkala", "kovalam", "sunset")):
        return "coast"
    if any(k in text for k in ("tea", "munnar", "hill", "mountain", "mist", "cloud")):
        return "hills"
    if any(k in text for k in ("boat", "backwater", "houseboat", "alleppey", "alappuzha", "canal")):
        return "backwaters"
    if any(k in text for k in ("food", "dosa", "biryani", "meal", "sadya", "chai", "coffee")):
        return "food"
    if any(k in text for k in ("temple", "festival", "pooram", "onam", "drum")):
        return "festive"
    if any(k in text for k in ("rain", "monsoon", "forest", "waterfall", "trail")):
        return "monsoon"
    if any(k in text for k in ("city", "street", "kochi", "fort")):
        return "city"
    return "moment"


# Stylish Instagram-like lines — vibe, not alt-text.
_STYLISH_BY_VIBE: dict[str, list[str]] = {
    "coast": [
        "salt air and slower thoughts",
        "golden hour did the work",
        "somewhere between waves and quiet",
        "kept this light for later",
    ],
    "hills": [
        "higher up, quieter mind",
        "green on green on green",
        "mist over everything that matters",
        "tea country, soft pace",
    ],
    "backwaters": [
        "drifting, on purpose",
        "water like glass today",
        "slow boat, soft sky",
        "this pace feels right",
    ],
    "food": [
        "worth every bite",
        "comfort on a plate",
        "flavor first, captions second",
        "saving this craving for next time",
    ],
    "festive": [
        "colour, sound, and heart",
        "tradition hits different",
        "living for this energy",
        "culture in full bloom",
    ],
    "monsoon": [
        "rain mood unlocked",
        "petrichor and pause",
        "grey skies, good days",
        "let the weather set the tempo",
    ],
    "city": [
        "city light, soft edges",
        "found this frame on a walk",
        "ordinary streets, better light",
        "another evening worth keeping",
    ],
    "moment": [
        "caught in the moment",
        "this one stays",
        "soft focus, loud feeling",
        "just here for the vibe",
        "little frame, big mood",
        "not staged, just felt",
    ],
}


_CAPTION_STOP = {
    "with", "this", "that", "from", "have", "been", "were", "their", "about",
    "there", "which", "would", "could", "photo", "image", "picture", "scene",
    "view", "looking", "standing", "there", "they", "them", "into", "over",
    "under", "some", "very", "just", "like", "also", "and", "the", "are", "was",
    "taking", "holding", "sitting", "wearing", "making", "going", "using",
}


def _collapse_repeats(text: str) -> str:
    """Drop repeated words and repeated phrases from a model caption."""
    words = re.findall(r"[A-Za-z0-9']+", text or "")
    if not words:
        return ""
    deduped: list[str] = []
    for word in words:
        if deduped and deduped[-1].lower() == word.lower():
            continue
        deduped.append(word)
    changed = True
    while changed and len(deduped) > 4:
        changed = False
        low = [w.lower() for w in deduped]
        for size in range(len(deduped) // 2, 2, -1):
            for i in range(0, len(deduped) - (2 * size) + 1):
                if low[i:i + size] == low[i + size:i + (2 * size)]:
                    del deduped[i + size:i + (2 * size)]
                    changed = True
                    break
            if changed:
                break
    phrase = " ".join(deduped).strip()
    if not phrase:
        return ""
    return phrase[0].upper() + phrase[1:]


def _emoji_for(text: str, faces: int) -> str:
    t = (text or "").lower()
    if faces >= 1 or any(k in t for k in ("selfie", "girl", "boy", "people", "person", "woman", "man", "smile")):
        return "📸"
    if any(k in t for k in ("food", "meal", "plate", "coffee", "cake", "fruit")):
        return "🍽️"
    if any(k in t for k in ("beach", "sea", "ocean", "sunset", "wave")):
        return "🌊"
    if any(k in t for k in ("flower", "garden", "tree", "forest", "mountain")):
        return "🌿"
    if any(k in t for k in ("dog", "cat", "bird", "animal")):
        return "🐾"
    if any(k in t for k in ("city", "street", "building", "night")):
        return "🌃"
    return "✨"


def _natural_caption(description: str, faces: int) -> str:
    sentence = _collapse_repeats(description)
    if not sentence or sentence.lower() in {"everyday moment outdoors", "a moment"}:
        if faces >= 2:
            sentence = f"{faces} people together"
        elif faces == 1:
            sentence = "A portrait"
        else:
            sentence = "A photo worth keeping"
    sentence = sentence.rstrip(".")
    emoji = _emoji_for(sentence, faces)
    if emoji not in sentence:
        sentence = f"{sentence} {emoji}"
    return sentence


def suggest_image_captions(image_path: str, count: int = 3) -> list[str]:
    """Fresh captions from this image only. Results are not saved until the user posts."""
    description = _describe_image(image_path)
    faces = 0
    try:
        from app.services.ai_vision import detect_faces_opencv
        faces = len(detect_faces_opencv(image_path or "") or [])
    except Exception:
        faces = 0
    primary = _natural_caption(description, faces)
    short = _collapse_repeats(description)
    if short and not short.endswith((".", "!", "?")):
        short = short[:90].rstrip()
    variants = [
        primary,
        f"{short} {_emoji_for(short or description, faces)}".strip() if short else primary,
        primary.replace("  ", " "),
    ]
    seen: set[str] = set()
    result: list[str] = []
    for line in variants:
        key = re.sub(r"\s+", " ", (line or "").lower()).strip()
        if not key or key in seen:
            continue
        seen.add(key)
        result.append(re.sub(r"\s+", " ", line).strip())
        if len(result) >= count:
            break
    return result or ["A photo worth keeping ✨"]


def generate_hashtags_from_image(image_path: str, caption: str = "", count: int = 8) -> list[str]:
    """Hashtags from what is actually in the image. Place names only if mentioned."""
    description = caption or ""
    if image_path and os.path.isfile(image_path):
        seen_desc = _describe_image(image_path)
        if seen_desc:
            description = f"{seen_desc} {description}".strip()

    clip_bits: list[str] = []
    try:
        from app.services.ai_vision import zero_shot_classify
        generic = ["people", "a selfie", "food", "a beach", "nature", "a city street", "an animal", "flowers", "a portrait"]
        for tag in zero_shot_classify(image_path or "", labels=generic, top_k=4) or []:
            if float(tag.get("score") or 0) < 0.18:
                continue
            clip_bits.append(str(tag.get("label") or ""))
    except Exception:
        clip_bits = []

    text = f"{description} {' '.join(clip_bits)}".lower()
    tags: list[str] = []
    words = re.findall(r"[a-zA-Z]{4,}", text)
    for word in words:
        if word in _CAPTION_STOP:
            continue
        tags.append(f"#{word}")

    for cat, cat_tags in CATEGORY_TAGS.items():
        if cat in text:
            tags.extend(cat_tags[:3])

    # Places are included only when the image description actually mentions them.
    for place in ("kochi", "munnar", "varkala", "kovalam", "alleppey", "wayanad", "kerala"):
        if place in text:
            tags.append(f"#{place}")

    seen: set[str] = set()
    unique: list[str] = []
    for tag in tags:
        key = tag.lower()
        if key in seen or not key.startswith("#") or len(key) < 3:
            continue
        seen.add(key)
        unique.append(key)
        if len(unique) >= count:
            break
    return unique[:count]


def analyze_image(image_path: str) -> dict[str, Any]:
    """Full local AI analysis: BLIP caption + CLIP tags + faces + hashtags."""
    # Support video inputs by extracting a frame first
    analysis_path = image_path
    if image_path and image_path.lower().endswith((".mp4", ".webm", ".mov", ".avi", ".mkv")):
        try:
            from app.services.ai_vision import extract_video_frame
            frame = extract_video_frame(image_path)
            if frame:
                analysis_path = frame
        except Exception:
            pass

    description = _describe_image(analysis_path)
    caption = suggest_image_captions(analysis_path, count=1)[0]
    hashtags = generate_hashtags_from_image(analysis_path, caption=description)
    labels = _extract_labels(description)

    clip_tags = []
    faces = []
    nsfw = 0.0
    try:
        from app.services.ai_vision import zero_shot_classify, detect_faces_opencv, clip_status
        from app.services.ai_nsfw import nsfw_score
        clip_tags = zero_shot_classify(analysis_path or "", top_k=6)
        faces = detect_faces_opencv(analysis_path or "")
        nsfw = nsfw_score(analysis_path or "")
        # Enrich hashtags from CLIP labels
        for tag in clip_tags[:4]:
            word = re.sub(r"[^a-z0-9]+", "", tag["label"].lower().split()[-1])
            if word and len(word) > 3:
                h = f"#{word}"
                if h not in hashtags:
                    hashtags.append(h)
        clip_info = clip_status()
    except Exception:
        clip_info = {"available": False}

    return {
        "caption": caption,
        "captions": suggest_image_captions(analysis_path),
        "hashtags": hashtags[:14],
        "labels": labels,
        "clip_tags": clip_tags,
        "faces": faces,
        "face_count": len(faces),
        "nsfw_score": nsfw,
        "engine": BLIP_MODEL_ID if _model is not None else "fallback",
        "status": get_ai_status(),
        "clip": clip_info,
    }


def _extract_labels(caption: str) -> list[str]:
    words = re.findall(r"[a-zA-Z]{4,}", (caption or "").lower())
    stop = {"with", "this", "that", "from", "have", "been", "were", "their", "about"}
    labels = []
    for w in words:
        if w not in stop and w not in labels:
            labels.append(w)
        if len(labels) >= 8:
            break
    return labels


def _kerala_flavor_caption(caption: str) -> str:
    caption = strip_caption_emojis(caption.strip())
    if not caption:
        return _fallback_caption("")
    caption = caption[0].upper() + caption[1:] if len(caption) > 1 else caption.upper()
    return caption


def _fallback_caption(image_path: str) -> str:
    """Internal description only — used for vibe detection / alt-text, not as post caption."""
    name = os.path.basename(image_path or "").lower()
    if any(k in name for k in ("beach", "sea", "varkala", "kovalam")):
        return "coastline and evening light"
    if any(k in name for k in ("tea", "munnar", "hill")):
        return "tea hills and mist"
    if any(k in name for k in ("boat", "backwater", "alleppey", "alappuzha")):
        return "backwaters and houseboat"
    if any(k in name for k in ("food", "sadya", "dosa", "meal")):
        return "kerala food plate"
    if any(k in name for k in ("temple", "festival", "pooram")):
        return "festival colours and drums"
    return "everyday moment outdoors"


def recommend_hashtags_text(caption: str = "", count: int = 10) -> list[str]:
    """Hashtags from caption text only (no image)."""
    return generate_hashtags_from_image("", caption=caption, count=count)
