"""Best-frame extraction for reels using OpenCV sharpness scoring."""
from __future__ import annotations

import os


def extract_best_frames(video_path: str, count: int = 3, out_dir: str | None = None) -> list[dict]:
    """
    Sample frames across the video, rank by Laplacian variance (sharpness),
    save top frames, return paths + scores.
    """
    if not video_path or not os.path.isfile(video_path):
        return []
    try:
        import cv2
    except ImportError:
        from app.services.ai_vision import extract_video_frame
        frame = extract_video_frame(video_path)
        return [{"path": frame, "score": 0.0, "index": 0}] if frame else []

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return []

    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    if total <= 0:
        cap.release()
        return []

    # Sample up to 12 candidate positions
    samples = min(12, max(total, 1))
    indices = sorted({int(i * (total - 1) / max(samples - 1, 1)) for i in range(samples)})
    scored = []

    for idx in indices:
        cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ok, frame = cap.read()
        if not ok or frame is None:
            continue
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        sharp = float(cv2.Laplacian(gray, cv2.CV_64F).var())
        # Prefer brighter-enough frames
        brightness = float(gray.mean())
        score = sharp + (5.0 if 40 < brightness < 210 else 0.0)
        scored.append((score, idx, frame))
    cap.release()

    if not scored:
        return []

    scored.sort(key=lambda x: x[0], reverse=True)
    out_dir = out_dir or os.path.dirname(video_path)
    os.makedirs(out_dir, exist_ok=True)
    base = os.path.splitext(os.path.basename(video_path))[0]
    results = []
    for rank, (score, idx, frame) in enumerate(scored[:count]):
        out_path = os.path.join(out_dir, f"{base}_best_{rank}.jpg")
        cv2.imwrite(out_path, frame)
        results.append({"path": out_path, "score": round(score, 2), "index": idx, "rank": rank})
    return results


def best_thumbnail(video_path: str) -> str | None:
    frames = extract_best_frames(video_path, count=1)
    return frames[0]["path"] if frames else None
