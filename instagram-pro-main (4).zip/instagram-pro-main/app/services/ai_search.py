"""Smarter local search: ILIKE + hashtag expansion + caption keyword ranking."""
from __future__ import annotations

from sqlalchemy import or_
from app.models.user import User
from app.models.post import Post
from app.models.hashtag import Hashtag, PostHashtag
from app.models.profile import Profile


def smart_user_search(query: str, limit: int = 20) -> list[User]:
    q = (query or "").strip()
    if not q:
        return []
    return (
        User.query
        .outerjoin(Profile, Profile.user_id == User.id)
        .filter(
            or_(
                User.username.ilike(f"%{q}%"),
                Profile.full_name.ilike(f"%{q}%"),
                Profile.bio.ilike(f"%{q}%"),
            )
        )
        .limit(limit)
        .all()
    )


def smart_post_search(query: str, limit: int = 24) -> list[Post]:
    from app.utils.helpers import filter_visible_posts, can_view_post
    from flask_login import current_user

    raw = (query or "").strip()
    q = raw.lstrip("#")
    if not q:
        return []
    tokens = [t.lstrip("#") for t in raw.replace(",", " ").split() if t.strip()]
    if q not in tokens:
        tokens.insert(0, q)

    caption_filters = [Post.caption.ilike(f"%{token}%") for token in tokens]
    posts = (
        filter_visible_posts(Post.query.filter(or_(*caption_filters)))
        .order_by(Post.created_at.desc())
        .limit(limit)
        .all()
    )
    found_ids = {p.id for p in posts}

    tag_filters = [Hashtag.name.ilike(f"%{token}%") for token in tokens]
    tags = Hashtag.query.filter(or_(*tag_filters)).limit(12).all()
    for tag in tags:
        links = PostHashtag.query.filter_by(hashtag_id=tag.id).limit(limit).all()
        for link in links:
            if link.post_id not in found_ids and link.post and can_view_post(current_user, link.post):
                posts.append(link.post)
                found_ids.add(link.post_id)
            if len(posts) >= limit:
                break

    posts = sorted(posts, key=lambda p: (p.like_count, p.created_at or 0), reverse=True)
    return posts[:limit]


def smart_hashtag_search(query: str, limit: int = 20) -> list[Hashtag]:
    q = (query or "").strip().lstrip("#")
    if not q:
        return []
    return (
        Hashtag.query
        .filter(Hashtag.name.ilike(f"%{q}%"))
        .limit(limit)
        .all()
    )


def smart_reel_search(query: str, limit: int = 20) -> list:
    from app.models.reel import Reel
    from app.utils.helpers import filter_visible_reels
    from sqlalchemy import or_

    q = (query or "").strip().lstrip("#")
    if not q:
        return []
    return (
        filter_visible_reels(
            Reel.query.filter(
                or_(
                    Reel.caption.ilike(f"%{q}%"),
                    Reel.audio_name.ilike(f"%{q}%"),
                )
            )
        )
        .order_by(Reel.created_at.desc())
        .limit(limit)
        .all()
    )


def smart_suggestions(query: str) -> dict:
    """Combined suggestion pack for search UI."""
    return {
        "users": [{"id": u.id, "username": u.username} for u in smart_user_search(query, 5)],
        "hashtags": [{"id": h.id, "name": h.name} for h in smart_hashtag_search(query, 5)],
        "posts": [{"id": p.id, "caption": (p.caption or "")[:80]} for p in smart_post_search(query, 5)],
        "reels": [{"id": r.id, "caption": (r.caption or "")[:80]} for r in smart_reel_search(query, 5)],
    }
