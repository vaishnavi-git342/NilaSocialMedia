"""Admin + Super Admin: users, reports, feature flags, Instagram Pro controls."""
from datetime import datetime

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import current_user, login_required

from app.extensions import db
from app.models.user import User
from app.models.post import Post
from app.models.report import Report
from app.utils.decorators import admin_required, super_admin_required
from app.services.feature_flags import (
    FEATURE_CATALOG,
    catalog_with_status,
    set_global_feature,
    set_user_feature,
    user_overrides_map,
    ensure_feature_flags,
)

admin_bp = Blueprint("admin", __name__)


@admin_bp.route("/")
@login_required
@admin_required
def dashboard():
    """Admin dashboard with overview stats."""
    stats = {
        "total_users": User.query.count(),
        "active_users": User.query.filter_by(is_active_account=True).count(),
        "inactive_users": User.query.filter_by(is_active_account=False).count(),
        "total_posts": Post.query.count(),
        "pending_reports": Report.query.filter_by(status="pending").count(),
        "total_reports": Report.query.count(),
    }
    return render_template(
        "admin/dashboard.html",
        stats=stats,
        is_super=bool(getattr(current_user, "is_super_admin", False)),
    )


@admin_bp.route("/users")
@login_required
@admin_required
def users():
    """User management page."""
    all_users = User.query.order_by(User.created_at.desc()).all()
    return render_template(
        "admin/users.html",
        users=all_users,
        is_super=bool(getattr(current_user, "is_super_admin", False)),
        features=FEATURE_CATALOG,
    )


@admin_bp.route("/users/<int:user_id>/toggle-active", methods=["POST"])
@login_required
@admin_required
def toggle_active(user_id):
    """Activate/deactivate a user."""
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("You cannot deactivate your own account.", "danger")
        return redirect(url_for("admin.users"))
    if getattr(user, "is_super_admin", False) and not getattr(current_user, "is_super_admin", False):
        flash("Only a super admin can deactivate another super admin.", "danger")
        return redirect(url_for("admin.users"))

    reason = (request.form.get("reason") or "").strip()[:255]
    user.is_active_account = not user.is_active_account
    if not user.is_active_account:
        user.deactivated_reason = reason or "Deactivated by administrator"
        user.deactivated_at = datetime.utcnow()
    else:
        user.deactivated_reason = None
        user.deactivated_at = None
    db.session.commit()
    flash(
        f"User @{user.username} {'activated' if user.is_active_account else 'deactivated'}.",
        "info",
    )
    return redirect(url_for("admin.users"))


@admin_bp.route("/users/<int:user_id>/toggle-admin", methods=["POST"])
@login_required
@super_admin_required
def toggle_admin(user_id):
    """Promote / demote regular admin (super admin only)."""
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("You cannot change your own admin role here.", "danger")
        return redirect(url_for("admin.users"))
    user.is_admin = not user.is_admin
    if not user.is_admin:
        user.is_super_admin = False
    db.session.commit()
    flash(
        f"@{user.username} is now {'an admin' if user.is_admin else 'a regular user'}.",
        "success",
    )
    return redirect(url_for("admin.users"))


@admin_bp.route("/users/<int:user_id>/toggle-super", methods=["POST"])
@login_required
@super_admin_required
def toggle_super(user_id):
    """Promote / demote super admin."""
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("You cannot remove your own super admin role.", "danger")
        return redirect(url_for("admin.users"))
    user.is_super_admin = not user.is_super_admin
    if user.is_super_admin:
        user.is_admin = True
    db.session.commit()
    flash(
        f"@{user.username} is now {'a super admin' if user.is_super_admin else 'no longer super admin'}.",
        "success",
    )
    return redirect(url_for("admin.users"))


@admin_bp.route("/users/<int:user_id>/features", methods=["GET", "POST"])
@login_required
@super_admin_required
def user_features(user_id):
    """Per-user Instagram Pro feature overrides."""
    user = User.query.get_or_404(user_id)
    ensure_feature_flags()

    if request.method == "POST":
        for item in FEATURE_CATALOG:
            key = item["key"]
            val = request.form.get(f"feat_{key}", "inherit")
            if val == "inherit":
                set_user_feature(user.id, key, None)
            elif val == "on":
                set_user_feature(user.id, key, True)
            else:
                set_user_feature(user.id, key, False)
        flash(f"Feature access updated for @{user.username}.", "success")
        return redirect(url_for("admin.user_features", user_id=user.id))

    overrides = user_overrides_map(user.id)
    return render_template(
        "admin/user_features.html",
        user=user,
        catalog=catalog_with_status(),
        overrides=overrides,
    )


@admin_bp.route("/features", methods=["GET", "POST"])
@login_required
@super_admin_required
def features():
    """Global Instagram Pro feature switches."""
    ensure_feature_flags()
    if request.method == "POST":
        for item in FEATURE_CATALOG:
            key = item["key"]
            enabled = request.form.get(f"feat_{key}") == "on"
            set_global_feature(key, enabled)
        flash("Global Nila Social features updated.", "success")
        return redirect(url_for("admin.features"))

    return render_template("admin/features.html", catalog=catalog_with_status())


@admin_bp.route("/reports")
@login_required
@admin_required
def reports():
    """View reported posts."""
    pending = Report.query.filter_by(status="pending").order_by(Report.created_at.desc()).all()
    reviewed = Report.query.filter(Report.status != "pending").order_by(Report.created_at.desc()).limit(20).all()
    return render_template("admin/reports.html", pending=pending, reviewed=reviewed)


@admin_bp.route("/reports/<int:report_id>/dismiss", methods=["POST"])
@login_required
@admin_required
def dismiss_report(report_id):
    r = Report.query.get_or_404(report_id)
    r.status = "dismissed"
    db.session.commit()
    flash("Report dismissed.", "info")
    return redirect(url_for("admin.reports"))


@admin_bp.route("/analytics")
@login_required
@admin_required
def analytics():
    """Analytics overview page."""
    return render_template("admin/analytics.html")


@admin_bp.route("/spam")
@login_required
@admin_required
def spam():
    """Spam detection dashboard (placeholder for AI spam detection)."""
    return render_template("admin/spam.html")


@admin_bp.route("/ai-monitor")
@login_required
@admin_required
def ai_monitor():
    """AI monitoring dashboard (placeholder)."""
    return render_template("admin/ai_monitor.html")
