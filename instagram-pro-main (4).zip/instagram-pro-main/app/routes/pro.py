"""Instagram Pro feature routes: journey maps, festival modes."""
from flask import Blueprint, render_template, redirect, url_for, flash, session, request
from flask_login import login_required, current_user
from app.utils.decorators import feature_required

pro_bp = Blueprint("pro", __name__)


@pro_bp.route("/journey")
@login_required
def journey():
    """Instagram has no travel-journey map. Keep the URL from 404ing old links."""
    return redirect(url_for("main.feed"))


@pro_bp.route("/festival", methods=["GET", "POST"])
@login_required
@feature_required("festival")
def festival():
    from app.services.ai_festival import list_modes, get_mode
    if request.method == "POST":
        mode_id = request.form.get("mode", "default")
        if mode_id not in {m["id"] for m in list_modes()}:
            mode_id = "default"
        session["festival_mode"] = mode_id
        flash(f"Festival mode set to {get_mode(mode_id)['name']}", "success")
        return redirect(url_for("pro.festival"))
    current = session.get("festival_mode")
    return render_template(
        "pro/festival.html",
        modes=list_modes(),
        current_mode=get_mode(current),
    )
