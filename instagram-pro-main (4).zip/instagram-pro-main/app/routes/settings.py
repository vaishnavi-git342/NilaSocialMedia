"""Settings blueprint: dark mode, privacy, password change, email change, delete account."""
from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import current_user, login_required, logout_user
from app.extensions import db
from app.models.user import User
from app.forms.settings import (
    ChangePasswordForm, EmailChangeForm, PrivacySettingsForm, DeleteAccountForm,
)

settings_bp = Blueprint("settings", __name__)


@settings_bp.route("/")
@login_required
def index():
    """Settings landing page."""
    return render_template("settings/index.html")


@settings_bp.route("/privacy", methods=["GET", "POST"])
@login_required
def privacy():
    form = PrivacySettingsForm()
    if form.validate_on_submit():
        was_private = current_user.is_private
        current_user.is_private = form.is_private.data
        current_user.dark_mode = form.dark_mode.data
        current_user.filter_offensive_comments = form.filter_offensive_comments.data
        # Going public: auto-accept pending follow requests
        if was_private and not current_user.is_private:
            from app.models.follow import Follow
            Follow.query.filter_by(followed_id=current_user.id, accepted=False).update(
                {"accepted": True}, synchronize_session=False
            )
        db.session.commit()
        flash("Settings updated.", "success")
        return redirect(url_for("settings.privacy"))
    form.is_private.data = current_user.is_private
    form.dark_mode.data = current_user.dark_mode
    form.filter_offensive_comments.data = getattr(current_user, "filter_offensive_comments", True)
    return render_template("settings/privacy.html", form=form)


@settings_bp.route("/blocked")
@login_required
def blocked():
    from app.models.block import UserBlock
    blocks = (
        UserBlock.query.filter_by(blocker_id=current_user.id)
        .order_by(UserBlock.created_at.desc())
        .all()
    )
    return render_template("settings/blocked.html", blocks=blocks)


@settings_bp.route("/muted")
@login_required
def muted():
    from app.models.social_controls import UserMute
    mutes = (
        UserMute.query.filter_by(muter_id=current_user.id)
        .order_by(UserMute.created_at.desc())
        .all()
    )
    return render_template("settings/muted.html", mutes=mutes)


@settings_bp.route("/password", methods=["GET", "POST"])
@login_required
def password():
    form = ChangePasswordForm()
    if form.validate_on_submit():
        if not current_user.check_password(form.current_password.data):
            flash("Current password is incorrect.", "danger")
        else:
            current_user.set_password(form.new_password.data)
            db.session.commit()
            flash("Password changed successfully.", "success")
            return redirect(url_for("settings.index"))
    return render_template("settings/password.html", form=form)


@settings_bp.route("/email", methods=["GET", "POST"])
@login_required
def email():
    form = EmailChangeForm()
    if form.validate_on_submit():
        if not current_user.check_password(form.password.data):
            flash("Password is incorrect.", "danger")
        else:
            current_user.email = form.new_email.data
            current_user.email_verified = False
            db.session.commit()
            flash("Email updated. Please verify your new email.", "success")
            return redirect(url_for("settings.index"))
    return render_template("settings/email.html", form=form)


@settings_bp.route("/delete", methods=["GET", "POST"])
@login_required
def delete():
    form = DeleteAccountForm()
    if form.validate_on_submit():
        if not current_user.check_password(form.password.data):
            flash("Password is incorrect.", "danger")
        else:
            user = db.session.get(User, current_user.id)
            logout_user()
            if user:
                from app.utils.helpers import delete_user_account
                try:
                    delete_user_account(user)
                    db.session.commit()
                except Exception:
                    db.session.rollback()
                    flash("Could not delete account due to related data. Please try again.", "danger")
                    return redirect(url_for("settings.delete"))
            flash("Account deleted. We're sorry to see you go.", "info")
            return redirect(url_for("auth.login"))
    return render_template("settings/delete.html", form=form)
