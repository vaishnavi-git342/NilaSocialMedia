"""Social features blueprint: reposts, close friends, broadcast channels."""
from flask import Blueprint, render_template, redirect, url_for, flash, abort, request
from flask_login import current_user, login_required
from app.extensions import db
from app.models.repost import Repost
from app.models.social_features import (
    CloseFriend, BroadcastChannel, BroadcastMessage, BroadcastMember,
)
from app.models.post import Post
from app.models.reel import Reel
from app.models.user import User
from app.utils.helpers import create_notification

social_bp = Blueprint("social", __name__)


# --- Reposts ---

@social_bp.route("/repost/post/<int:post_id>", methods=["POST"])
@login_required
def repost_post(post_id):
    """Repost a post."""
    post = Post.query.get_or_404(post_id)
    existing = Repost.query.filter_by(user_id=current_user.id, post_id=post_id).first()
    if existing:
        db.session.delete(existing)
        flash("Repost removed.", "info")
    else:
        caption = request.form.get("caption", "")
        r = Repost(user_id=current_user.id, post_id=post_id, caption=caption)
        db.session.add(r)
        create_notification(post.user_id, current_user.id, "mention", f"{current_user.username} reposted your post.")
        flash("Reposted to your feed!", "success")
    db.session.commit()
    return redirect(request.referrer or url_for("main.feed"))


@social_bp.route("/repost/reel/<int:reel_id>", methods=["POST"])
@login_required
def repost_reel(reel_id):
    """Repost a reel."""
    reel = Reel.query.get_or_404(reel_id)
    existing = Repost.query.filter_by(user_id=current_user.id, reel_id=reel_id).first()
    if existing:
        db.session.delete(existing)
        flash("Repost removed.", "info")
    else:
        caption = request.form.get("caption", "")
        r = Repost(user_id=current_user.id, reel_id=reel_id, caption=caption)
        db.session.add(r)
        create_notification(reel.user_id, current_user.id, "mention", f"{current_user.username} reposted your reel.")
        flash("Reposted!", "success")
    db.session.commit()
    return redirect(request.referrer or url_for("reel.feed"))


# --- Close Friends ---

@social_bp.route("/close-friends")
@login_required
def close_friends():
    """View and manage close friends list."""
    friends = CloseFriend.query.filter_by(user_id=current_user.id).all()
    friend_ids = {f.friend_id for f in friends}
    following = [f.followed for f in current_user.following if f.accepted]
    return render_template("social/close_friends.html", friends=friends, friend_ids=friend_ids, following=following)


@social_bp.route("/close-friends/<int:user_id>/add", methods=["POST"])
@login_required
def add_close_friend(user_id):
    """Add a user to close friends."""
    if user_id == current_user.id:
        return redirect(url_for("social.close_friends"))
    existing = CloseFriend.query.filter_by(user_id=current_user.id, friend_id=user_id).first()
    if not existing:
        cf = CloseFriend(user_id=current_user.id, friend_id=user_id)
        db.session.add(cf)
        db.session.commit()
        flash("Added to close friends.", "success")
    return redirect(url_for("social.close_friends"))


@social_bp.route("/close-friends/<int:user_id>/remove", methods=["POST"])
@login_required
def remove_close_friend(user_id):
    """Remove a user from close friends."""
    cf = CloseFriend.query.filter_by(user_id=current_user.id, friend_id=user_id).first()
    if cf:
        db.session.delete(cf)
        db.session.commit()
        flash("Removed from close friends.", "info")
    return redirect(url_for("social.close_friends"))


# --- Broadcast Channels ---

@social_bp.route("/broadcasts")
@login_required
def broadcasts():
    """List broadcast channels."""
    my_channels = BroadcastChannel.query.filter_by(creator_id=current_user.id).all()
    joined = (
        BroadcastChannel.query
        .join(BroadcastMember, BroadcastChannel.id == BroadcastMember.channel_id)
        .filter(BroadcastMember.user_id == current_user.id)
        .all()
    )
    return render_template("social/broadcasts.html", my_channels=my_channels, joined=joined)


@social_bp.route("/broadcasts/create", methods=["POST"])
@login_required
def create_broadcast():
    """Create a broadcast channel."""
    title = request.form.get("title", "").strip()
    description = request.form.get("description", "").strip()
    if not title:
        flash("Channel title is required.", "danger")
        return redirect(url_for("social.broadcasts"))
    ch = BroadcastChannel(creator_id=current_user.id, title=title, description=description)
    db.session.add(ch)
    db.session.flush()
    # Creator is auto-member
    member = BroadcastMember(channel_id=ch.id, user_id=current_user.id)
    db.session.add(member)
    db.session.commit()
    flash("Broadcast channel created!", "success")
    return redirect(url_for("social.view_broadcast", channel_id=ch.id))


@social_bp.route("/broadcasts/<int:channel_id>")
@login_required
def view_broadcast(channel_id):
    """View a broadcast channel."""
    ch = BroadcastChannel.query.get_or_404(channel_id)
    messages = BroadcastMessage.query.filter_by(channel_id=channel_id).order_by(BroadcastMessage.created_at).all()
    is_member = BroadcastMember.query.filter_by(channel_id=channel_id, user_id=current_user.id).first() is not None
    return render_template("social/broadcast_view.html", channel=ch, messages=messages, is_member=is_member)


@social_bp.route("/broadcasts/<int:channel_id>/post", methods=["POST"])
@login_required
def post_broadcast_message(channel_id):
    """Post a message to a broadcast channel (creator only)."""
    ch = BroadcastChannel.query.get_or_404(channel_id)
    if ch.creator_id != current_user.id:
        abort(403)
    body = request.form.get("body", "").strip()
    if body:
        msg = BroadcastMessage(channel_id=channel_id, sender_id=current_user.id, body=body)
        db.session.add(msg)
        db.session.commit()
        flash("Message sent!", "success")
    return redirect(url_for("social.view_broadcast", channel_id=channel_id))


@social_bp.route("/broadcasts/<int:channel_id>/join")
@login_required
def join_broadcast(channel_id):
    """Join a broadcast channel."""
    existing = BroadcastMember.query.filter_by(channel_id=channel_id, user_id=current_user.id).first()
    if not existing:
        m = BroadcastMember(channel_id=channel_id, user_id=current_user.id)
        db.session.add(m)
        db.session.commit()
        flash("Joined channel!", "success")
    return redirect(url_for("social.view_broadcast", channel_id=channel_id))
