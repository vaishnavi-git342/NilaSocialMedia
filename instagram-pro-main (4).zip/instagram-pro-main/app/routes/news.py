"""Daily updates, similar to the news row on social apps."""
from flask import Blueprint, render_template
from flask_login import login_required

from app.extensions import db
from app.services.daily_news import _plain, refresh_news_if_stale

news_bp = Blueprint("news", __name__)


@news_bp.route("/")
@login_required
def index():
    items = refresh_news_if_stale()
    dirty = False
    for item in items:
        clean = _plain(item.summary or "")
        if clean != (item.summary or ""):
            item.summary = clean[:500]
            dirty = True
    if dirty:
        db.session.commit()
    return render_template("news/index.html", items=items)
