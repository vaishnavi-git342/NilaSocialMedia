"""Story blueprint: upload, view, and working highlights."""
from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, abort, request
from flask_login import current_user, login_required
from app.extensions import db
from app.models.story import Story, StoryView, StoryHighlight, HighlightItem
from app.forms.story import StoryForm
from app.utils.helpers import save_uploaded_file, can_view_story
from flask import current_app

story_bp = Blueprint("story", __name__)


@story_bp.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    form = StoryForm()
    if form.validate_on_submit():
        from datetime import timedelta

        ext = form.media.data.filename.rsplit(".", 1)[1].lower()
        is_video = ext in {"mp4", "webm", "mov"}
        path = save_uploaded_file(
            form.media.data,
            "stories",
            current_app.config["ALLOWED_IMAGE_EXTENSIONS"] | current_app.config["ALLOWED_VIDEO_EXTENSIONS"],
        )
        audio_path = None
        if form.audio.data:
            audio_path = save_uploaded_file(
                form.audio.data,
                "audio",
                current_app.config["ALLOWED_AUDIO_EXTENSIONS"],
            )
            if not audio_path:
                flash("That audio file could not be saved. Use mp3, wav, m4a, ogg, or aac.", "danger")
                return render_template("stories/upload.html", form=form)
        if not path:
            flash("Add a photo or video.", "danger")
            return render_template("stories/upload.html", form=form)

        story = Story(
            user_id=current_user.id,
            filename=path,
            is_video=is_video,
            caption=(form.caption.data or "").strip() or None,
            audio_filename=audio_path,
            expires_at=datetime.utcnow() + timedelta(hours=48),
        )
        db.session.add(story)
        db.session.commit()
        flash("Story added!", "success")
        return redirect(url_for("main.feed"))
    return render_template("stories/upload.html", form=form)


@story_bp.route("/<int:story_id>/delete", methods=["POST"])
@login_required
def delete(story_id):
    story = Story.query.get_or_404(story_id)
    is_staff = bool(getattr(current_user, "is_admin", False) or getattr(current_user, "is_super_admin", False))
    if story.user_id != current_user.id and not is_staff:
        abort(403)
    StoryView.query.filter_by(story_id=story.id).delete(synchronize_session=False)
    db.session.delete(story)
    db.session.commit()
    flash("Story deleted.", "info")
    return redirect(url_for("main.feed"))


def _active_stories_for_user(user_id: int):
    return (
        Story.query.filter(
            Story.user_id == user_id,
            Story.expires_at > datetime.utcnow(),
        )
        .order_by(Story.created_at.asc(), Story.id.asc())
        .all()
    )


def _tray_user_order(viewer) -> list[int]:
    """Same order as the home stories tray: own first, then followed users with stories."""
    from app.utils.helpers import story_tray_for_user

    tray = story_tray_for_user(viewer)
    order = []
    if tray["own_story"]:
        order.append(viewer.id)
    order.extend(e["user"].id for e in tray["story_users"])
    return order


@story_bp.route("/view/<int:story_id>")
@login_required
def view(story_id):
    story = Story.query.get_or_404(story_id)
    if not can_view_story(current_user, story):
        abort(403)
    if story.is_expired:
        flash("This story has expired.", "info")
        return redirect(url_for("main.feed"))
    existing = StoryView.query.filter_by(story_id=story_id, user_id=current_user.id).first()
    if not existing:
        db.session.add(StoryView(story_id=story_id, user_id=current_user.id))
        db.session.commit()

    # Instagram: play this user's stories in order, then advance to the next tray user
    same_user = _active_stories_for_user(story.user_id)
    ids = [s.id for s in same_user]
    next_story = None
    prev_story = None
    if story.id in ids:
        idx = ids.index(story.id)
        if idx + 1 < len(ids):
            next_story = same_user[idx + 1]
        if idx > 0:
            prev_story = same_user[idx - 1]

    if next_story is None:
        order = _tray_user_order(current_user)
        try:
            pos = order.index(story.user_id)
        except ValueError:
            pos = -1
        for uid in order[pos + 1 :]:
            nxt = _active_stories_for_user(uid)
            if nxt:
                next_story = nxt[0]
                break

    if prev_story is None:
        order = _tray_user_order(current_user)
        try:
            pos = order.index(story.user_id)
        except ValueError:
            pos = -1
        for uid in reversed(order[:pos]):
            prev = _active_stories_for_user(uid)
            if prev:
                prev_story = prev[-1]
                break

    return render_template(
        "stories/view.html",
        story=story,
        next_story=next_story,
        prev_story=prev_story,
    )


@story_bp.route("/highlights")
@login_required
def highlights():
    user_highlights = (
        StoryHighlight.query.filter_by(user_id=current_user.id)
        .order_by(StoryHighlight.created_at.desc())
        .all()
    )
    active_stories = (
        Story.query.filter(
            Story.user_id == current_user.id,
            Story.expires_at > datetime.utcnow(),
        )
        .order_by(Story.created_at.desc())
        .all()
    )
    return render_template(
        "stories/highlights.html",
        highlights=user_highlights,
        active_stories=active_stories,
    )


@story_bp.route("/highlights/create", methods=["POST"])
@login_required
def create_highlight():
    title = (request.form.get("title") or "").strip()[:80]
    if not title:
        flash("Give your highlight a title.", "danger")
        return redirect(url_for("story.highlights"))
    h = StoryHighlight(user_id=current_user.id, title=title)
    db.session.add(h)
    db.session.commit()
    flash(f'Highlight "{title}" created.', "success")
    return redirect(url_for("story.highlights"))


@story_bp.route("/highlights/<int:highlight_id>/add", methods=["POST"])
@login_required
def add_to_highlight(highlight_id):
    h = StoryHighlight.query.get_or_404(highlight_id)
    if h.user_id != current_user.id:
        abort(403)
    story_id = request.form.get("story_id", type=int)
    story = Story.query.get_or_404(story_id)
    if story.user_id != current_user.id:
        abort(403)
    # Persist a copy reference so it survives story expiry
    item = HighlightItem(
        highlight_id=h.id,
        media_filename=story.filename,
        is_video=story.is_video,
        caption=story.caption,
        position=len(h.items),
    )
    db.session.add(item)
    if not h.cover_filename:
        h.cover_filename = story.filename
    db.session.commit()
    flash("Added to highlight.", "success")
    return redirect(url_for("story.highlights"))


@story_bp.route("/highlights/<int:highlight_id>")
@login_required
def view_highlight(highlight_id):
    h = StoryHighlight.query.get_or_404(highlight_id)
    # Public if owner account is public or viewer is owner / follower — reuse story privacy via owner
    from app.models.user import User
    owner = User.query.get(h.user_id)
    if owner and owner.is_private and current_user.id != owner.id:
        if not current_user.is_following(owner.id):
            abort(403)
    return render_template("stories/highlight_view.html", highlight=h)


@story_bp.route("/highlights/<int:highlight_id>/delete", methods=["POST"])
@login_required
def delete_highlight(highlight_id):
    h = StoryHighlight.query.get_or_404(highlight_id)
    if h.user_id != current_user.id:
        abort(403)
    db.session.delete(h)
    db.session.commit()
    flash("Highlight deleted.", "info")
    return redirect(url_for("story.highlights"))
