"""Notification blueprint: list and mark notifications as read."""
from flask import Blueprint, render_template, redirect, url_for, abort
from flask_login import current_user, login_required
from app.extensions import db
from app.models.notification import Notification

notification_bp = Blueprint("notification", __name__)


@notification_bp.route("/")
@login_required
def index():
    """List all notifications for the current user."""
    notifications = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).all()
    return render_template("notifications/index.html", notifications=notifications)


@notification_bp.route("/read/<int:notification_id>")
@login_required
def mark_read(notification_id):
    n = Notification.query.get_or_404(notification_id)
    if n.user_id != current_user.id:
        abort(403)
    n.is_read = True
    db.session.commit()
    return redirect(url_for("notification.index"))


@notification_bp.route("/read-all")
@login_required
def mark_all_read():
    Notification.query.filter_by(user_id=current_user.id, is_read=False).update({"is_read": True})
    db.session.commit()
    return redirect(url_for("notification.index"))
