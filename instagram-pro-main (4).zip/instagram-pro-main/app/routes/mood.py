"""Mood blueprint: mood-based AI feed, mood selector, mood-tagged content."""
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import current_user, login_required
from app.extensions import db
from app.models.mood import Mood, UserMood, PostMood
from app.models.post import Post
from app.models.reel import Reel
from app.services.ai_mood_feed import get_mood_posts, get_mood_reels
from app.services.ai_mood import detect_user_mood
from app.utils.decorators import feature_required

mood_bp = Blueprint("mood", __name__)


@mood_bp.route("/")
@login_required
@feature_required("mood_feed")
def mood_page():
    """Mood selector page."""
    moods = Mood.query.all()
    # Get user's current mood
    current_mood = UserMood.query.filter_by(user_id=current_user.id).order_by(UserMood.created_at.desc()).first()
    current_mood_obj = current_mood.mood if current_mood else None
    # AI-detected mood
    detected_mood = detect_user_mood(current_user.id)
    return render_template("mood/index.html", moods=moods, current_mood=current_mood_obj, detected_mood=detected_mood)


@mood_bp.route("/select/<mood_name>")
@login_required
def select_mood(mood_name):
    """Set the user's current mood."""
    mood = Mood.query.filter_by(name=mood_name).first()
    if not mood:
        flash("Mood not found.", "danger")
        return redirect(url_for("mood.mood_page"))

    # Remove old mood entries
    UserMood.query.filter_by(user_id=current_user.id).delete()
    um = UserMood(user_id=current_user.id, mood_id=mood.id)
    db.session.add(um)
    db.session.commit()
    flash(f"Mood set to {mood.emoji} {mood.name}!", "success")
    return redirect(url_for("mood.mood_feed", mood_name=mood_name))


@mood_bp.route("/feed/<mood_name>")
@login_required
def mood_feed(mood_name):
    """Show mood-based feed."""
    mood = Mood.query.filter_by(name=mood_name).first_or_404()
    page = request.args.get("page", 1, type=int)
    posts = get_mood_posts(mood_name, limit=12, offset=(page - 1) * 12)
    reels = get_mood_reels(mood_name, limit=6)
    all_moods = Mood.query.all()
    return render_template("mood/feed.html", mood=mood, posts=posts, reels=reels, all_moods=all_moods, page=page)


@mood_bp.route("/detect")
@login_required
def detect_mood():
    """AI auto-detect mood and redirect to feed."""
    mood_name = detect_user_mood(current_user.id)
    return redirect(url_for("mood.mood_feed", mood_name=mood_name))
