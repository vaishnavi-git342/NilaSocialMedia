"""Profile blueprint: view and edit profiles, followers/following lists."""
from flask import Blueprint, render_template, redirect, url_for, flash, abort
from flask_login import current_user, login_required
from app.extensions import db
from app.models.user import User
from app.models.profile import Profile
from app.models.post import Post
from app.models.follow import Follow
from app.models.saved_post import SavedPost
from app.forms.profile import EditProfileForm
from app.utils.helpers import save_uploaded_file
from flask import current_app

profile_bp = Blueprint("profile", __name__)


@profile_bp.route("/<username>")
def view(username):
    """View a user's profile (posts or reels tab)."""
    from flask import request
    from app.models.reel import Reel

    user = User.query.filter_by(username=username).first_or_404()
    is_own_profile = current_user.is_authenticated and current_user.id == user.id
    is_blocked = current_user.is_authenticated and current_user.has_blocked(user.id)
    blocked_by_them = current_user.is_authenticated and current_user.is_blocked_by(user.id)

    if not is_own_profile and (is_blocked or blocked_by_them):
        return render_template(
            "profile/blocked.html",
            user=user,
            is_blocked=is_blocked,
            blocked_by_them=blocked_by_them,
        )

    tab = (request.args.get("tab") or "posts").strip().lower()
    if tab not in ("posts", "reels"):
        tab = "posts"

    posts = Post.query.filter_by(user_id=user.id).order_by(Post.created_at.desc()).all()
    reels = Reel.query.filter_by(user_id=user.id).order_by(Reel.created_at.desc()).all()
    if not is_own_profile:
        posts = [p for p in posts if not getattr(p, "is_archived", False)]
        if not (current_user.is_authenticated and current_user.is_adult):
            posts = [p for p in posts if not getattr(p, "is_adult_content", False)]
            reels = [r for r in reels if not getattr(r, "is_adult_content", False)]

    is_following = current_user.is_authenticated and current_user.is_following(user.id)
    is_pending = current_user.is_authenticated and current_user.has_pending_follow(user.id)
    is_muted = current_user.is_authenticated and current_user.has_muted(user.id)
    is_restricted = current_user.is_authenticated and current_user.has_restricted(user.id)

    from app.models.story import StoryHighlight, Story
    from datetime import datetime

    highlights = (
        StoryHighlight.query.filter_by(user_id=user.id)
        .order_by(StoryHighlight.created_at.desc())
        .all()
    )
    active_story = (
        Story.query.filter(
            Story.user_id == user.id,
            Story.expires_at > datetime.utcnow(),
        )
        .order_by(Story.created_at.asc())
        .first()
    )

    if user.is_private and not is_following and not is_own_profile:
        return render_template(
            "profile/private.html",
            user=user,
            is_following=is_following,
            is_pending=is_pending,
        )

    return render_template(
        "profile/view.html",
        user=user,
        posts=posts,
        reels=reels,
        tab=tab,
        highlights=highlights,
        active_story=active_story,
        is_following=is_following,
        is_pending=is_pending,
        is_own_profile=is_own_profile,
        is_blocked=is_blocked,
        is_muted=is_muted,
        is_restricted=is_restricted,
    )


@profile_bp.route("/<username>/saved")
@login_required
def saved(username):
    """View saved posts (only own profile)."""
    if current_user.username != username:
        abort(403)
    saved_posts = SavedPost.query.filter_by(user_id=current_user.id).order_by(SavedPost.created_at.desc()).all()
    return render_template("profile/saved.html", user=current_user, saved_posts=saved_posts)


@profile_bp.route("/<username>/tagged")
def tagged(username):
    """View tagged posts (placeholder)."""
    user = User.query.filter_by(username=username).first_or_404()
    is_following = current_user.is_authenticated and current_user.is_following(user.id)
    is_own = current_user.is_authenticated and current_user.id == user.id
    if user.is_private and not is_following and not is_own:
        return render_template("profile/private.html", user=user, is_following=is_following, is_pending=current_user.is_authenticated and current_user.has_pending_follow(user.id))
    return render_template("profile/tagged.html", user=user, posts=[])


@profile_bp.route("/<username>/followers")
def followers(username):
    """View followers list."""
    user = User.query.filter_by(username=username).first_or_404()
    is_following = current_user.is_authenticated and current_user.is_following(user.id)
    is_own = current_user.is_authenticated and current_user.id == user.id
    if user.is_private and not is_following and not is_own:
        return render_template(
            "profile/private.html",
            user=user,
            is_following=is_following,
            is_pending=current_user.is_authenticated and current_user.has_pending_follow(user.id),
        )
    follows = Follow.query.filter_by(followed_id=user.id, accepted=True).all()
    return render_template("profile/followers.html", user=user, follows=follows)


@profile_bp.route("/<username>/following")
def following(username):
    """View following list."""
    user = User.query.filter_by(username=username).first_or_404()
    is_following = current_user.is_authenticated and current_user.is_following(user.id)
    is_own = current_user.is_authenticated and current_user.id == user.id
    if user.is_private and not is_following and not is_own:
        return render_template(
            "profile/private.html",
            user=user,
            is_following=is_following,
            is_pending=current_user.is_authenticated and current_user.has_pending_follow(user.id),
        )
    follows = Follow.query.filter_by(follower_id=user.id, accepted=True).all()
    return render_template("profile/following.html", user=user, follows=follows)


@profile_bp.route("/edit", methods=["GET", "POST"])
@login_required
def edit():
    """Edit own profile."""
    form = EditProfileForm()
    profile = current_user.profile or Profile(user_id=current_user.id)

    if form.validate_on_submit():
        profile.full_name = form.full_name.data
        profile.bio = form.bio.data
        profile.website = form.website.data
        profile.gender = form.gender.data
        if form.profile_photo.data:
            from app.services.ai_age_gate import analyze_profile_photo
            check = analyze_profile_photo(form.profile_photo.data)
            if not check.get("allowed"):
                flash(
                    "Profile photo rejected: "
                    + "; ".join(check.get("reasons") or ["heavily edited photos are not allowed."]),
                    "danger",
                )
                return render_template("profile/edit.html", form=form)
            path = save_uploaded_file(form.profile_photo.data, "profiles", current_app.config["ALLOWED_IMAGE_EXTENSIONS"])
            if path:
                profile.profile_photo = path
                profile.is_ai_profile_photo = bool(check.get("is_ai_generated"))
                profile.profile_photo_label = check.get("label") if check.get("is_ai_generated") else None
        if form.cover_photo.data:
            path = save_uploaded_file(form.cover_photo.data, "profiles", current_app.config["ALLOWED_IMAGE_EXTENSIONS"])
            if path:
                profile.cover_photo = path
        db.session.add(profile)
        db.session.commit()
        flash("Profile updated successfully!", "success")
        return redirect(url_for("profile.view", username=current_user.username))

    # Pre-populate form
    form.full_name.data = profile.full_name
    form.bio.data = profile.bio
    form.website.data = profile.website
    form.gender.data = profile.gender

    return render_template("profile/edit.html", form=form)
