"""Community movie reviews: write, search by title, and read."""
import re

from flask import Blueprint, abort, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from app.extensions import db
from app.forms.review import MovieReviewForm
from app.models.review import MovieReview

review_bp = Blueprint("review", __name__)


def _clean_title(value: str) -> str:
    return re.sub(r"\s+", " ", (value or "").strip())


@review_bp.route("/", methods=["GET", "POST"])
@login_required
def index():
    form = MovieReviewForm()
    if form.validate_on_submit():
        review = MovieReview(
            user_id=current_user.id,
            movie_title=_clean_title(form.movie_title.data)[:160],
            rating=int(form.rating.data),
            body=form.body.data.strip(),
        )
        db.session.add(review)
        db.session.commit()
        flash("Review posted.", "success")
        return redirect(url_for("review.index", q=review.movie_title))

    q = _clean_title(request.args.get("q") or "")
    query = MovieReview.query
    if q:
        query = query.filter(MovieReview.movie_title.ilike(f"%{q}%"))
    reviews = query.order_by(MovieReview.created_at.desc()).limit(60).all()
    return render_template("reviews/index.html", form=form, reviews=reviews, q=q)


@review_bp.route("/<int:review_id>")
@login_required
def view(review_id):
    review = MovieReview.query.get_or_404(review_id)
    return render_template("reviews/view.html", review=review)


@review_bp.route("/<int:review_id>/delete", methods=["POST"])
@login_required
def delete(review_id):
    review = MovieReview.query.get_or_404(review_id)
    if review.user_id != current_user.id and not (
        current_user.is_admin or current_user.is_super_admin
    ):
        abort(403)
    db.session.delete(review)
    db.session.commit()
    flash("Review removed.", "info")
    return redirect(url_for("review.index"))
