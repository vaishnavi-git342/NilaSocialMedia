"""Explore blueprint: trending posts, reels, mixed all, suggested users, hashtags."""
from flask import Blueprint, render_template, request
from flask_login import current_user
from app.models.post import Post
from app.models.reel import Reel
from app.models.user import User
from app.models.hashtag import Hashtag
from app.utils.helpers import filter_visible_posts, filter_visible_reels

explore_bp = Blueprint("explore", __name__)


@explore_bp.route("/")
def index():
    """Explore page — All / Posts / Reels tabs."""
    page = request.args.get("page", 1, type=int)
    tab = (request.args.get("tab") or "all").strip().lower()
    if tab not in ("all", "posts", "reels"):
        tab = "all"
    per_page = 24

    posts = []
    reels = []
    mixed = []

    if tab == "reels":
        reels = (
            filter_visible_reels(Reel.query)
            .order_by(Reel.created_at.desc())
            .offset((page - 1) * per_page)
            .limit(per_page)
            .all()
        )
    elif tab == "posts":
        posts = (
            filter_visible_posts(Post.query)
            .order_by(Post.created_at.desc())
            .offset((page - 1) * per_page)
            .limit(per_page)
            .all()
        )
    else:
        # Mixed grid: recent posts + reels interleaved by time
        posts = (
            filter_visible_posts(Post.query)
            .order_by(Post.created_at.desc())
            .limit(per_page)
            .all()
        )
        reels = (
            filter_visible_reels(Reel.query)
            .order_by(Reel.created_at.desc())
            .limit(per_page)
            .all()
        )
        for p in posts:
            mixed.append({"kind": "post", "item": p, "at": p.created_at})
        for r in reels:
            mixed.append({"kind": "reel", "item": r, "at": r.created_at})
        mixed.sort(key=lambda x: x["at"] or 0, reverse=True)
        mixed = mixed[:per_page]

    following_ids = set()
    if current_user.is_authenticated:
        following_ids = {f.followed_id for f in current_user.following if f.accepted}
        following_ids.add(current_user.id)
    suggested = (
        User.query
        .filter(~User.id.in_(following_ids) if following_ids else True)
        .limit(5)
        .all()
    )
    popular_tags = Hashtag.query.order_by(Hashtag.id.desc()).limit(10).all()
    return render_template(
        "explore/index.html",
        posts=posts,
        reels=reels,
        mixed=mixed,
        tab=tab,
        suggested_users=suggested,
        popular_tags=popular_tags,
        page=page,
    )


@explore_bp.route("/category/<category>")
def category(category):
    return render_template("explore/category.html", category=category)
