"""Authentication blueprint: register, login, logout, email verification, password reset."""
from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_user, logout_user, current_user, login_required
from itsdangerous import URLSafeTimedSerializer, SignatureExpired, BadSignature
from flask import current_app

from app.extensions import db, mail
from app.models.user import User
from app.models.profile import Profile
from app.forms.auth import (
    LoginForm, RegisterForm, ForgotPasswordForm, ResetPasswordForm,
    ProfileSetupForm, EmailVerificationForm,
)
from flask_mail import Message as MailMessage

auth_bp = Blueprint("auth", __name__)


# --- Helpers ---

def get_serializer():
    return URLSafeTimedSerializer(current_app.config["SECRET_KEY"])


def generate_token(email: str, salt: str = "email-confirm") -> str:
    s = get_serializer()
    return s.dumps(email, salt=salt)


def confirm_token(token: str, salt: str = "email-confirm", max_age: int = 3600) -> str | None:
    s = get_serializer()
    try:
        return s.loads(token, salt=salt, max_age=max_age)
    except (SignatureExpired, BadSignature):
        return None


def send_email(to: str, subject: str, body: str):
    """Send an email via Flask-Mail. Silently falls back to console in dev."""
    try:
        msg = MailMessage(subject, recipients=[to], body=body, sender=current_app.config["MAIL_DEFAULT_SENDER"])
        mail.send(msg)
    except Exception:
        # In development without a mail server, print to console
        print(f"[EMAIL] To: {to}\nSubject: {subject}\n{body}")


# --- Routes ---

@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.feed"))
    form = RegisterForm()
    if form.validate_on_submit():
        from app.services.ai_age_gate import analyze_profile_photo
        from app.utils.helpers import save_uploaded_file

        photo_check = analyze_profile_photo(form.profile_photo.data)
        if not photo_check.get("allowed"):
            flash(
                "Profile photo rejected: "
                + "; ".join(photo_check.get("reasons") or ["heavily edited photos are not allowed."]),
                "danger",
            )
            return render_template("auth/register.html", form=form)

        path = save_uploaded_file(
            form.profile_photo.data,
            "profiles",
            current_app.config["ALLOWED_IMAGE_EXTENSIONS"],
        )
        if not path:
            flash("Could not save profile photo.", "danger")
            return render_template("auth/register.html", form=form)

        user = User(
            username=form.username.data.strip(),
            email=form.email.data.strip().lower(),
            birth_date=form.birth_date.data,
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.flush()

        profile = Profile(
            user_id=user.id,
            profile_photo=path,
            is_ai_profile_photo=bool(photo_check.get("is_ai_generated")),
            profile_photo_label=photo_check.get("label") if photo_check.get("is_ai_generated") else None,
        )
        db.session.add(profile)
        db.session.commit()

        token = generate_token(user.email)
        verify_url = url_for("auth.verify_email", token=token, _external=True)
        send_email(
            user.email,
            "Verify Your Email - Nila Social",
            f"Welcome to Nila Social!\n\nClick the link to verify your email:\n{verify_url}\n\nThis link expires in 1 hour.",
        )

        if photo_check.get("is_ai_generated"):
            flash("Account created. Your profile photo was labeled as AI-generated.", "warning")
        else:
            flash("Account created! Complete your profile next.", "success")
        login_user(user)
        return redirect(url_for("auth.profile_setup"))
    return render_template("auth/register.html", form=form)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.feed"))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and user.check_password(form.password.data):
            if not user.is_active_account:
                reason = user.deactivated_reason or "Your account has been deactivated."
                flash(reason, "danger")
                return redirect(url_for("auth.login"))
            login_user(user, remember=form.remember_me.data)
            user.last_seen = datetime.utcnow()
            db.session.commit()
            next_page = request.args.get("next")
            from app.utils.helpers import is_safe_redirect
            if not is_safe_redirect(next_page):
                next_page = None
            flash("Welcome back!", "success")
            return redirect(next_page or url_for("main.feed"))
        flash("Invalid email or password.", "danger")
    return render_template("auth/login.html", form=form)


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("auth.login"))


@auth_bp.route("/verify/<token>")
def verify_email(token):
    email = confirm_token(token)
    if not email:
        flash("The verification link is invalid or expired.", "danger")
        return redirect(url_for("auth.login"))
    user = User.query.filter_by(email=email).first()
    if user and user.email_verified:
        flash("Email already verified. Please log in.", "info")
    elif user:
        user.email_verified = True
        db.session.commit()
        flash("Email verified successfully!", "success")
    return redirect(url_for("auth.login"))


@auth_bp.route("/profile-setup", methods=["GET", "POST"])
@login_required
def profile_setup():
    form = ProfileSetupForm()
    if form.validate_on_submit():
        profile = current_user.profile or Profile(user_id=current_user.id)
        profile.full_name = form.full_name.data
        profile.bio = form.bio.data
        if form.profile_photo.data:
            from app.utils.helpers import save_uploaded_file
            from app.services.ai_age_gate import analyze_profile_photo
            check = analyze_profile_photo(form.profile_photo.data)
            if not check.get("allowed"):
                flash(
                    "Profile photo rejected: "
                    + "; ".join(check.get("reasons") or ["heavily edited photos are not allowed."]),
                    "danger",
                )
                return render_template("auth/profile_setup.html", form=form)
            path = save_uploaded_file(
                form.profile_photo.data, "profiles", current_app.config["ALLOWED_IMAGE_EXTENSIONS"]
            )
            if path:
                profile.profile_photo = path
                profile.is_ai_profile_photo = bool(check.get("is_ai_generated"))
                profile.profile_photo_label = check.get("label") if check.get("is_ai_generated") else None
                if check.get("is_ai_generated"):
                    flash("Profile photo saved and labeled as AI-generated.", "warning")
        db.session.add(profile)
        db.session.commit()
        flash("Profile setup complete!", "success")
        return redirect(url_for("main.feed"))
    return render_template("auth/profile_setup.html", form=form)


@auth_bp.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if current_user.is_authenticated:
        return redirect(url_for("main.feed"))
    form = ForgotPasswordForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user:
            token = generate_token(user.email, salt="password-reset")
            reset_url = url_for("auth.reset_password", token=token, _external=True)
            send_email(
                user.email,
                "Password Reset - Nila Social",
                f"Click the link to reset your password:\n{reset_url}\n\nThis link expires in 1 hour.",
            )
        flash("If that email exists, a reset link has been sent.", "info")
        return redirect(url_for("auth.login"))
    return render_template("auth/forgot_password.html", form=form)


@auth_bp.route("/reset-password/<token>", methods=["GET", "POST"])
def reset_password(token):
    email = confirm_token(token, salt="password-reset")
    if not email:
        flash("The reset link is invalid or expired.", "danger")
        return redirect(url_for("auth.forgot_password"))
    form = ResetPasswordForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=email).first()
        if user:
            user.set_password(form.password.data)
            db.session.commit()
            flash("Password reset successfully! Please log in.", "success")
            return redirect(url_for("auth.login"))
    return render_template("auth/reset_password.html", form=form)
