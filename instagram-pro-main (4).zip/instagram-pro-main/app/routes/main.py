"""Main blueprint: home feed and landing page."""
from flask import Blueprint, render_template, redirect, url_for, request
from flask_login import current_user, login_required

from app.models.user import User
from app.services.ai_feed import get_recommended_posts
from app.utils.helpers import story_tray_for_user

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    """Landing page or redirect to feed if logged in."""
    if current_user.is_authenticated:
        return redirect(url_for("main.feed"))
    return render_template("index.html")


@main_bp.route("/feed")
@login_required
def feed():
    """Home feed — posts + stories tray + suggested reels."""
    from app.models.reel import Reel
    from app.utils.helpers import filter_visible_reels

    page = request.args.get("page", 1, type=int)
    per_page = 12
    posts = get_recommended_posts(current_user.id, limit=per_page, offset=(page - 1) * per_page)

    tray = story_tray_for_user(current_user)

    following_ids = [f.followed_id for f in current_user.following if f.accepted]
    following_ids.append(current_user.id)
    following_ids_set = set(following_ids)
    suggested = (
        User.query
        .filter(~User.id.in_(following_ids_set))
        .limit(5)
        .all()
    )

    suggested_reels = (
        filter_visible_reels(Reel.query)
        .order_by(Reel.created_at.desc())
        .limit(12)
        .all()
    )

    return render_template(
        "feed.html",
        posts=posts,
        own_story=tray["own_story"],
        story_users=tray["story_users"],
        suggested_users=suggested,
        suggested_reels=suggested_reels,
        page=page,
    )
