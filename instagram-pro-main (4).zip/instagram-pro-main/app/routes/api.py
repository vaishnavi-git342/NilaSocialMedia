"""API blueprint: JSON endpoints for like, save, follow, story reactions, online status, etc."""
from flask import Blueprint, request, jsonify, current_app
from flask_login import current_user, login_required
from app.extensions import db
from app.models.post import Post
from app.models.like import Like
from app.models.saved_post import SavedPost
from app.models.follow import Follow
from app.models.reel import Reel
from app.models.story import Story
from app.models.notification import Notification
from app.utils.helpers import create_notification, can_view_post, can_view_reel, can_view_story
from functools import wraps

api_bp = Blueprint("api", __name__)


def ai_safe(fn):
    """Wrap AI endpoints so model failures return JSON 503 instead of 500."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except Exception as exc:
            current_app.logger.exception("AI endpoint error in %s", fn.__name__)
            return jsonify({"error": "AI unavailable", "detail": str(exc)}), 503
    return wrapper


@api_bp.route("/post/<int:post_id>/like", methods=["POST"])
@login_required
def toggle_like(post_id):
    post = Post.query.get_or_404(post_id)
    if not can_view_post(current_user, post):
        return jsonify({"error": "Forbidden"}), 403
    existing = Like.query.filter_by(user_id=current_user.id, post_id=post_id).first()
    if existing:
        db.session.delete(existing)
        liked = False
    else:
        like = Like(user_id=current_user.id, post_id=post_id)
        db.session.add(like)
        create_notification(post.user_id, current_user.id, "like", f"{current_user.username} liked your post.", post_id=post_id)
        liked = True
    db.session.commit()
    return jsonify({"liked": liked, "count": post.like_count})


@api_bp.route("/post/<int:post_id>/save", methods=["POST"])
@login_required
def toggle_save(post_id):
    post = Post.query.get_or_404(post_id)
    if not can_view_post(current_user, post):
        return jsonify({"error": "Forbidden"}), 403
    existing = SavedPost.query.filter_by(user_id=current_user.id, post_id=post_id).first()
    if existing:
        db.session.delete(existing)
        saved = False
    else:
        s = SavedPost(user_id=current_user.id, post_id=post_id)
        db.session.add(s)
        saved = True
    db.session.commit()
    return jsonify({"saved": saved})


@api_bp.route("/reel/<int:reel_id>/like", methods=["POST"])
@login_required
def toggle_reel_like(reel_id):
    reel = Reel.query.get_or_404(reel_id)
    if not can_view_reel(current_user, reel):
        return jsonify({"error": "Forbidden"}), 403
    existing = Like.query.filter_by(user_id=current_user.id, reel_id=reel_id).first()
    if existing:
        db.session.delete(existing)
        liked = False
    else:
        like = Like(user_id=current_user.id, reel_id=reel_id)
        db.session.add(like)
        create_notification(reel.user_id, current_user.id, "like", f"{current_user.username} liked your reel.", reel_id=reel_id)
        liked = True
    db.session.commit()
    return jsonify({"liked": liked, "count": reel.like_count})


@api_bp.route("/story/<int:story_id>/react", methods=["POST"])
@login_required
def story_react(story_id):
    story = Story.query.get_or_404(story_id)
    if not can_view_story(current_user, story):
        return jsonify({"error": "Forbidden"}), 403
    if story.user_id == current_user.id:
        return jsonify({"error": "Cannot reply to your own story"}), 400
    data = request.get_json(silent=True) or {}
    emoji = (data.get("emoji") or "❤️")[:8]
    create_notification(
        story.user_id,
        current_user.id,
        "story_like",
        f"{current_user.username} reacted {emoji} to your story.",
        story_id=story_id,
    )
    db.session.commit()
    return jsonify({"ok": True})


@api_bp.route("/user/<int:user_id>/follow", methods=["POST"])
@login_required
def toggle_follow(user_id):
    if user_id == current_user.id:
        return jsonify({"error": "Cannot follow yourself"}), 400
    if current_user.is_blocked_with(user_id):
        return jsonify({"error": "Cannot follow a blocked user"}), 403
    existing = Follow.query.filter_by(follower_id=current_user.id, followed_id=user_id).first()
    if existing:
        db.session.delete(existing)
        following = False
        pending = False
    else:
        f = Follow(follower_id=current_user.id, followed_id=user_id)
        db.session.add(f)
        from app.models.user import User
        target = User.query.get(user_id)
        if target and target.is_private:
            f.accepted = False
            pending = True
            create_notification(user_id, current_user.id, "follow", f"{current_user.username} requested to follow you.")
        else:
            pending = False
            create_notification(user_id, current_user.id, "follow", f"{current_user.username} started following you.")
        following = not pending
    db.session.commit()
    from app.models.user import User
    target = User.query.get_or_404(user_id)
    return jsonify({
        "following": following,
        "pending": pending,
        "followers": target.follower_count,
    })


@api_bp.route("/user/<int:user_id>/block", methods=["POST"])
@login_required
def toggle_block(user_id):
    """Block or unblock a user (Instagram-style)."""
    from app.models.user import User
    from app.utils.helpers import apply_block_user, remove_block_user

    if user_id == current_user.id:
        return jsonify({"error": "Cannot block yourself"}), 400
    User.query.get_or_404(user_id)
    if current_user.has_blocked(user_id):
        remove_block_user(current_user.id, user_id)
        db.session.commit()
        return jsonify({"blocked": False, "message": "User unblocked"})
    apply_block_user(current_user.id, user_id)
    db.session.commit()
    return jsonify({"blocked": True, "message": "User blocked"})


@api_bp.route("/user/<int:user_id>/mute", methods=["POST"])
@login_required
def toggle_mute(user_id):
    from app.models.user import User
    from app.utils.helpers import toggle_mute_user
    if user_id == current_user.id:
        return jsonify({"error": "Cannot mute yourself"}), 400
    User.query.get_or_404(user_id)
    muted = toggle_mute_user(current_user.id, user_id)
    db.session.commit()
    return jsonify({"muted": muted, "message": "User muted" if muted else "User unmuted"})


@api_bp.route("/user/<int:user_id>/restrict", methods=["POST"])
@login_required
def toggle_restrict(user_id):
    from app.models.user import User
    from app.utils.helpers import toggle_restrict_user
    if user_id == current_user.id:
        return jsonify({"error": "Cannot restrict yourself"}), 400
    User.query.get_or_404(user_id)
    restricted = toggle_restrict_user(current_user.id, user_id)
    db.session.commit()
    return jsonify({
        "restricted": restricted,
        "message": "User restricted" if restricted else "Restriction removed",
    })


@api_bp.route("/post/<int:post_id>/not-interested", methods=["POST"])
@login_required
def not_interested(post_id):
    from app.models.social_controls import HiddenPost
    post = Post.query.get_or_404(post_id)
    if post.user_id == current_user.id:
        return jsonify({"error": "Cannot hide your own post"}), 400
    existing = HiddenPost.query.filter_by(user_id=current_user.id, post_id=post_id).first()
    if existing:
        db.session.delete(existing)
        db.session.commit()
        return jsonify({"hidden": False})
    db.session.add(HiddenPost(user_id=current_user.id, post_id=post_id))
    db.session.commit()
    return jsonify({"hidden": True, "message": "We'll show fewer posts like this"})


@api_bp.route("/post/<int:post_id>/comments-toggle", methods=["POST"])
@login_required
def toggle_comments(post_id):
    post = Post.query.get_or_404(post_id)
    if post.user_id != current_user.id:
        return jsonify({"error": "Forbidden"}), 403
    post.comments_disabled = not bool(post.comments_disabled)
    db.session.commit()
    return jsonify({"comments_disabled": post.comments_disabled})


@api_bp.route("/post/<int:post_id>/hide-likes", methods=["POST"])
@login_required
def toggle_hide_likes(post_id):
    post = Post.query.get_or_404(post_id)
    if post.user_id != current_user.id:
        return jsonify({"error": "Forbidden"}), 403
    post.hide_like_count = not bool(post.hide_like_count)
    db.session.commit()
    return jsonify({"hide_like_count": post.hide_like_count})


@api_bp.route("/post/<int:post_id>/archive", methods=["POST"])
@login_required
def toggle_archive(post_id):
    post = Post.query.get_or_404(post_id)
    if post.user_id != current_user.id:
        return jsonify({"error": "Forbidden"}), 403
    post.is_archived = not bool(post.is_archived)
    db.session.commit()
    return jsonify({"archived": post.is_archived})


@api_bp.route("/comment/<int:comment_id>/like", methods=["POST"])
@login_required
def toggle_comment_like(comment_id):
    from app.models.comment import Comment
    from app.models.social_controls import CommentLike
    comment = Comment.query.get_or_404(comment_id)
    existing = CommentLike.query.filter_by(user_id=current_user.id, comment_id=comment_id).first()
    if existing:
        db.session.delete(existing)
        liked = False
    else:
        db.session.add(CommentLike(user_id=current_user.id, comment_id=comment_id))
        liked = True
        if comment.user_id != current_user.id:
            create_notification(
                comment.user_id,
                current_user.id,
                "like",
                f"{current_user.username} liked your comment.",
                post_id=comment.post_id,
            )
    db.session.commit()
    return jsonify({"liked": liked, "count": comment.like_count})


@api_bp.route("/comment/<int:comment_id>/pin", methods=["POST"])
@login_required
def pin_comment(comment_id):
    from app.models.comment import Comment
    comment = Comment.query.get_or_404(comment_id)
    if not comment.post or comment.post.user_id != current_user.id:
        return jsonify({"error": "Only the post owner can pin comments"}), 403
    # Unpin others on same post
    for c in comment.post.comments:
        if c.id != comment.id and c.is_pinned:
            c.is_pinned = False
    comment.is_pinned = not bool(comment.is_pinned)
    db.session.commit()
    return jsonify({"pinned": comment.is_pinned})


@api_bp.route("/comment/<int:comment_id>/report", methods=["POST"])
@login_required
def report_comment(comment_id):
    from app.models.comment import Comment
    from app.models.report import Report
    comment = Comment.query.get_or_404(comment_id)
    data = request.get_json(silent=True) or {}
    reason = (data.get("reason") or "Inappropriate comment").strip()[:255]
    db.session.add(Report(
        comment_id=comment_id,
        post_id=comment.post_id,
        reported_user_id=comment.user_id,
        reporter_id=current_user.id,
        reason=reason,
    ))
    db.session.commit()
    return jsonify({"ok": True, "message": "Comment reported"})


@api_bp.route("/user/<int:user_id>/report", methods=["POST"])
@login_required
def report_user(user_id):
    from app.models.user import User
    from app.models.report import Report
    if user_id == current_user.id:
        return jsonify({"error": "Cannot report yourself"}), 400
    User.query.get_or_404(user_id)
    data = request.get_json(silent=True) or {}
    reason = (data.get("reason") or "Inappropriate account").strip()[:255]
    db.session.add(Report(
        reported_user_id=user_id,
        reporter_id=current_user.id,
        reason=reason,
    ))
    db.session.commit()
    return jsonify({"ok": True, "message": "User reported. Thanks for letting us know."})


@api_bp.route("/comment/<int:comment_id>/delete", methods=["POST"])
@login_required
def api_delete_comment(comment_id):
    from app.models.comment import Comment
    from app.models.reel import Reel

    comment = Comment.query.get_or_404(comment_id)
    allowed = comment.user_id == current_user.id
    if comment.post and comment.post.user_id == current_user.id:
        allowed = True
    if comment.reel_id:
        reel = Reel.query.get(comment.reel_id)
        if reel and reel.user_id == current_user.id:
            allowed = True
    if not allowed:
        return jsonify({"error": "Forbidden"}), 403
    db.session.delete(comment)
    db.session.commit()
    return jsonify({"ok": True, "deleted": True})


@api_bp.route("/ai/comment-check", methods=["POST"])
@login_required
@ai_safe
def ai_comment_check():
    data = request.get_json(silent=True) or {}
    text = data.get("comment") or data.get("text") or data.get("caption") or ""
    from app.services.ai_comment_mod import moderate_comment
    return jsonify(moderate_comment(text))


@api_bp.route("/user/<int:user_id>/follow/accept", methods=["POST"])
@login_required
def accept_follow(user_id):
    """Accept a pending follow request."""
    follow = Follow.query.filter_by(follower_id=user_id, followed_id=current_user.id, accepted=False).first_or_404()
    follow.accepted = True
    create_notification(user_id, current_user.id, "follow", f"{current_user.username} accepted your follow request.")
    db.session.commit()
    return jsonify({"ok": True, "followers": current_user.follower_count})


@api_bp.route("/user/<int:user_id>/follow/reject", methods=["POST"])
@login_required
def reject_follow(user_id):
    """Reject / delete a pending follow request."""
    follow = Follow.query.filter_by(follower_id=user_id, followed_id=current_user.id, accepted=False).first_or_404()
    db.session.delete(follow)
    db.session.commit()
    return jsonify({"ok": True, "followers": current_user.follower_count})


@api_bp.route("/ai/caption", methods=["POST"])
@login_required
@ai_safe
def ai_caption():
    """Generate captions from uploaded image (preferred) or text fallback."""
    image_path = _save_temp_ai_image()
    from app.services.ai_caption import suggest_captions
    captions = suggest_captions(image_path or "")
    return jsonify({"captions": captions, "engine": _ai_engine_name()})


@api_bp.route("/ai/hashtags", methods=["POST"])
@login_required
@ai_safe
def ai_hashtags():
    """Generate hashtags from uploaded image and/or caption text."""
    image_path = _save_temp_ai_image()
    caption = ""
    if request.is_json:
        caption = (request.get_json(silent=True) or {}).get("caption", "")
    else:
        caption = request.form.get("caption", "")
    from app.services.ai_hashtags import recommend_hashtags
    tags = recommend_hashtags(image_path or "", caption=caption)
    return jsonify({"hashtags": tags, "engine": _ai_engine_name()})


@api_bp.route("/ai/analyze", methods=["POST"])
@login_required
@ai_safe
def ai_analyze():
    """Full local AI analysis: caption + hashtags + labels from image."""
    image_path = _save_temp_ai_image()
    if not image_path:
        return jsonify({"error": "Please upload an image first."}), 400
    from app.services.ai_engine import analyze_image
    result = analyze_image(image_path)
    return jsonify(result)


@api_bp.route("/ai/status")
@login_required
def ai_status():
    from app.services.ai_engine import get_ai_status
    from app.services.ai_vision import clip_status
    status = get_ai_status()
    status["clip"] = clip_status()
    status["features"] = {
        "caption": True,
        "hashtags": True,
        "clip_zero_shot": True,
        "faces": True,
        "nsfw": True,
        "spam": True,
        "toxicity": True,
        "video_frames": True,
        "quality": True,
        "location": True,
        "engagement": True,
        "similar": True,
        "alt_text": True,
        "smart_replies": True,
        "story_ideas": True,
        "bio": True,
        "music": True,
        "bilingual": True,
        "places": True,
        "privacy_meter": True,
        "safety_score": True,
        "reel_best_frame": True,
        "journey": True,
        "festival": True,
        "comment_moderation": True,
        "block": True,
        "mute": True,
        "restrict": True,
        "comment_likes": True,
        "not_interested": True,
        "archive": True,
    }
    try:
        from app.services.feature_flags import features_for_user
        controlled = features_for_user(current_user)
        status["features"].update(controlled)
        status["features"]["ai_studio"] = controlled.get("ai_studio", True)
        if not controlled.get("ai_studio", True):
            for k in ("caption", "hashtags", "bilingual", "places", "privacy_meter", "safety_score"):
                status["features"][k] = False
    except Exception:
        pass
    return jsonify(status)


@api_bp.route("/ai/moderate", methods=["POST"])
@login_required
@ai_safe
def ai_moderate():
    image_path = _save_temp_ai_image()
    caption = ""
    if request.is_json:
        caption = (request.get_json(silent=True) or {}).get("caption", "")
    else:
        caption = request.form.get("caption", "")
    from app.services.ai_moderation import moderate_content
    report = moderate_content(caption, image_path)
    return jsonify(report)


@api_bp.route("/ai/mood", methods=["POST"])
@login_required
@ai_safe
def ai_mood():
    data = request.get_json(silent=True) or {}
    text = data.get("caption") or data.get("text") or ""
    from app.services.ai_mood import detect_mood_from_text, get_mood_emoji
    mood = detect_mood_from_text(text) or "relaxed"
    return jsonify({"mood": mood, "emoji": get_mood_emoji(mood)})


@api_bp.route("/ai/quality", methods=["POST"])
@login_required
@ai_safe
def ai_quality():
    image_path = _save_temp_ai_image()
    if not image_path:
        return jsonify({"error": "Upload an image first."}), 400
    from app.services.ai_quality import analyze_image_quality, suggest_filter
    return jsonify({
        "quality": analyze_image_quality(image_path),
        "filter": suggest_filter(image_path),
    })


@api_bp.route("/ai/location", methods=["POST"])
@login_required
@ai_safe
def ai_location():
    image_path = _save_temp_ai_image()
    if not image_path:
        return jsonify({"error": "Upload an image first."}), 400
    from app.services.ai_location import suggest_locations
    return jsonify({"locations": suggest_locations(image_path)})


@api_bp.route("/ai/engagement", methods=["POST"])
@login_required
@ai_safe
def ai_engagement():
    image_path = _save_temp_ai_image()
    if request.is_json:
        data = request.get_json(silent=True) or {}
        caption = data.get("caption", "")
        has_location = bool(data.get("location"))
    else:
        caption = request.form.get("caption", "")
        has_location = bool(request.form.get("location"))
    from app.services.ai_engagement import predict_engagement
    return jsonify(predict_engagement(caption=caption, image_path=image_path or "", has_location=has_location))


@api_bp.route("/ai/similar", methods=["POST"])
@login_required
@ai_safe
def ai_similar():
    image_path = _save_temp_ai_image()
    if request.is_json:
        data = request.get_json(silent=True) or {}
        caption = data.get("caption", "")
    else:
        caption = request.form.get("caption", "")
    from app.services.ai_similar import find_similar_posts
    return jsonify({"similar": find_similar_posts(caption=caption, image_path=image_path or "")})


@api_bp.route("/ai/alt-text", methods=["POST"])
@login_required
@ai_safe
def ai_alt_text():
    image_path = _save_temp_ai_image()
    if not image_path:
        return jsonify({"error": "Upload an image first."}), 400
    from app.services.ai_alt_text import generate_caption_styles
    return jsonify(generate_caption_styles(image_path))


@api_bp.route("/ai/replies", methods=["POST"])
@login_required
@ai_safe
def ai_replies():
    data = request.get_json(silent=True) or {}
    from app.services.ai_reply import suggest_replies
    replies = suggest_replies(data.get("comment", ""), data.get("caption", ""))
    return jsonify({"replies": replies})


@api_bp.route("/ai/story-ideas")
@login_required
@ai_safe
def ai_story_ideas():
    from app.services.ai_story_ideas import generate_story_ideas
    return jsonify({"ideas": generate_story_ideas(current_user.id)})


@api_bp.route("/ai/bio", methods=["POST"])
@login_required
@ai_safe
def ai_bio():
    data = request.get_json(silent=True) or {}
    name = data.get("name") or (current_user.profile.full_name if current_user.profile else current_user.username)
    place = data.get("location") or "Kerala"
    from app.services.ai_bio import generate_bios
    return jsonify({"bios": generate_bios(full_name=name, location_hint=place)})


@api_bp.route("/ai/music", methods=["POST"])
@login_required
@ai_safe
def ai_music():
    image_path = _save_temp_ai_image()
    if request.is_json:
        data = request.get_json(silent=True) or {}
        caption = data.get("caption", "")
        mood = data.get("mood", "")
    else:
        caption = request.form.get("caption", "")
        mood = request.form.get("mood", "")
    from app.services.ai_music import recommend_music_for_reel
    tracks = recommend_music_for_reel(caption=caption, mood=mood, image_path=image_path or "")
    return jsonify({"tracks": tracks})


@api_bp.route("/ai/bilingual", methods=["POST"])
@login_required
@ai_safe
def ai_bilingual():
    image_path = _save_temp_ai_image()
    if request.is_json:
        data = request.get_json(silent=True) or {}
        caption = data.get("caption", "")
    else:
        caption = request.form.get("caption", "")
    from app.services.ai_bilingual import bilingual_caption, generate_bilingual_from_image
    if image_path and not caption:
        return jsonify(generate_bilingual_from_image(image_path))
    from app.services.ai_mood import detect_mood_from_text
    mood = detect_mood_from_text(caption)
    return jsonify(bilingual_caption(caption, mood=mood))


@api_bp.route("/ai/places", methods=["POST"])
@login_required
@ai_safe
def ai_places():
    image_path = _save_temp_ai_image()
    if request.is_json:
        hint = (request.get_json(silent=True) or {}).get("location", "")
    else:
        hint = request.form.get("location", "")
    from app.services.ai_places import place_intelligence
    return jsonify(place_intelligence(image_path=image_path or "", location_hint=hint))


@api_bp.route("/ai/privacy", methods=["POST"])
@login_required
@ai_safe
def ai_privacy():
    data = request.get_json(silent=True) or {}
    audience = data.get("audience", "auto")
    from app.services.ai_privacy import privacy_clarity
    return jsonify(privacy_clarity(current_user, audience=audience))


@api_bp.route("/ai/safety", methods=["POST"])
@login_required
@ai_safe
def ai_safety():
    image_path = _save_temp_ai_image()
    if request.is_json:
        caption = (request.get_json(silent=True) or {}).get("caption", "")
    else:
        caption = request.form.get("caption", "")
    from app.services.ai_safety import community_safety_score
    return jsonify(community_safety_score(text=caption, image_path=image_path or ""))


@api_bp.route("/ai/reel-frames", methods=["POST"])
@login_required
@ai_safe
def ai_reel_frames():
    """Extract best thumbnail frames from an uploaded reel video."""
    import os
    from werkzeug.utils import secure_filename
    file = request.files.get("video") or request.files.get("image") or request.files.get("media")
    if not file or not file.filename:
        return jsonify({"error": "Upload a video first."}), 400
    ext = file.filename.rsplit(".", 1)[-1].lower()
    if ext not in {"mp4", "webm", "mov"}:
        return jsonify({"error": "Video files only."}), 400
    tmp_dir = os.path.join(current_app.config["UPLOAD_FOLDER"], "tmp_ai")
    os.makedirs(tmp_dir, exist_ok=True)
    path = os.path.join(tmp_dir, secure_filename(f"reel_{current_user.id}_{file.filename}"))
    file.save(path)
    from app.services.ai_reel_frames import extract_best_frames
    frames = extract_best_frames(path, count=3, out_dir=tmp_dir)
    # Return relative static-ish paths for preview messaging
    def _rel(path):
        upload = str(current_app.config["UPLOAD_FOLDER"]).replace("\\", "/")
        pth = str(path).replace("\\", "/")
        if pth.startswith(upload):
            return "uploads/" + pth[len(upload):].lstrip("/")
        if "uploads/" in pth:
            return "uploads/" + pth.split("uploads/", 1)[1]
        return os.path.basename(path)

    safe_frames = [
        {"score": f["score"], "index": f["index"], "rank": f["rank"], "path": _rel(f["path"])}
        for f in frames
    ]
    best = dict(safe_frames[0]) if safe_frames else None
    return jsonify({"frames": safe_frames, "best": best})


@api_bp.route("/reel/<int:reel_id>/view", methods=["POST"])
@login_required
def reel_view_ping(reel_id):
    from flask import session
    reel = Reel.query.get_or_404(reel_id)
    key = f"reel_viewed_{reel_id}"
    if not session.get(key):
        reel.views = (reel.views or 0) + 1
        db.session.commit()
        session[key] = True
    return jsonify({"ok": True, "views": reel.views})


def _save_temp_ai_image() -> str | None:
    """Persist an uploaded image for AI analysis; return absolute path."""
    import os
    from werkzeug.utils import secure_filename

    file = request.files.get("image") or request.files.get("media")
    if not file or not file.filename:
        return None
    ext = file.filename.rsplit(".", 1)[-1].lower()
    if ext not in {"jpg", "jpeg", "png", "gif", "webp"}:
        return None
    tmp_dir = os.path.join(current_app.config["UPLOAD_FOLDER"], "tmp_ai")
    os.makedirs(tmp_dir, exist_ok=True)
    name = secure_filename(f"ai_{current_user.id}_{file.filename}")
    path = os.path.join(tmp_dir, name)
    file.save(path)
    return path


def _ai_engine_name() -> str:
    from app.services.ai_engine import get_ai_status
    status = get_ai_status()
    return status.get("model") or "fallback"


@api_bp.route("/user/online-status")
@login_required
def online_status():
    """Placeholder for online status — returns current user only."""
    return jsonify({"online": True, "user_id": current_user.id})
