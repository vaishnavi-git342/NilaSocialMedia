"""Read-only real Instagram viewer (instagrapi), gated by INSTAGRAM_LIVE + feature flag."""
from flask import Blueprint, render_template, current_app, abort, request
from flask_login import login_required
from app.utils.decorators import feature_required

live_bp = Blueprint("live", __name__)


@live_bp.route("/instagram")
@login_required
@feature_required("live_instagram")
def instagram_feed():
    if not current_app.config.get("INSTAGRAM_LIVE"):
        abort(404)

    from app.services.instagram_live import (
        fetch_timeline_posts,
        fetch_own_posts,
        fetch_user_posts,
        live_status,
    )

    view = request.args.get("view", "timeline")
    target = (request.args.get("u") or "").strip().lstrip("@")

    if view == "own":
        result = fetch_own_posts()
    elif view == "user" and target:
        result = fetch_user_posts(target)
    else:
        view = "timeline"
        result = fetch_timeline_posts()

    return render_template(
        "live/instagram.html",
        result=result,
        status=live_status(),
        view=view,
        target=target,
    )
