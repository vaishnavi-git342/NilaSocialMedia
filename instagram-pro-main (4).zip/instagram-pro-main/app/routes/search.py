"""Search blueprint: users, posts, and hashtags."""
from flask import Blueprint, render_template, request
from flask_login import login_required
from app.services.ai_search import (
    smart_user_search,
    smart_post_search,
    smart_hashtag_search,
    smart_reel_search,
)

search_bp = Blueprint("search", __name__)


@search_bp.route("/", methods=["GET"])
@login_required
def index():
    query = (request.args.get("query") or request.args.get("q") or "").strip()
    tab = (request.args.get("tab") or "top").strip().lower()
    if tab not in {"top", "accounts", "hashtags", "posts", "reels"}:
        tab = "top"
    results = {"users": [], "posts": [], "hashtags": [], "reels": []}

    if query:
        results["users"] = smart_user_search(query)
        results["posts"] = smart_post_search(query)
        results["hashtags"] = smart_hashtag_search(query)
        results["reels"] = smart_reel_search(query)

    return render_template("search/index.html", query=query, results=results, tab=tab)
