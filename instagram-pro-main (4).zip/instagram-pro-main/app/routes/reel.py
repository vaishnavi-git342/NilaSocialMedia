"""Reel blueprint: upload, view feed, like, comment."""
from flask import Blueprint, render_template, redirect, url_for, flash, request, abort, jsonify
from flask_login import current_user, login_required
from app.extensions import db
from app.models.reel import Reel
from app.models.comment import Comment
from app.forms.reel import ReelForm
from app.forms.post import CommentForm
from app.utils.helpers import save_uploaded_file, create_notification, can_view_reel, filter_visible_reels
from flask import current_app
import os

reel_bp = Blueprint("reel", __name__)


@reel_bp.route("/")
@login_required
def feed():
    page = request.args.get("page", 1, type=int)
    per_page = current_app.config.get("REELS_PER_PAGE", 10)
    reels = (
        filter_visible_reels(Reel.query)
        .order_by(Reel.created_at.desc())
        .offset((page - 1) * per_page)
        .limit(per_page)
        .all()
    )
    return render_template("reels/feed.html", reels=reels, page=page)


def _upload_error(message, ajax):
    if ajax:
        return jsonify({"ok": False, "error": message}), 400
    flash(message, "danger")
    return None


@reel_bp.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    form = ReelForm()
    ajax = request.headers.get("X-Requested-With") == "XMLHttpRequest"
    if form.validate_on_submit():
        allowed = set(current_app.config["ALLOWED_VIDEO_EXTENSIONS"]) | set(
            current_app.config["ALLOWED_IMAGE_EXTENSIONS"]
        )
        path = save_uploaded_file(form.video.data, "reels", allowed)
        audio_path = None
        if form.audio.data:
            audio_path = save_uploaded_file(
                form.audio.data, "audio", current_app.config["ALLOWED_AUDIO_EXTENSIONS"]
            )
            if not audio_path:
                failed = _upload_error("That song could not be saved. Use mp3, wav, m4a, ogg, or aac.", ajax)
                if failed:
                    return failed
                return render_template("reels/upload.html", form=form)
        if not path:
            failed = _upload_error("Add a video or photo.", ajax)
            if failed:
                return failed
            return render_template("reels/upload.html", form=form)

        abs_path = os.path.join(current_app.config["UPLOAD_FOLDER"], path.replace("uploads/", "", 1))
        caption = (form.caption.data or "").strip()
        thumbnail = None
        is_image = path.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".webp"))
        from app.services.ai_spam import is_spam
        from app.services.ai_toxicity import is_toxic

        if caption and (is_spam(caption) or is_toxic(caption)):
            failed = _upload_error("Reel flagged by moderation. Please revise the caption.", ajax)
            if failed:
                return failed
            return render_template("reels/upload.html", form=form)

        if is_image:
            thumbnail = path
        else:
            try:
                import shutil
                from app.services.ai_reel_frames import best_thumbnail

                frame = best_thumbnail(abs_path)
                if frame and os.path.isfile(frame):
                    reels_dir = os.path.join(current_app.config["UPLOAD_FOLDER"], "reels")
                    os.makedirs(reels_dir, exist_ok=True)
                    thumb_name = os.path.basename(frame)
                    dest = os.path.join(reels_dir, thumb_name)
                    if os.path.abspath(frame) != os.path.abspath(dest):
                        shutil.copy2(frame, dest)
                    thumbnail = f"uploads/reels/{thumb_name}"
            except Exception:
                thumbnail = None

        title = (form.audio_name.data or "").strip()
        if audio_path and not title:
            title = os.path.splitext(os.path.basename(audio_path))[0]
        elif not audio_path and not is_image:
            title = title or "Original audio"
        reel = Reel(
            user_id=current_user.id,
            filename=path,
            thumbnail=thumbnail,
            caption=caption,
            audio_name=title or None,
            audio_filename=audio_path,
        )
        try:
            from app.services.ai_age_gate import rate_image_quick
            rate_path = abs_path
            if thumbnail:
                thumb_abs = os.path.join(
                    current_app.config["UPLOAD_FOLDER"],
                    thumbnail.replace("uploads/", "", 1),
                )
                if os.path.isfile(thumb_abs):
                    rate_path = thumb_abs
            rating = rate_image_quick(rate_path)
            reel.is_adult_content = bool(rating.get("is_adult_content"))
            reel.content_rating = rating.get("rating") or "general"
            if reel.is_adult_content and not current_user.is_adult:
                failed = _upload_error("This content can't be published on your account.", ajax)
                if failed:
                    return failed
                return render_template("reels/upload.html", form=form)
        except Exception:
            reel.is_adult_content = False
            reel.content_rating = "general"
        db.session.add(reel)
        db.session.commit()
        if ajax:
            return jsonify({"ok": True, "redirect": url_for("reel.feed")})
        flash("Reel shared!", "success")
        return redirect(url_for("reel.feed"))
    if ajax and request.method == "POST":
        message = "Check the video, audio, and caption, then try again."
        for field in form:
            if field.errors:
                message = field.errors[0]
                break
        return jsonify({"ok": False, "error": message}), 400
    return render_template("reels/upload.html", form=form)


@reel_bp.route("/<int:reel_id>/delete", methods=["POST"])
@login_required
def delete(reel_id):
    reel = Reel.query.get_or_404(reel_id)
    is_staff = bool(getattr(current_user, "is_admin", False) or getattr(current_user, "is_super_admin", False))
    if reel.user_id != current_user.id and not is_staff:
        abort(403)
    from app.models.notification import Notification
    Notification.query.filter_by(reel_id=reel_id).delete(synchronize_session=False)
    for rel in (reel.filename, reel.thumbnail):
        if not rel:
            continue
        try:
            rel_path = rel.replace("uploads/", "", 1) if rel.startswith("uploads/") else rel
            abs_path = os.path.join(current_app.config["UPLOAD_FOLDER"], rel_path)
            if os.path.isfile(abs_path):
                os.remove(abs_path)
        except OSError:
            pass
    db.session.delete(reel)
    db.session.commit()
    flash("Reel deleted.", "info")
    return redirect(url_for("profile.view", username=current_user.username, tab="reels"))


@reel_bp.route("/<int:reel_id>")
@login_required
def view(reel_id):
    reel = Reel.query.get_or_404(reel_id)
    if not can_view_reel(current_user, reel):
        abort(403)
    comment_form = CommentForm()
    return render_template("reels/view.html", reel=reel, comment_form=comment_form)


@reel_bp.route("/<int:reel_id>/view", methods=["POST"])
@login_required
def register_view(reel_id):
    """Increment view count once per session per reel."""
    reel = Reel.query.get_or_404(reel_id)
    key = f"reel_viewed_{reel_id}"
    from flask import session
    if not session.get(key):
        reel.views = (reel.views or 0) + 1
        db.session.commit()
        session[key] = True
    return {"ok": True, "views": reel.views}


@reel_bp.route("/<int:reel_id>/comment", methods=["POST"])
@login_required
def comment(reel_id):
    reel = Reel.query.get_or_404(reel_id)
    if not can_view_reel(current_user, reel):
        abort(403)
    if current_user.is_blocked_with(reel.user_id):
        flash("You can't comment on this reel.", "danger")
        return redirect(url_for("reel.view", reel_id=reel_id))
    form = CommentForm()
    if form.validate_on_submit():
        from app.services.ai_comment_mod import moderate_comment
        owner_filters = getattr(reel.user, "filter_offensive_comments", True)
        verdict = moderate_comment(form.body.data)
        if owner_filters and verdict["action"] == "reject":
            flash(verdict["message"], "danger")
            return redirect(url_for("reel.view", reel_id=reel_id))
        c = Comment(
            user_id=current_user.id,
            reel_id=reel_id,
            body=form.body.data,
            moderation_status="ok" if verdict["action"] == "allow" else "flagged",
            moderation_reason=verdict.get("reason"),
        )
        db.session.add(c)
        create_notification(
            reel.user_id,
            current_user.id,
            "comment",
            f"{current_user.username} commented on your reel.",
            reel_id=reel_id,
        )
        db.session.commit()
        flash("Comment added!", "success")
    return redirect(url_for("reel.view", reel_id=reel_id))
