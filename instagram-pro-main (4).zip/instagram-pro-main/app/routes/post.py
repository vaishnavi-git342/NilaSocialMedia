"""Post blueprint: create, view, like, comment, save, delete, report."""
from datetime import datetime, timedelta
import uuid
from flask import Blueprint, render_template, redirect, url_for, flash, abort, request, jsonify, session
from flask_login import current_user, login_required
from app.extensions import db
from app.models.post import Post, PostImage
from app.models.comment import Comment, Reply
from app.models.like import Like
from app.models.saved_post import SavedPost
from app.models.hashtag import Hashtag, PostHashtag
from app.models.report import Report
from app.models.notification import Notification
from app.forms.post import PostForm, CommentForm, ReportForm
from app.utils.helpers import (
    save_uploaded_file,
    create_notification,
    can_view_post,
    cleanup_post_dependencies,
    visible_comments_for,
)
from flask import current_app
import re

post_bp = Blueprint("post", __name__)


def extract_hashtags(caption: str, post: Post):
    """Extract #hashtags from caption and create Hashtag/PostHashtag records."""
    if not caption:
        return
    tags = set(re.findall(r"#(\w+)", caption))
    for tag_name in tags:
        tag = Hashtag.query.filter_by(name=tag_name.lower()).first()
        if not tag:
            tag = Hashtag(name=tag_name.lower())
            db.session.add(tag)
            db.session.flush()
        link = PostHashtag(post_id=post.id, hashtag_id=tag.id)
        db.session.add(link)


@post_bp.route("/create", methods=["GET", "POST"])
@login_required
def create():
    form = PostForm()
    if form.validate_on_submit():
        token = (request.form.get("post_token") or "").strip()
        if not token or token != session.get("post_token"):
            flash("That post was already shared.", "info")
            return redirect(url_for("main.feed"))
        ext = form.media.data.filename.rsplit(".", 1)[1].lower()
        is_video = ext in {"mp4", "webm", "mov"}

        path = save_uploaded_file(
            form.media.data,
            "posts",
            current_app.config["ALLOWED_IMAGE_EXTENSIONS"] | current_app.config["ALLOWED_VIDEO_EXTENSIONS"],
        )
        audio_path = None
        if form.audio.data:
            audio_path = save_uploaded_file(
                form.audio.data,
                "audio",
                current_app.config["ALLOWED_AUDIO_EXTENSIONS"],
            )
            if not audio_path:
                flash("That song could not be saved. Use mp3, wav, m4a, ogg, or aac.", "danger")
                return render_template("post/create.html", form=form, post_token=session.get("post_token"))
        if not path:
            flash("Could not save media file.", "danger")
            return render_template("post/create.html", form=form, post_token=session.get("post_token"))

        # AI moderation gate
        abs_media = None
        try:
            import os
            abs_media = os.path.join(str(current_app.config["UPLOAD_FOLDER"]), path.replace("uploads/", "", 1))
            from app.services.ai_moderation import moderate_content
            report = moderate_content(form.caption.data or "", None if is_video else abs_media)
            if not report.get("is_safe"):
                flash("Content flagged by AI moderation (spam/toxicity/NSFW). Please revise.", "danger")
                return render_template("post/create.html", form=form, post_token=session.get("post_token"))
        except Exception:
            pass

        tag_bits = []
        for token in re.split(r"[\s,]+", form.hashtags.data or ""):
            token = token.strip().lstrip("#")
            if token:
                tag_bits.append("#" + token)
        clean_caption = (form.caption.data or "").strip()
        if tag_bits:
            clean_caption = (clean_caption + " " + " ".join(tag_bits)).strip()
        song_title = (form.audio_name.data or "").strip()
        if audio_path and not song_title:
            import os
            song_title = os.path.splitext(os.path.basename(audio_path))[0]
        post = Post(
            user_id=current_user.id,
            caption=clean_caption,
            location=form.location.data,
            is_video=is_video,
            audio_filename=audio_path,
            audio_name=song_title or None,
        )
        try:
            from app.services.ai_age_gate import rate_media_file
            import os
            abs_for_rate = os.path.join(str(current_app.config["UPLOAD_FOLDER"]), path.replace("uploads/", "", 1))
            rating = rate_media_file(abs_for_rate, form.caption.data or "")
            post.is_adult_content = bool(rating.get("is_adult_content"))
            post.content_rating = rating.get("rating") or "general"
            if post.is_adult_content and not current_user.is_adult:
                flash("This content can't be published on your account.", "danger")
                return render_template("post/create.html", form=form, post_token=session.get("post_token"))
        except Exception:
            pass
        db.session.add(post)
        db.session.flush()

        img = PostImage(post_id=post.id, filename=path, position=0, is_video=is_video)
        db.session.add(img)

        extract_hashtags(clean_caption, post)

        try:
            from app.services.ai_mood import detect_mood_from_text
            from app.models.mood import Mood, PostMood
            mood_name = detect_mood_from_text(form.caption.data or "")
            if mood_name:
                mood = Mood.query.filter_by(name=mood_name).first()
                if mood:
                    db.session.add(PostMood(post_id=post.id, mood_id=mood.id))
        except Exception:
            pass

        session.pop("post_token", None)
        if request.form.get("share_story") == "on":
            from app.models.story import Story
            db.session.add(Story(
                user_id=current_user.id,
                filename=path,
                is_video=is_video,
                caption=(clean_caption or "")[:255] or None,
                audio_filename=audio_path,
                expires_at=datetime.utcnow() + timedelta(hours=48),
            ))
        db.session.commit()
        flash("Post shared successfully!", "success")
        return redirect(url_for("main.feed"))
    token = uuid.uuid4().hex
    session["post_token"] = token
    return render_template("post/create.html", form=form, post_token=token)


def _comment_redirect(parent: Comment):
    if parent.post_id:
        return redirect(url_for("post.view", post_id=parent.post_id))
    if parent.reel_id:
        return redirect(url_for("reel.view", reel_id=parent.reel_id))
    return redirect(url_for("main.feed"))


@post_bp.route("/<int:post_id>")
def view(post_id):
    post = Post.query.get_or_404(post_id)
    if not can_view_post(current_user, post):
        abort(403)
    if getattr(post, "is_archived", False) and (
        not current_user.is_authenticated or current_user.id != post.user_id
    ):
        abort(404)
    comment_form = CommentForm()
    comments = visible_comments_for(post, current_user)
    return render_template(
        "post/view.html",
        post=post,
        comment_form=comment_form,
        comments=comments,
    )


@post_bp.route("/<int:post_id>/delete", methods=["POST"])
@login_required
def delete(post_id):
    post = Post.query.get_or_404(post_id)
    is_staff = bool(getattr(current_user, "is_admin", False) or getattr(current_user, "is_super_admin", False))
    if post.user_id != current_user.id and not is_staff:
        abort(403)
    try:
        from app.models.social_controls import CommentLike
        comment_ids = [c.id for c in Comment.query.filter_by(post_id=post.id).all()]
        if comment_ids:
            Reply.query.filter(Reply.comment_id.in_(comment_ids)).delete(synchronize_session=False)
            CommentLike.query.filter(CommentLike.comment_id.in_(comment_ids)).delete(synchronize_session=False)
            Comment.query.filter(Comment.id.in_(comment_ids)).delete(synchronize_session=False)
        cleanup_post_dependencies(post.id)
        db.session.delete(post)
        db.session.commit()
    except Exception:
        db.session.rollback()
        current_app.logger.exception("Post delete failed for %s", post_id)
        flash("Could not delete that post. Try again.", "danger")
        return redirect(request.referrer or url_for("main.feed"))
    flash("Post deleted.", "info")
    return redirect(url_for("profile.view", username=current_user.username))


@post_bp.route("/<int:post_id>/comment", methods=["POST"])
@login_required
def comment(post_id):
    post = Post.query.get_or_404(post_id)
    if not can_view_post(current_user, post):
        abort(403)
    if getattr(post, "comments_disabled", False):
        flash("Comments are turned off for this post.", "info")
        return redirect(url_for("post.view", post_id=post_id))
    if current_user.is_blocked_with(post.user_id):
        flash("You can't comment on this post.", "danger")
        return redirect(url_for("post.view", post_id=post_id))
    form = CommentForm()
    if form.validate_on_submit():
        from app.services.ai_comment_mod import moderate_comment
        owner_filters = getattr(post.user, "filter_offensive_comments", True)
        verdict = moderate_comment(form.body.data)
        if owner_filters and verdict["action"] == "reject":
            flash(verdict["message"], "danger")
            return redirect(url_for("post.view", post_id=post_id))
        c = Comment(
            user_id=current_user.id,
            post_id=post_id,
            body=form.body.data,
            moderation_status="ok" if verdict["action"] == "allow" else "flagged",
            moderation_reason=verdict.get("reason"),
        )
        db.session.add(c)
        create_notification(post.user_id, current_user.id, "comment", f"{current_user.username} commented on your post.", post_id=post_id)
        db.session.commit()
        flash("Comment added!", "success")
    return redirect(url_for("post.view", post_id=post_id))


@post_bp.route("/comment/<int:comment_id>/reply", methods=["POST"])
@login_required
def reply(comment_id):
    parent = Comment.query.get_or_404(comment_id)
    body = request.form.get("body", "").strip()
    if body:
        # Block check vs comment author / content owner
        owner_id = parent.user_id
        if parent.post_id and parent.post:
            owner_id = parent.post.user_id
        elif parent.reel_id:
            from app.models.reel import Reel
            reel = Reel.query.get(parent.reel_id)
            if reel:
                owner_id = reel.user_id
        if current_user.is_blocked_with(owner_id) or current_user.is_blocked_with(parent.user_id):
            flash("You can't reply here.", "danger")
            return _comment_redirect(parent)
        from app.services.ai_comment_mod import moderate_comment
        verdict = moderate_comment(body)
        if verdict["action"] == "reject":
            flash(verdict["message"], "danger")
            return _comment_redirect(parent)
        r = Reply(comment_id=comment_id, user_id=current_user.id, body=body)
        db.session.add(r)
        create_notification(parent.user_id, current_user.id, "comment", f"{current_user.username} replied to your comment.")
        db.session.commit()
        flash("Reply added!", "success")
    return _comment_redirect(parent)


@post_bp.route("/comment/<int:comment_id>/delete", methods=["POST"])
@login_required
def delete_comment(comment_id):
    """Author or post/reel owner can delete a comment (Instagram-style)."""
    comment = Comment.query.get_or_404(comment_id)
    allowed = comment.user_id == current_user.id
    if comment.post_id and comment.post and comment.post.user_id == current_user.id:
        allowed = True
    if comment.reel_id:
        from app.models.reel import Reel
        reel = Reel.query.get(comment.reel_id)
        if reel and reel.user_id == current_user.id:
            allowed = True
    if not allowed:
        abort(403)
    redirect_target = _comment_redirect(comment)
    db.session.delete(comment)
    db.session.commit()
    flash("Comment deleted.", "info")
    return redirect_target


@post_bp.route("/<int:post_id>/report", methods=["GET", "POST"])
@login_required
def report(post_id):
    post = Post.query.get_or_404(post_id)
    if not can_view_post(current_user, post):
        abort(403)
    form = ReportForm()
    if form.validate_on_submit():
        r = Report(post_id=post_id, reporter_id=current_user.id, reason=form.reason.data)
        db.session.add(r)
        db.session.commit()
        flash("Report submitted. Thank you.", "info")
        return redirect(url_for("post.view", post_id=post_id))
    return render_template("post/report.html", form=form, post=post)
