"""Messaging blueprint: conversations and direct messages."""
from sqlalchemy import or_
from flask import Blueprint, render_template, redirect, url_for, flash, abort, request
from flask_login import current_user, login_required
from app.extensions import db
from app.models.user import User
from app.models.message import Conversation, Message
from app.forms.message import MessageForm
from app.utils.helpers import save_uploaded_file
from flask import current_app

message_bp = Blueprint("message", __name__)


def get_or_create_conversation(user_id: int, partner_id: int) -> Conversation:
    """One shared conversation per user pair (canonical ordered ids)."""
    a, b = (user_id, partner_id) if user_id < partner_id else (partner_id, user_id)
    conv = Conversation.query.filter_by(user_id=a, partner_id=b).first()
    if conv:
        return conv
    conv = Conversation(user_id=a, partner_id=b)
    db.session.add(conv)
    db.session.commit()
    return conv


def conversation_partner(conv: Conversation, viewer_id: int) -> User:
    """Return the other user in a shared conversation."""
    other_id = conv.partner_id if conv.user_id == viewer_id else conv.user_id
    return User.query.get(other_id)


@message_bp.route("/")
@login_required
def inbox():
    """List all conversations for the current user."""
    conversations = (
        Conversation.query.filter(
            or_(
                Conversation.user_id == current_user.id,
                Conversation.partner_id == current_user.id,
            )
        )
        .order_by(Conversation.created_at.desc())
        .all()
    )
    inbox_items = []
    for conv in conversations:
        partner = conversation_partner(conv, current_user.id)
        if partner:
            inbox_items.append({"conversation": conv, "partner": partner})
    return render_template("messages/inbox.html", inbox_items=inbox_items)


@message_bp.route("/<int:partner_id>", methods=["GET", "POST"])
@login_required
def chat(partner_id):
    """View and send messages in a conversation with a specific user."""
    partner = User.query.get_or_404(partner_id)
    if partner_id == current_user.id:
        flash("You cannot message yourself.", "info")
        return redirect(url_for("message.inbox"))

    if current_user.is_blocked_with(partner_id):
        flash("You can't message this user.", "danger")
        return redirect(url_for("message.inbox"))

    conv = get_or_create_conversation(current_user.id, partner_id)
    form = MessageForm()

    if form.validate_on_submit():
        image_path = None
        if form.image.data:
            image_path = save_uploaded_file(
                form.image.data,
                "messages",
                current_app.config["ALLOWED_IMAGE_EXTENSIONS"],
            )

        body = (form.body.data or "").strip()
        if not body and not image_path:
            flash("Type a message or attach an image.", "warning")
            return redirect(url_for("message.chat", partner_id=partner_id))

        from app.services.ai_toxicity import is_toxic
        if body and is_toxic(body):
            flash("Message blocked by AI toxicity filter.", "danger")
            return redirect(url_for("message.chat", partner_id=partner_id))

        msg = Message(
            conversation_id=conv.id,
            sender_id=current_user.id,
            body=body or None,
            image_filename=image_path,
        )
        db.session.add(msg)
        db.session.commit()
        return redirect(url_for("message.chat", partner_id=partner_id))

    # Mark messages from partner as seen
    Message.query.filter(
        Message.conversation_id == conv.id,
        Message.sender_id == partner_id,
        Message.is_seen.is_(False),
    ).update({"is_seen": True})
    db.session.commit()

    messages = (
        Message.query.filter_by(conversation_id=conv.id)
        .order_by(Message.created_at)
        .all()
    )
    return render_template(
        "messages/chat.html",
        partner=partner,
        messages=messages,
        form=form,
    )


@message_bp.route("/start/<int:user_id>")
@login_required
def start(user_id):
    """Start a new conversation with a user."""
    if current_user.is_blocked_with(user_id):
        flash("You can't message this user.", "danger")
        return redirect(url_for("message.inbox"))
    return redirect(url_for("message.chat", partner_id=user_id))
