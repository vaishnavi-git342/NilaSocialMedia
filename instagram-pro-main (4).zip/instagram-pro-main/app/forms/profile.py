"""Profile editing form."""
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, TextAreaField, SubmitField
from wtforms.validators import Length, Optional, URL


class EditProfileForm(FlaskForm):
    full_name = StringField("Full Name", validators=[Optional(), Length(max=120)])
    bio = TextAreaField("Bio", validators=[Optional(), Length(max=500)])
    website = StringField("Website", validators=[Optional(), Length(max=255), URL()])
    profile_photo = FileField("Profile Photo", validators=[
        FileAllowed(["jpg", "jpeg", "png", "webp"], "Images only.")
    ])
    cover_photo = FileField("Cover Photo", validators=[
        FileAllowed(["jpg", "jpeg", "png", "webp"], "Images only.")
    ])
    gender = StringField("Gender", validators=[Optional(), Length(max=20)])
    submit = SubmitField("Save Changes")
