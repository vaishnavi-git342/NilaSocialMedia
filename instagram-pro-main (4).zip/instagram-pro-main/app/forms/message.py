"""Message and conversation forms."""
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import TextAreaField, StringField, SubmitField, IntegerField
from wtforms.validators import DataRequired, Length, Optional


class MessageForm(FlaskForm):
    body = TextAreaField("Message", validators=[Optional(), Length(max=2000)])
    image = FileField("Image", validators=[
        FileAllowed(["jpg", "jpeg", "png", "webp", "gif"], "Images only.")
    ])
    submit = SubmitField("Send")


class ConversationForm(FlaskForm):
    partner_id = IntegerField("Partner ID", validators=[DataRequired()])
    submit = SubmitField("Start Conversation")
