"""Movie review form."""
from flask_wtf import FlaskForm
from wtforms import IntegerField, StringField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Length, NumberRange


class MovieReviewForm(FlaskForm):
    movie_title = StringField(
        "Movie",
        validators=[DataRequired(), Length(min=1, max=160)],
    )
    rating = IntegerField(
        "Rating",
        default=4,
        validators=[DataRequired(), NumberRange(min=1, max=5)],
    )
    body = TextAreaField(
        "Review",
        validators=[DataRequired(), Length(min=10, max=2000)],
    )
    submit = SubmitField("Post review")
