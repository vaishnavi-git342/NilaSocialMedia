"""Import all forms for convenience."""
from app.forms.auth import (
    LoginForm, RegisterForm, ForgotPasswordForm, ResetPasswordForm,
    ProfileSetupForm, EmailVerificationForm,
)
from app.forms.profile import EditProfileForm
from app.forms.post import PostForm, CommentForm, ReportForm
from app.forms.story import StoryForm
from app.forms.reel import ReelForm
from app.forms.message import MessageForm, ConversationForm
from app.forms.settings import (
    ChangePasswordForm, EmailChangeForm, PrivacySettingsForm,
    DeleteAccountForm,
)
from app.forms.search import SearchForm
