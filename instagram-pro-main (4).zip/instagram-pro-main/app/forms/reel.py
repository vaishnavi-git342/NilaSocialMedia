"""Reel upload form — video or photo reel."""
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed, FileRequired
from wtforms import TextAreaField, StringField, SubmitField
from wtforms.validators import Optional, Length


class ReelForm(FlaskForm):
    video = FileField(
        "Reel (video or photo)",
        validators=[
            FileRequired(message="Choose a video or image for your reel."),
            FileAllowed(
                ["mp4", "webm", "mov", "jpg", "jpeg", "png", "webp", "gif"],
                "Videos (mp4/webm/mov) or images only.",
            ),
        ],
    )
    caption = TextAreaField("Caption", validators=[Optional(), Length(max=2200)])
    audio = FileField("Audio", validators=[
        Optional(),
        FileAllowed(["mp3", "wav", "m4a", "ogg", "aac"], "Use mp3, wav, m4a, ogg, or aac."),
    ])
    audio_name = StringField("Audio title", validators=[Optional(), Length(max=255)])
    submit = SubmitField("Share Reel")
