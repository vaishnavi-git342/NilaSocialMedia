"""Authentication-related forms."""
from email_validator import EmailNotValidError, validate_email

from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed, FileRequired
from wtforms import (
    StringField, PasswordField, BooleanField, SubmitField,
    TextAreaField, DateField, ValidationError,
)
from wtforms.validators import DataRequired, Email, Length, EqualTo

from app.models.user import User


def allow_app_email(form, field):
    """Accept normal emails and the app's own @nila.local accounts."""
    value = (field.data or "").strip()
    field.data = value
    local, _, domain = value.lower().rpartition("@")
    if domain == "nila.local" and local:
        return
    try:
        validate_email(value, check_deliverability=False)
    except EmailNotValidError as exc:
        raise ValidationError("Invalid email address.") from exc


class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), allow_app_email])
    password = PasswordField("Password", validators=[DataRequired()])
    remember_me = BooleanField("Remember Me")
    submit = SubmitField("Log In")


class RegisterForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired(), Length(min=3, max=30)])
    email = StringField("Email", validators=[DataRequired(), Email()])
    birth_date = DateField("Date of birth", validators=[DataRequired()], format="%Y-%m-%d")
    password = PasswordField("Password", validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField(
        "Confirm Password", validators=[DataRequired(), EqualTo("password", "Passwords must match.")]
    )
    profile_photo = FileField(
        "Profile photo",
        validators=[
            FileRequired(message="Profile photo is required."),
            FileAllowed(["jpg", "jpeg", "png", "webp"], "Images only."),
        ],
    )
    submit = SubmitField("Sign Up")

    def validate_username(self, field):
        if User.query.filter_by(username=field.data).first():
            raise ValidationError("Username already taken.")

    def validate_email(self, field):
        if User.query.filter_by(email=field.data).first():
            raise ValidationError("Email already registered.")

    def validate_birth_date(self, field):
        from app.services.ai_age_gate import age_from_birth_date
        years = age_from_birth_date(field.data)
        if years is None:
            raise ValidationError("Enter a valid date of birth.")
        if years < 13:
            raise ValidationError("You must be at least 13 years old to register.")


class ProfileSetupForm(FlaskForm):
    full_name = StringField("Full Name", validators=[Length(max=120)])
    bio = TextAreaField("Bio", validators=[Length(max=500)])
    profile_photo = FileField("Profile Photo", validators=[
        FileAllowed(["jpg", "jpeg", "png", "webp"], "Images only.")
    ])
    submit = SubmitField("Complete Setup")


class EmailVerificationForm(FlaskForm):
    code = StringField("Verification Code", validators=[DataRequired(), Length(min=6, max=6)])
    submit = SubmitField("Verify")


class ForgotPasswordForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), allow_app_email])
    submit = SubmitField("Send Reset Link")

    def validate_email(self, field):
        if not User.query.filter_by(email=field.data).first():
            raise ValidationError("No account found with that email.")


class ResetPasswordForm(FlaskForm):
    password = PasswordField("New Password", validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField(
        "Confirm Password", validators=[DataRequired(), EqualTo("password", "Passwords must match.")]
    )
    submit = SubmitField("Reset Password")
