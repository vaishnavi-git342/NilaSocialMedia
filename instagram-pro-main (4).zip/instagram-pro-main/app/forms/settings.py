"""Settings-related forms."""
from flask_wtf import FlaskForm
from wtforms import (
    PasswordField, StringField, BooleanField, SubmitField, ValidationError,
)
from wtforms.validators import DataRequired, Email, Length, EqualTo

from app.models.user import User


class ChangePasswordForm(FlaskForm):
    current_password = PasswordField("Current Password", validators=[DataRequired()])
    new_password = PasswordField("New Password", validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField(
        "Confirm New Password", validators=[DataRequired(), EqualTo("new_password", "Passwords must match.")]
    )
    submit = SubmitField("Change Password")


class EmailChangeForm(FlaskForm):
    new_email = StringField("New Email", validators=[DataRequired(), Email()])
    password = PasswordField("Current Password", validators=[DataRequired()])
    submit = SubmitField("Update Email")

    def validate_new_email(self, field):
        from flask_login import current_user
        existing = User.query.filter_by(email=field.data).first()
        if existing and (not current_user.is_authenticated or existing.id != current_user.id):
            raise ValidationError("Email already in use.")


class PrivacySettingsForm(FlaskForm):
    is_private = BooleanField("Private Account")
    dark_mode = BooleanField("Dark Mode")
    filter_offensive_comments = BooleanField("AI filter offensive comments")
    submit = SubmitField("Save Settings")


class DeleteAccountForm(FlaskForm):
    password = PasswordField("Password", validators=[DataRequired()])
    confirm = StringField("Type DELETE to confirm", validators=[DataRequired(), Length(min=6, max=6)])
    submit = SubmitField("Delete My Account")

    def validate_confirm(self, field):
        if field.data != "DELETE":
            raise ValidationError("Please type DELETE exactly to confirm.")
