"""Story upload form."""
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed, FileRequired
from wtforms import StringField, SubmitField
from wtforms.validators import Optional, Length


class StoryForm(FlaskForm):
    media = FileField("Story Media", validators=[
        FileRequired(),
        FileAllowed(["jpg", "jpeg", "png", "webp", "mp4", "webm", "mov"], "Images or videos only."),
    ])
    caption = StringField("Caption", validators=[Optional(), Length(max=255)])
    audio = FileField("Audio", validators=[
        Optional(),
        FileAllowed(["mp3", "wav", "m4a", "ogg", "aac"], "Use mp3, wav, m4a, ogg, or aac."),
    ])
    submit = SubmitField("Add to Story")
