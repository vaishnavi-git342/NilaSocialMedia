"""Post, comment, and report forms."""
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed, FileRequired
from wtforms import StringField, TextAreaField, SubmitField, SelectField
from wtforms.validators import DataRequired, Length, Optional


class PostForm(FlaskForm):
    media = FileField("Upload Media", validators=[
        FileRequired(),
        FileAllowed(
            ["jpg", "jpeg", "png", "gif", "webp", "mp4", "webm", "mov"],
            "Images or videos only.",
        ),
    ])
    caption = TextAreaField("Caption", validators=[Optional(), Length(max=2200)])
    hashtags = StringField("Hashtags", validators=[Optional(), Length(max=500)])
    location = StringField("Location", validators=[Optional(), Length(max=255)])
    audio = FileField("Song", validators=[
        Optional(),
        FileAllowed(["mp3", "wav", "m4a", "ogg", "aac"], "Use mp3, wav, m4a, ogg, or aac."),
    ])
    audio_name = StringField("Song title", validators=[Optional(), Length(max=255)])
    submit = SubmitField("Share")


class CommentForm(FlaskForm):
    body = TextAreaField("Comment", validators=[DataRequired(), Length(max=1000)])
    submit = SubmitField("Post")


class ReportForm(FlaskForm):
    reason = SelectField("Reason", choices=[
        ("spam", "Spam"),
        ("nudity", "Nudity or sexual activity"),
        ("hate", "Hate speech"),
        ("violence", "Violence or dangerous organizations"),
        ("harassment", "Harassment or bullying"),
        ("misinformation", "Misinformation"),
        ("other", "Other"),
    ], validators=[DataRequired()])
    submit = SubmitField("Submit Report")
