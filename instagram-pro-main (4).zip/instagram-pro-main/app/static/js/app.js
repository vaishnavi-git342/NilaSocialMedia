/* ============================================
   Instagram Clone - Enhanced JavaScript
   ============================================ */

// --- CSRF Token Helper ---
function getCSRFToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (meta) return meta.content;
    const input = document.querySelector('input[name="csrf_token"]');
    return input ? input.value : '';
}

// --- API Call Helper ---
async function apiCall(url, method = 'POST', body = null) {
    const headers = {
        'X-CSRFToken': getCSRFToken(),
    };
    if (body && !(body instanceof FormData)) {
        headers['Content-Type'] = 'application/json';
    }
    const options = { method, headers, credentials: 'same-origin' };
    if (body && method.toUpperCase() !== 'GET' && method.toUpperCase() !== 'HEAD') {
        options.body = body instanceof FormData ? body : JSON.stringify(body);
    }
    try {
        const res = await fetch(url, options);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    } catch (err) {
        console.error('API call failed:', err);
        showToast('Something went wrong. Please try again.', 'danger');
        return null;
    }
}

// --- Toast Notification ---
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `ig-flash ig-flash-${type} fade-in`;
    const iconMap = {
        success: 'bi-check-circle-fill',
        danger: 'bi-exclamation-circle-fill',
        warning: 'bi-exclamation-triangle-fill',
        info: 'bi-info-circle-fill'
    };
    toast.innerHTML = `
        <div class="ig-flash-icon"><i class="bi ${iconMap[type] || iconMap.info}"></i></div>
        <div class="ig-flash-message">${message}</div>
        <button type="button" class="ig-flash-close" onclick="this.parentElement.remove()"><i class="bi bi-x"></i></button>
    `;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 5000);
}

// --- Toggle Like on Post ---
async function toggleLike(postId, btn) {
    const result = await apiCall(`/api/post/${postId}/like`);
    if (!result) return;
    const icon = btn.querySelector('i');
    if (result.liked) {
        icon.className = 'bi bi-heart-fill';
        btn.classList.add('liked');
    } else {
        icon.className = 'bi bi-heart';
        btn.classList.remove('liked');
    }
    const likesEl = btn.closest('.ig-post-card')?.querySelector('.ig-post-likes');
    if (likesEl) likesEl.textContent = `${result.count} likes`;
}

// --- Double-tap to Like ---
function doubleTapLike(postId, mediaEl) {
    // Show heart burst animation
    const heart = document.createElement('div');
    heart.className = 'ig-heart-burst';
    heart.innerHTML = '<i class="bi bi-heart-fill"></i>';
    mediaEl.appendChild(heart);
    setTimeout(() => heart.remove(), 800);

    // Like the post
    const card = mediaEl.closest('.ig-post-card');
    const likeBtn = card?.querySelector('.like-btn');
    if (likeBtn && !likeBtn.classList.contains('liked')) {
        toggleLike(postId, likeBtn);
    }
}

// --- Toggle Save on Post ---
async function toggleSave(postId, btn) {
    const result = await apiCall(`/api/post/${postId}/save`);
    if (!result) return;
    const icon = btn.querySelector('i');
    if (result.saved) {
        icon.className = 'bi bi-bookmark-fill';
        btn.classList.add('saved');
        showToast('Post saved!', 'success');
    } else {
        icon.className = 'bi bi-bookmark';
        btn.classList.remove('saved');
        showToast('Post removed from saved.', 'info');
    }
}

function toggleSaveFromMenu(postId) {
    const card = document.querySelector(`.ig-post-card[data-post-id="${postId}"]`);
    const saveBtn = card?.querySelector('.save-btn');
    if (saveBtn) toggleSave(postId, saveBtn);
}

// --- Toggle Like on Reel ---
async function toggleReelLike(reelId, btn) {
    const result = await apiCall(`/api/reel/${reelId}/like`);
    if (!result) return;
    const icon = btn.querySelector('i');
    const countSpan = btn.querySelector('span');
    if (result.liked) {
        icon.className = 'bi bi-heart-fill';
        btn.classList.add('liked');
    } else {
        icon.className = 'bi bi-heart';
        btn.classList.remove('liked');
    }
    if (countSpan) countSpan.textContent = result.count;
}

// --- Toggle Follow ---
async function toggleFollow(userId, btn) {
    const result = await apiCall(`/api/user/${userId}/follow`);
    if (!result) return;
    if (result.pending) {
        btn.textContent = 'Requested';
        btn.classList.remove('btn-primary', 'ig-btn-primary');
        btn.classList.add('btn-outline-secondary');
    } else if (result.following) {
        btn.textContent = 'Following';
        btn.classList.remove('btn-primary', 'ig-btn-primary');
        btn.classList.add('btn-outline-secondary');
    } else {
        btn.textContent = 'Follow';
        btn.classList.remove('btn-outline-secondary');
        btn.classList.add('btn-primary', 'ig-btn-primary');
    }
}

async function acceptFollow(userId, btn) {
    const result = await apiCall(`/api/user/${userId}/follow/accept`);
    if (!result) return;
    btn.textContent = 'Accepted';
    btn.disabled = true;
    btn.classList.remove('btn-primary', 'ig-btn-primary');
    btn.classList.add('btn-outline-secondary');
    const rejectBtn = btn.parentElement?.querySelector('[onclick*="rejectFollow"]');
    if (rejectBtn) rejectBtn.remove();
    showToast('Follow request accepted', 'success');
}

async function rejectFollow(userId, btn) {
    const result = await apiCall(`/api/user/${userId}/follow/reject`);
    if (!result) return;
    btn.textContent = 'Rejected';
    btn.disabled = true;
    const acceptBtn = btn.parentElement?.querySelector('[onclick*="acceptFollow"]');
    if (acceptBtn) acceptBtn.remove();
    showToast('Follow request rejected', 'info');
}

async function toggleBlock(userId, btn) {
    const result = await apiCall(`/api/user/${userId}/block`);
    if (!result) return;
    if (result.blocked) {
        btn.textContent = 'Unblock';
        showToast('User blocked', 'info');
        // Soft-reload profile UX
        setTimeout(() => location.reload(), 400);
    } else {
        btn.textContent = 'Block';
        showToast('User unblocked', 'success');
        setTimeout(() => location.reload(), 400);
    }
}

async function deleteComment(commentId, btn) {
    if (!confirm('Delete this comment?')) return;
    const result = await apiCall(`/api/comment/${commentId}/delete`);
    if (!result || !result.ok) return;
    const row = btn.closest('.ig-post-comment') || btn.closest('[data-comment-id]');
    if (row) row.remove();
    showToast('Comment deleted', 'info');
}

async function toggleMute(userId, btn) {
    const result = await apiCall(`/api/user/${userId}/mute`);
    if (!result) return;
    showToast(result.message || (result.muted ? 'Muted' : 'Unmuted'), 'info');
    if (btn && btn.tagName) btn.textContent = result.muted ? 'Unmute' : 'Mute';
}

async function toggleRestrict(userId, btn) {
    const result = await apiCall(`/api/user/${userId}/restrict`);
    if (!result) return;
    showToast(result.message || (result.restricted ? 'Restricted' : 'Unrestricted'), 'info');
    if (btn && btn.tagName) btn.textContent = result.restricted ? 'Unrestrict' : 'Restrict';
}

async function reportUser(userId) {
    const reason = prompt('Why are you reporting this account?', 'Spam or fake account');
    if (reason === null) return;
    const result = await apiCall(`/api/user/${userId}/report`, 'POST', { reason });
    if (result) showToast(result.message || 'Reported', 'success');
}

async function reportComment(commentId) {
    const reason = prompt('Why are you reporting this comment?', 'Harassment or spam');
    if (reason === null) return;
    const result = await apiCall(`/api/comment/${commentId}/report`, 'POST', { reason });
    if (result) showToast(result.message || 'Comment reported', 'success');
}

async function toggleCommentLike(commentId, btn) {
    const result = await apiCall(`/api/comment/${commentId}/like`);
    if (!result) return;
    const icon = btn.querySelector('i');
    const count = btn.querySelector('.like-count');
    if (result.liked) {
        btn.classList.add('liked');
        if (icon) icon.className = 'bi bi-heart-fill';
    } else {
        btn.classList.remove('liked');
        if (icon) icon.className = 'bi bi-heart';
    }
    if (count) count.textContent = result.count;
}

async function pinComment(commentId) {
    const result = await apiCall(`/api/comment/${commentId}/pin`);
    if (!result) return;
    showToast(result.pinned ? 'Comment pinned' : 'Comment unpinned', 'success');
    setTimeout(() => location.reload(), 350);
}

async function notInterested(postId, btn) {
    const result = await apiCall(`/api/post/${postId}/not-interested`);
    if (!result) return;
    showToast(result.message || 'Hidden from feed', 'info');
    const card = btn.closest('.ig-post-card') || btn.closest('.ig-post-detail-card');
    if (card) card.remove();
}

async function togglePostComments(postId) {
    const result = await apiCall(`/api/post/${postId}/comments-toggle`);
    if (!result) return;
    showToast(result.comments_disabled ? 'Comments turned off' : 'Comments turned on', 'info');
    setTimeout(() => location.reload(), 350);
}

async function toggleHideLikes(postId) {
    const result = await apiCall(`/api/post/${postId}/hide-likes`);
    if (!result) return;
    showToast(result.hide_like_count ? 'Like count hidden' : 'Like count visible', 'info');
    setTimeout(() => location.reload(), 350);
}

async function toggleArchive(postId) {
    const result = await apiCall(`/api/post/${postId}/archive`);
    if (!result) return;
    showToast(result.archived ? 'Post archived' : 'Post unarchived', 'info');
    setTimeout(() => location.reload(), 350);
}

// --- Reel autoplay + view tracking ---
function setupReelAutoplay() {
    const cards = document.querySelectorAll('.ig-reel-card');
    if (!cards.length) return;
    let soundOn = false;
    const hint = document.getElementById('reelSoundHint');

    const paintMutes = () => {
        document.querySelectorAll('.reel-mute-btn').forEach(btn => {
            btn.innerHTML = soundOn
                ? '<i class="bi bi-volume-up"></i>'
                : '<i class="bi bi-volume-mute"></i>';
        });
    };
    const playVideo = (video, card) => {
        if (!video) return;
        const added = card && card.dataset.addedSong === '1';
        video.muted = added ? true : !soundOn;
        video.playsInline = true;
        const p = video.play();
        if (p && typeof p.catch === 'function') p.catch(() => {});
    };

    const pauseOthers = (exceptCard) => {
        document.querySelectorAll('.ig-reel-card').forEach(card => {
            if (card === exceptCard) return;
            card.querySelectorAll('video, audio').forEach(el => el.pause());
        });
    };
    const playAudio = (card) => {
        const audio = card.querySelector('.reel-audio');
        const video = card.querySelector('video');
        const added = card.dataset.addedSong === '1';
        if (added && audio) {
            if (video) video.muted = true;
            audio.loop = true;
            audio.muted = !soundOn;
            if (!soundOn) {
                audio.pause();
                return;
            }
            const p = audio.play();
            if (p && typeof p.catch === 'function') p.catch(() => {});
            return;
        }
        if (video) video.muted = !soundOn;
    };
    const visibleCard = () => {
        let best = cards[0];
        let bestRatio = 0;
        cards.forEach(card => {
            const rect = card.getBoundingClientRect();
            const visible = Math.max(0, Math.min(rect.bottom, window.innerHeight) - Math.max(rect.top, 0));
            const ratio = visible / Math.max(rect.height, 1);
            if (ratio > bestRatio) { bestRatio = ratio; best = card; }
        });
        return best;
    };

    document.getElementById('reelsFeed')?.addEventListener('pointerdown', (e) => {
        if (soundOn || e.target.closest('video')) return;
        soundOn = true;
        if (hint) hint.remove();
        const card = visibleCard();
        if (card) playAudio(card);
    });
    hint?.addEventListener('click', (e) => {
        e.stopPropagation();
        soundOn = true;
        hint.remove();
        const card = visibleCard();
        if (card) playAudio(card);
    });

    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                const video = entry.target.querySelector('video');
                if (entry.isIntersecting && entry.intersectionRatio >= 0.55) {
                    pauseOthers(entry.target);
                    playVideo(video, entry.target);
                    playAudio(entry.target);
                    const reelId = entry.target.dataset.reelId;
                    if (reelId) {
                        apiCall(`/api/reel/${reelId}/view`, 'POST', {}).then(res => {
                            if (res && typeof res.views === 'number') {
                                const el = entry.target.querySelector('.reel-views');
                                if (el) el.textContent = res.views;
                            }
                        });
                    }
                } else {
                    entry.target.querySelectorAll('video, audio').forEach(el => el.pause());
                }
            });
        }, { threshold: [0.55, 0.75] });

        cards.forEach(card => {
            observer.observe(card);
            const video = card.querySelector('video');
            const mute = card.querySelector('.reel-mute-btn');
            mute?.addEventListener('click', (e) => {
                e.stopPropagation();
                soundOn = !soundOn;
                if (hint) hint.remove();
                paintMutes();
                playAudio(card);
                const video = card.querySelector('video');
                if (video && video.paused) playVideo(video, card);
            });
            if (video) {
                video.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const audio = card.querySelector('.reel-audio');
                    if (!soundOn) {
                        soundOn = true;
                        if (hint) hint.remove();
                        paintMutes();
                        playVideo(video, card);
                        playAudio(card);
                        return;
                    }
                    if (video.paused) {
                        playVideo(video, card);
                        playAudio(card);
                    } else {
                        video.pause();
                        if (audio) audio.pause();
                    }
                });
            }
        });
    }

    paintMutes();
    const firstCard = cards[0];
    const first = firstCard && firstCard.querySelector('video');
    if (first) playVideo(first, firstCard);
}

function setupPostSongs() {
    document.querySelectorAll('.ig-post-song').forEach(row => {
        const audio = row.querySelector('.ig-post-audio');
        const button = row.querySelector('.ig-post-song-btn');
        const card = row.closest('.ig-post-card, .ig-post-detail-card');
        const video = card ? card.querySelector('video') : null;
        if (!audio || !button) return;
        if (video) video.muted = true;
        let on = false;
        const paint = () => {
            button.innerHTML = on ? '<i class="bi bi-volume-up"></i>' : '<i class="bi bi-volume-mute"></i>';
        };
        button.addEventListener('click', () => {
            on = !on;
            audio.muted = !on;
            paint();
            if (on) audio.play().catch(() => {});
            else audio.pause();
        });
        if (video) {
            video.addEventListener('play', () => { if (on) audio.play().catch(() => {}); });
            video.addEventListener('pause', () => audio.pause());
        }
        paint();
    });
}

// --- Share Post ---
function sharePost(postId) {
    const url = `${window.location.origin}/post/${postId}`;
    if (navigator.share) {
        navigator.share({ url }).catch(() => {});
    } else {
        navigator.clipboard.writeText(url).then(() => {
            showToast('Link copied to clipboard!', 'success');
        });
    }
}

function shareReel(reelId) {
    const url = `${window.location.origin}/reels/${reelId}`;
    if (navigator.share) {
        navigator.share({ url }).catch(() => {});
    } else {
        navigator.clipboard.writeText(url).then(() => {
            showToast('Link copied to clipboard!', 'success');
        });
    }
}

function copyLink(postId) {
    const url = `${window.location.origin}/post/${postId}`;
    navigator.clipboard.writeText(url).then(() => {
        showToast('Link copied to clipboard!', 'success');
    });
}

// --- Story Auto-Advance ---
function startStoryTimer(storyId, nextUrl) {
    const progress = document.querySelector('.ig-story-progress');
    if (progress) {
        setTimeout(() => progress.classList.add('animated'), 100);
    }
    setTimeout(() => {
        if (nextUrl) {
            window.location.href = nextUrl;
        }
    }, 5000);
}

// --- Infinite Scroll (placeholder) ---
let loading = false;
let currentPage = 1;

function setupInfiniteScroll() {
    const sentinel = document.getElementById('infiniteScrollSentinel');
    if (!sentinel) return;

    const observer = new IntersectionObserver(async (entries) => {
        if (entries[0].isIntersecting && !loading) {
            loading = true;
            currentPage++;
            const url = `${window.location.pathname}?page=${currentPage}`;
            try {
                const res = await fetch(url);
                const html = await res.text();
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const newPosts = doc.querySelectorAll('.ig-post-card');
                const container = document.querySelector('.ig-feed-posts-list');
                if (container && newPosts.length > 0) {
                    newPosts.forEach(post => container.appendChild(post));
                } else {
                    // No more posts, stop observing
                    observer.unobserve(sentinel);
                }
            } catch (err) {
                console.error('Infinite scroll failed:', err);
            }
            loading = false;
        }
    });
    observer.observe(sentinel);
}

// --- Auto-dismiss Flash Messages ---
document.addEventListener('DOMContentLoaded', () => {
    // Auto-dismiss flash messages
    document.querySelectorAll('[data-auto-dismiss]').forEach(el => {
        const ms = parseInt(el.dataset.autoDismiss) || 5000;
        setTimeout(() => {
            el.style.opacity = '0';
            setTimeout(() => el.remove(), 300);
        }, ms);
    });

    // Setup infinite scroll
    setupInfiniteScroll();
    setupReelAutoplay();
    setupPostSongs();

    // Lazy loading images
    if ('IntersectionObserver' in window) {
        const imgObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                    }
                    observer.unobserve(img);
                }
            });
        });
        document.querySelectorAll('img[data-src]').forEach(img => imgObserver.observe(img));
    }

    // Story auto-advance
    const storyViewer = document.querySelector('.ig-story-viewer');
    if (storyViewer) {
        const nextLink = storyViewer.querySelector('.ig-story-next');
        const nextUrl = nextLink?.getAttribute('href');
        const storyId = storyViewer.dataset.storyId;
        if (storyId) startStoryTimer(storyId, nextUrl);
    }
});
