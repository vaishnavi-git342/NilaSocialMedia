"""Post and PostImage models."""
from datetime import datetime
from app.extensions import db


class Post(db.Model):
    __tablename__ = "posts"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    caption = db.Column(db.Text, nullable=True)
    location = db.Column(db.String(255), nullable=True)
    is_video = db.Column(db.Boolean, default=False, nullable=False)
    is_carousel = db.Column(db.Boolean, default=False, nullable=False)
    comments_disabled = db.Column(db.Boolean, default=False, nullable=False)
    hide_like_count = db.Column(db.Boolean, default=False, nullable=False)
    is_archived = db.Column(db.Boolean, default=False, nullable=False)
    is_adult_content = db.Column(db.Boolean, default=False, nullable=False)
    content_rating = db.Column(db.String(20), default="general", nullable=False)
    audio_filename = db.Column(db.String(512), nullable=True)
    audio_name = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship("User", back_populates="posts")
    images = db.relationship("PostImage", back_populates="post", cascade="all, delete-orphan", order_by="PostImage.position")
    likes = db.relationship("Like", back_populates="post", cascade="all, delete-orphan")
    comments = db.relationship("Comment", back_populates="post", cascade="all, delete-orphan")
    saved_by = db.relationship("SavedPost", back_populates="post", cascade="all, delete-orphan")
    hashtags = db.relationship("PostHashtag", back_populates="post", cascade="all, delete-orphan")
    reports = db.relationship("Report", back_populates="post", cascade="all, delete-orphan")

    @property
    def like_count(self):
        return len(self.likes)

    @property
    def comment_count(self):
        return sum(1 for c in self.comments if getattr(c, "is_visible", True))

    def is_liked_by(self, user_id: int) -> bool:
        return any(l.user_id == user_id for l in self.likes)

    def is_saved_by(self, user_id: int) -> bool:
        return any(s.user_id == user_id for s in self.saved_by)

    def __repr__(self):
        return f"<Post {self.id} by user_id={self.user_id}>"


class PostImage(db.Model):
    __tablename__ = "post_images"

    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=False, index=True)
    filename = db.Column(db.String(512), nullable=False)
    position = db.Column(db.Integer, default=0, nullable=False)
    is_video = db.Column(db.Boolean, default=False, nullable=False)

    post = db.relationship("Post", back_populates="images")

    def __repr__(self):
        return f"<PostImage {self.filename} pos={self.position}>"
