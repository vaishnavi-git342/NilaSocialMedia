"""Community movie reviews written by people on Nila."""
from datetime import datetime
from app.extensions import db


class MovieReview(db.Model):
    __tablename__ = "movie_reviews"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    movie_title = db.Column(db.String(160), nullable=False, index=True)
    rating = db.Column(db.Integer, nullable=False, default=3)
    body = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)

    user = db.relationship("User")

    def __repr__(self):
        return f"<MovieReview {self.id} {self.movie_title!r}>"
