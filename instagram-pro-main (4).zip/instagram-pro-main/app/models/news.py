"""Cached daily news items shown in the updates feed."""
from datetime import datetime
from app.extensions import db


class NewsItem(db.Model):
    __tablename__ = "news_items"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(300), nullable=False)
    summary = db.Column(db.Text, nullable=True)
    url = db.Column(db.String(500), nullable=False, unique=True)
    source = db.Column(db.String(80), nullable=False, default="News")
    published_at = db.Column(db.DateTime, nullable=True)
    fetched_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def __repr__(self):
        return f"<NewsItem {self.id}>"
