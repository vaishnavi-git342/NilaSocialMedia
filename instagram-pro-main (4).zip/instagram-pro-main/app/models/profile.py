"""Profile model for extended user information."""
from datetime import datetime
from app.extensions import db


class Profile(db.Model):
    __tablename__ = "profiles"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, unique=True, index=True)
    full_name = db.Column(db.String(120), nullable=True)
    bio = db.Column(db.Text, nullable=True)
    website = db.Column(db.String(255), nullable=True)
    profile_photo = db.Column(db.String(512), nullable=True)
    cover_photo = db.Column(db.String(512), nullable=True)
    gender = db.Column(db.String(20), nullable=True)
    profile_photo_label = db.Column(db.String(80), nullable=True)  # e.g. AI-generated
    is_ai_profile_photo = db.Column(db.Boolean, default=False, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship("User", back_populates="profile")

    def __repr__(self):
        return f"<Profile for user_id={self.user_id}>"
