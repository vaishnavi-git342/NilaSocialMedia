"""User block model — Instagram-style block / unblock."""
from datetime import datetime
from app.extensions import db


class UserBlock(db.Model):
    __tablename__ = "user_blocks"

    id = db.Column(db.Integer, primary_key=True)
    blocker_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    blocked_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    blocker = db.relationship("User", foreign_keys=[blocker_id], backref=db.backref("blocks_made", lazy="dynamic"))
    blocked = db.relationship("User", foreign_keys=[blocked_id], backref=db.backref("blocks_received", lazy="dynamic"))

    __table_args__ = (
        db.UniqueConstraint("blocker_id", "blocked_id", name="uq_user_block"),
    )

    def __repr__(self):
        return f"<UserBlock {self.blocker_id} -> {self.blocked_id}>"
