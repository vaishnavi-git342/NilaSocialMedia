"""Notification model."""
from datetime import datetime
from app.extensions import db


class Notification(db.Model):
    __tablename__ = "notifications"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    actor_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True, index=True)
    type = db.Column(db.String(50), nullable=False)  # like, comment, follow, mention, story_like
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=True)
    story_id = db.Column(db.Integer, db.ForeignKey("stories.id"), nullable=True)
    reel_id = db.Column(db.Integer, db.ForeignKey("reels.id"), nullable=True)
    text = db.Column(db.String(255), nullable=True)
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)

    user = db.relationship("User", back_populates="notifications", foreign_keys=[user_id])
    actor = db.relationship("User", foreign_keys=[actor_id], lazy="joined")
    post = db.relationship("Post", foreign_keys=[post_id], lazy="joined")
    story = db.relationship("Story", foreign_keys=[story_id], lazy="joined")
    reel = db.relationship("Reel", foreign_keys=[reel_id], lazy="joined")

    def __repr__(self):
        return f"<Notification {self.type} for user_id={self.user_id}>"
