"""Import all models so SQLAlchemy and Flask-Migrate can discover them."""
from app.models.user import User
from app.models.profile import Profile
from app.models.post import Post, PostImage
from app.models.like import Like
from app.models.comment import Comment, Reply
from app.models.story import Story, StoryView, StoryHighlight, HighlightItem
from app.models.reel import Reel
from app.models.follow import Follow
from app.models.notification import Notification
from app.models.message import Message, Conversation
from app.models.saved_post import SavedPost
from app.models.hashtag import Hashtag, PostHashtag
from app.models.report import Report
from app.models.ai_recommendation import AIRecommendation
from app.models.mood import Mood, UserMood, PostMood
from app.models.repost import Repost
from app.models.social_features import (
    CloseFriend, BroadcastChannel, BroadcastMessage, BroadcastMember,
)
from app.models.block import UserBlock
from app.models.social_controls import UserMute, UserRestrict, HiddenPost, CommentLike
from app.models.feature_flag import FeatureFlag, UserFeatureOverride
from app.models.news import NewsItem
from app.models.review import MovieReview

__all__ = [
    "User", "Profile", "Post", "PostImage", "Like", "Comment", "Reply",
    "Story", "StoryView", "StoryHighlight", "HighlightItem", "Reel", "Follow",
    "Notification", "Message", "Conversation", "SavedPost",
    "Hashtag", "PostHashtag", "Report", "AIRecommendation",
    "Mood", "UserMood", "PostMood", "Repost",
    "CloseFriend", "BroadcastChannel", "BroadcastMessage", "BroadcastMember",
    "UserBlock", "UserMute", "UserRestrict", "HiddenPost", "CommentLike",
    "FeatureFlag", "UserFeatureOverride", "NewsItem", "MovieReview",
]
