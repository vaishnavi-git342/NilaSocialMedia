"""Like model for posts and reels."""
from datetime import datetime
from app.extensions import db


class Like(db.Model):
    __tablename__ = "likes"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=True, index=True)
    reel_id = db.Column(db.Integer, db.ForeignKey("reels.id"), nullable=True, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User", back_populates="likes")
    post = db.relationship("Post", back_populates="likes")

    __table_args__ = (
        db.UniqueConstraint("user_id", "post_id", name="uq_user_post_like"),
        db.UniqueConstraint("user_id", "reel_id", name="uq_user_reel_like"),
    )

    def __repr__(self):
        return f"<Like user_id={self.user_id} post_id={self.post_id} reel_id={self.reel_id}>"
