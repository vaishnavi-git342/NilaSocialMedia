"""CloseFriends and BroadcastChannel models."""
from datetime import datetime
from app.extensions import db


class CloseFriend(db.Model):
    """Records who is on a user's close friends list."""
    __tablename__ = "close_friends"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    friend_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User", foreign_keys=[user_id])
    friend = db.relationship("User", foreign_keys=[friend_id])

    __table_args__ = (db.UniqueConstraint("user_id", "friend_id", name="uq_close_friend"),)

    def __repr__(self):
        return f"<CloseFriend user_id={self.user_id} friend_id={self.friend_id}>"


class BroadcastChannel(db.Model):
    """Creator broadcast channels for one-to-many messaging."""
    __tablename__ = "broadcast_channels"

    id = db.Column(db.Integer, primary_key=True)
    creator_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    title = db.Column(db.String(120), nullable=False)
    description = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    creator = db.relationship("User", foreign_keys=[creator_id])
    messages = db.relationship("BroadcastMessage", back_populates="channel", cascade="all, delete-orphan")
    members = db.relationship("BroadcastMember", back_populates="channel", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<BroadcastChannel '{self.title}'>"


class BroadcastMessage(db.Model):
    __tablename__ = "broadcast_messages"

    id = db.Column(db.Integer, primary_key=True)
    channel_id = db.Column(db.Integer, db.ForeignKey("broadcast_channels.id"), nullable=False, index=True)
    sender_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    body = db.Column(db.Text, nullable=True)
    image_filename = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    channel = db.relationship("BroadcastChannel", back_populates="messages")
    sender = db.relationship("User", foreign_keys=[sender_id])

    def __repr__(self):
        return f"<BroadcastMessage channel_id={self.channel_id}>"


class BroadcastMember(db.Model):
    __tablename__ = "broadcast_members"

    id = db.Column(db.Integer, primary_key=True)
    channel_id = db.Column(db.Integer, db.ForeignKey("broadcast_channels.id"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    joined_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    channel = db.relationship("BroadcastChannel", back_populates="members")
    user = db.relationship("User", foreign_keys=[user_id])

    __table_args__ = (db.UniqueConstraint("channel_id", "user_id", name="uq_broadcast_member"),)

    def __repr__(self):
        return f"<BroadcastMember channel_id={self.channel_id} user_id={self.user_id}>"
