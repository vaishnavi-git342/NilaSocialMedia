"""Hashtag and PostHashtag models."""
from datetime import datetime
from app.extensions import db


class Hashtag(db.Model):
    __tablename__ = "hashtags"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    posts = db.relationship("PostHashtag", back_populates="hashtag", cascade="all, delete-orphan")

    @property
    def post_count(self):
        return len(self.posts)

    def __repr__(self):
        return f"<Hashtag #{self.name}>"


class PostHashtag(db.Model):
    __tablename__ = "post_hashtags"

    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=False, index=True)
    hashtag_id = db.Column(db.Integer, db.ForeignKey("hashtags.id"), nullable=False, index=True)

    post = db.relationship("Post", back_populates="hashtags")
    hashtag = db.relationship("Hashtag", back_populates="posts")

    __table_args__ = (db.UniqueConstraint("post_id", "hashtag_id", name="uq_post_hashtag"),)

    def __repr__(self):
        return f"<PostHashtag post_id={self.post_id} hashtag_id={self.hashtag_id}>"
