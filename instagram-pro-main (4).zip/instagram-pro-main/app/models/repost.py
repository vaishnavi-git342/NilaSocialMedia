"""Repost model for reposting other users' posts and reels."""
from datetime import datetime
from app.extensions import db


class Repost(db.Model):
    __tablename__ = "reposts"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=True, index=True)
    reel_id = db.Column(db.Integer, db.ForeignKey("reels.id"), nullable=True, index=True)
    caption = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User", foreign_keys=[user_id])
    post = db.relationship("Post", foreign_keys=[post_id])
    reel = db.relationship("Reel", foreign_keys=[reel_id])

    def __repr__(self):
        return f"<Repost user_id={self.user_id} post_id={self.post_id} reel_id={self.reel_id}>"
