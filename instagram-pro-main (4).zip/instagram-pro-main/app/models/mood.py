"""Mood model for mood-based AI feed recommendations."""
from datetime import datetime
from app.extensions import db


class Mood(db.Model):
    __tablename__ = "moods"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False, index=True)
    emoji = db.Column(db.String(10), nullable=False)
    description = db.Column(db.String(255), nullable=True)
    color = db.Column(db.String(20), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def __repr__(self):
        return f"<Mood {self.emoji} {self.name}>"


class UserMood(db.Model):
    """Tracks a user's current mood selection."""
    __tablename__ = "user_moods"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    mood_id = db.Column(db.Integer, db.ForeignKey("moods.id"), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User", foreign_keys=[user_id])
    mood = db.relationship("Mood", foreign_keys=[mood_id])

    def __repr__(self):
        return f"<UserMood user_id={self.user_id} mood_id={self.mood_id}>"


class PostMood(db.Model):
    """Associates posts with moods for mood-based filtering."""
    __tablename__ = "post_moods"

    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=False, index=True)
    mood_id = db.Column(db.Integer, db.ForeignKey("moods.id"), nullable=False, index=True)

    post = db.relationship("Post", foreign_keys=[post_id])
    mood = db.relationship("Mood", foreign_keys=[mood_id])

    __table_args__ = (db.UniqueConstraint("post_id", "mood_id", name="uq_post_mood"),)

    def __repr__(self):
        return f"<PostMood post_id={self.post_id} mood_id={self.mood_id}>"
