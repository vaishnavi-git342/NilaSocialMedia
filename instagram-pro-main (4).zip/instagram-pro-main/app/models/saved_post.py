"""SavedPost model for bookmarked posts."""
from datetime import datetime
from app.extensions import db


class SavedPost(db.Model):
    __tablename__ = "saved_posts"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User", back_populates="saved_posts")
    post = db.relationship("Post", back_populates="saved_by")

    __table_args__ = (db.UniqueConstraint("user_id", "post_id", name="uq_user_saved_post"),)

    def __repr__(self):
        return f"<SavedPost user_id={self.user_id} post_id={self.post_id}>"
