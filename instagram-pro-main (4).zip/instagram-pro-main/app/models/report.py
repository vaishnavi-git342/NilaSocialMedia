"""Report model for user-reported posts."""
from datetime import datetime
from app.extensions import db


class Report(db.Model):
    __tablename__ = "reports"

    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=True, index=True)
    comment_id = db.Column(db.Integer, db.ForeignKey("comments.id"), nullable=True, index=True)
    reported_user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True, index=True)
    reporter_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    reason = db.Column(db.String(255), nullable=False)
    status = db.Column(db.String(20), default="pending", nullable=False)  # pending, reviewed, dismissed
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    post = db.relationship("Post", back_populates="reports")
    reporter = db.relationship("User", foreign_keys=[reporter_id])

    def __repr__(self):
        return f"<Report {self.id} post_id={self.post_id} reason='{self.reason}'>"
