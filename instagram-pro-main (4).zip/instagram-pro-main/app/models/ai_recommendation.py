"""AIRecommendation model for storing AI-generated feed recommendations."""
from datetime import datetime
from app.extensions import db


class AIRecommendation(db.Model):
    __tablename__ = "ai_recommendations"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=True, index=True)
    reel_id = db.Column(db.Integer, db.ForeignKey("reels.id"), nullable=True, index=True)
    score = db.Column(db.Float, default=0.0, nullable=False)
    reason = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User")
    post = db.relationship("Post")
    reel = db.relationship("Reel")

    def __repr__(self):
        return f"<AIRecommendation user_id={self.user_id} post_id={self.post_id} score={self.score}>"
