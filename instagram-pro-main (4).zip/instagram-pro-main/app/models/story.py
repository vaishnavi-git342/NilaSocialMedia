"""Story, StoryView, StoryHighlight, and highlight media items."""
from datetime import datetime, timedelta
from app.extensions import db


class Story(db.Model):
    __tablename__ = "stories"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    filename = db.Column(db.String(512), nullable=False)
    is_video = db.Column(db.Boolean, default=False, nullable=False)
    caption = db.Column(db.String(255), nullable=True)
    audio_filename = db.Column(db.String(512), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)
    expires_at = db.Column(db.DateTime, default=lambda: datetime.utcnow() + timedelta(hours=48), nullable=False)

    user = db.relationship("User", back_populates="stories")
    views = db.relationship("StoryView", back_populates="story", cascade="all, delete-orphan")

    @property
    def view_count(self):
        return len(self.views)

    @property
    def is_expired(self):
        return datetime.utcnow() > self.expires_at

    def __repr__(self):
        return f"<Story {self.id} by user_id={self.user_id}>"


class StoryView(db.Model):
    __tablename__ = "story_views"

    id = db.Column(db.Integer, primary_key=True)
    story_id = db.Column(db.Integer, db.ForeignKey("stories.id"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    viewed_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    story = db.relationship("Story", back_populates="views")
    user = db.relationship("User")

    __table_args__ = (db.UniqueConstraint("story_id", "user_id", name="uq_story_view"),)

    def __repr__(self):
        return f"<StoryView story_id={self.story_id} user_id={self.user_id}>"


class StoryHighlight(db.Model):
    __tablename__ = "story_highlights"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    title = db.Column(db.String(80), nullable=False)
    cover_filename = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User")
    items = db.relationship(
        "HighlightItem",
        back_populates="highlight",
        cascade="all, delete-orphan",
        order_by="HighlightItem.position",
    )

    def __repr__(self):
        return f"<StoryHighlight {self.id} '{self.title}'>"


class HighlightItem(db.Model):
    """Persisted media inside a highlight (survives the 48-hour story expiry)."""

    __tablename__ = "highlight_items"

    id = db.Column(db.Integer, primary_key=True)
    highlight_id = db.Column(db.Integer, db.ForeignKey("story_highlights.id", ondelete="CASCADE"), nullable=False, index=True)
    media_filename = db.Column(db.String(512), nullable=False)
    is_video = db.Column(db.Boolean, default=False, nullable=False)
    caption = db.Column(db.String(255), nullable=True)
    position = db.Column(db.Integer, default=0, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    highlight = db.relationship("StoryHighlight", back_populates="items")
