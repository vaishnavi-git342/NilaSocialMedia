"""Mute, Restrict, Not Interested, and Comment Like — Instagram-style controls."""
from datetime import datetime
from app.extensions import db


class UserMute(db.Model):
    """Mute someone: hide their posts from your feed without blocking."""
    __tablename__ = "user_mutes"

    id = db.Column(db.Integer, primary_key=True)
    muter_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    muted_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    muter = db.relationship("User", foreign_keys=[muter_id])
    muted = db.relationship("User", foreign_keys=[muted_id])

    __table_args__ = (db.UniqueConstraint("muter_id", "muted_id", name="uq_user_mute"),)


class UserRestrict(db.Model):
    """Restrict someone: their comments are only visible to you; limited interaction."""
    __tablename__ = "user_restricts"

    id = db.Column(db.Integer, primary_key=True)
    restrictor_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    restricted_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    restrictor = db.relationship("User", foreign_keys=[restrictor_id])
    restricted = db.relationship("User", foreign_keys=[restricted_id])

    __table_args__ = (db.UniqueConstraint("restrictor_id", "restricted_id", name="uq_user_restrict"),)


class HiddenPost(db.Model):
    """Not Interested — hide a post from the viewer's feed."""
    __tablename__ = "hidden_posts"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User")
    post = db.relationship("Post")

    __table_args__ = (db.UniqueConstraint("user_id", "post_id", name="uq_hidden_post"),)


class CommentLike(db.Model):
    __tablename__ = "comment_likes"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    comment_id = db.Column(db.Integer, db.ForeignKey("comments.id"), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User")
    comment = db.relationship("Comment", backref=db.backref("likes", cascade="all, delete-orphan"))

    __table_args__ = (db.UniqueConstraint("user_id", "comment_id", name="uq_comment_like"),)
