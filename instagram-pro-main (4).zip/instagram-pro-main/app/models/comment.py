"""Comment and Reply models."""
from datetime import datetime
from app.extensions import db


class Comment(db.Model):
    __tablename__ = "comments"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=True, index=True)
    reel_id = db.Column(db.Integer, db.ForeignKey("reels.id"), nullable=True, index=True)
    body = db.Column(db.Text, nullable=False)
    is_hidden = db.Column(db.Boolean, default=False, nullable=False)
    is_pinned = db.Column(db.Boolean, default=False, nullable=False)
    moderation_status = db.Column(db.String(20), default="ok", nullable=False)  # ok | removed | flagged
    moderation_reason = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User", back_populates="comments")
    post = db.relationship("Post", back_populates="comments")
    replies = db.relationship("Reply", back_populates="comment", cascade="all, delete-orphan")

    @property
    def reply_count(self):
        return len(self.replies)

    @property
    def like_count(self):
        return len(self.likes) if hasattr(self, "likes") else 0

    def is_liked_by(self, user_id: int) -> bool:
        return any(l.user_id == user_id for l in getattr(self, "likes", []))

    @property
    def is_visible(self) -> bool:
        return not self.is_hidden and self.moderation_status != "removed"

    def __repr__(self):
        return f"<Comment {self.id} by user_id={self.user_id}>"


class Reply(db.Model):
    __tablename__ = "replies"

    id = db.Column(db.Integer, primary_key=True)
    comment_id = db.Column(db.Integer, db.ForeignKey("comments.id"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    body = db.Column(db.Text, nullable=False)
    is_hidden = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    comment = db.relationship("Comment", back_populates="replies")
    user = db.relationship("User")

    def __repr__(self):
        return f"<Reply {self.id} to comment_id={self.comment_id}>"
