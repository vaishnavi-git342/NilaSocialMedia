"""Reel model for short vertical videos."""
from datetime import datetime
from app.extensions import db


class Reel(db.Model):
    __tablename__ = "reels"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    filename = db.Column(db.String(512), nullable=False)
    thumbnail = db.Column(db.String(512), nullable=True)
    caption = db.Column(db.Text, nullable=True)
    audio_name = db.Column(db.String(255), nullable=True)
    audio_filename = db.Column(db.String(512), nullable=True)
    views = db.Column(db.Integer, default=0, nullable=False)
    is_adult_content = db.Column(db.Boolean, default=False, nullable=False)
    content_rating = db.Column(db.String(20), default="general", nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)

    user = db.relationship("User", back_populates="reels")
    likes = db.relationship("Like", backref="reel", cascade="all, delete-orphan")
    comments = db.relationship("Comment", backref="reel", cascade="all, delete-orphan")

    @property
    def like_count(self):
        return len(self.likes)

    @property
    def comment_count(self):
        return len(self.comments)

    def is_liked_by(self, user_id: int) -> bool:
        return any(l.user_id == user_id for l in self.likes)

    def __repr__(self):
        return f"<Reel {self.id} by user_id={self.user_id}>"
