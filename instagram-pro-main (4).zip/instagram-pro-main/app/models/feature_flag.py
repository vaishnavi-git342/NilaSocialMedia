"""Global and per-user Instagram Pro feature flags (super-admin controlled)."""
from datetime import datetime
from app.extensions import db


class FeatureFlag(db.Model):
    """Global kill-switch for an Instagram Pro feature."""

    __tablename__ = "feature_flags"

    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(64), unique=True, nullable=False, index=True)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.String(255), default="")
    enabled = db.Column(db.Boolean, default=True, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f"<FeatureFlag {self.key}={'on' if self.enabled else 'off'}>"


class UserFeatureOverride(db.Model):
    """Per-user override: force enable/disable a feature for one account."""

    __tablename__ = "user_feature_overrides"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    feature_key = db.Column(db.String(64), nullable=False, index=True)
    enabled = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User", backref=db.backref("feature_overrides", cascade="all, delete-orphan"))

    __table_args__ = (
        db.UniqueConstraint("user_id", "feature_key", name="uq_user_feature"),
    )

    def __repr__(self):
        return f"<UserFeatureOverride user={self.user_id} {self.feature_key}={'on' if self.enabled else 'off'}>"
