"""User model for authentication and account management."""
from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app.extensions import db


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False, nullable=False)
    is_super_admin = db.Column(db.Boolean, default=False, nullable=False)
    is_active_account = db.Column(db.Boolean, default=True, nullable=False)
    email_verified = db.Column(db.Boolean, default=False, nullable=False)
    is_private = db.Column(db.Boolean, default=False, nullable=False)
    dark_mode = db.Column(db.Boolean, default=False, nullable=False)
    filter_offensive_comments = db.Column(db.Boolean, default=True, nullable=False)
    deactivated_reason = db.Column(db.String(255), nullable=True)
    deactivated_at = db.Column(db.DateTime, nullable=True)
    birth_date = db.Column(db.Date, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    last_seen = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    profile = db.relationship("Profile", uselist=False, back_populates="user", cascade="all, delete-orphan")
    posts = db.relationship("Post", back_populates="user", cascade="all, delete-orphan")
    stories = db.relationship("Story", back_populates="user", cascade="all, delete-orphan")
    reels = db.relationship("Reel", back_populates="user", cascade="all, delete-orphan")
    likes = db.relationship("Like", back_populates="user", cascade="all, delete-orphan")
    comments = db.relationship("Comment", back_populates="user", cascade="all, delete-orphan")
    notifications = db.relationship("Notification", back_populates="user", cascade="all, delete-orphan", foreign_keys="Notification.user_id")
    saved_posts = db.relationship("SavedPost", back_populates="user", cascade="all, delete-orphan")

    # Follower / following (self-referential through Follow)
    following = db.relationship(
        "Follow", foreign_keys="Follow.follower_id", back_populates="follower", cascade="all, delete-orphan"
    )
    followers = db.relationship(
        "Follow", foreign_keys="Follow.followed_id", back_populates="followed", cascade="all, delete-orphan"
    )

    # Messages
    conversations = db.relationship("Conversation", back_populates="user", cascade="all, delete-orphan", foreign_keys="Conversation.user_id")

    # Flask-Login uses is_active to decide if a session stays valid
    @property
    def is_active(self):
        return bool(self.is_active_account)

    @property
    def age(self):
        from app.services.ai_age_gate import age_from_birth_date
        return age_from_birth_date(self.birth_date)

    @property
    def is_adult(self) -> bool:
        from app.services.ai_age_gate import is_adult_age
        return is_adult_age(self.birth_date)

    # --- Password helpers ---
    def set_password(self, password: str):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    # --- Convenience properties ---
    def is_following(self, other_id: int) -> bool:
        follow = Follow.query.filter_by(follower_id=self.id, followed_id=other_id, accepted=True).first()
        return follow is not None

    def has_pending_follow(self, other_id: int) -> bool:
        follow = Follow.query.filter_by(follower_id=self.id, followed_id=other_id, accepted=False).first()
        return follow is not None

    def has_pending_follow_from(self, other_id: int) -> bool:
        """True if other_id has a pending request to follow this user."""
        follow = Follow.query.filter_by(follower_id=other_id, followed_id=self.id, accepted=False).first()
        return follow is not None

    def has_blocked(self, other_id: int) -> bool:
        from app.models.block import UserBlock
        return UserBlock.query.filter_by(blocker_id=self.id, blocked_id=other_id).first() is not None

    def is_blocked_by(self, other_id: int) -> bool:
        from app.models.block import UserBlock
        return UserBlock.query.filter_by(blocker_id=other_id, blocked_id=self.id).first() is not None

    def is_blocked_with(self, other_id: int) -> bool:
        """True if either user has blocked the other."""
        return self.has_blocked(other_id) or self.is_blocked_by(other_id)

    def has_muted(self, other_id: int) -> bool:
        from app.models.social_controls import UserMute
        return UserMute.query.filter_by(muter_id=self.id, muted_id=other_id).first() is not None

    def has_restricted(self, other_id: int) -> bool:
        from app.models.social_controls import UserRestrict
        return UserRestrict.query.filter_by(restrictor_id=self.id, restricted_id=other_id).first() is not None

    def is_close_friend_with(self, other_id: int) -> bool:
        from app.models.social_features import CloseFriend
        return CloseFriend.query.filter_by(user_id=self.id, friend_id=other_id).first() is not None

    @property
    def follower_count(self):
        return Follow.query.filter_by(followed_id=self.id, accepted=True).count()

    @property
    def following_count(self):
        return Follow.query.filter_by(follower_id=self.id, accepted=True).count()

    @property
    def post_count(self):
        return Post.query.filter_by(user_id=self.id).count()

    @property
    def reel_count(self):
        from app.models.reel import Reel
        return Reel.query.filter_by(user_id=self.id).count()

    def __repr__(self):
        return f"<User {self.username}>"


# Avoid circular imports at module load — import after class definition
from app.models.follow import Follow  # noqa: E402
from app.models.post import Post  # noqa: E402
