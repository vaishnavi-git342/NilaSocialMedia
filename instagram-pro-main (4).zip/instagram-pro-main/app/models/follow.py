"""Follow model for follower/following relationships."""
from datetime import datetime
from app.extensions import db


class Follow(db.Model):
    __tablename__ = "followers"

    id = db.Column(db.Integer, primary_key=True)
    follower_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    followed_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    accepted = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    follower = db.relationship("User", foreign_keys=[follower_id], back_populates="following")
    followed = db.relationship("User", foreign_keys=[followed_id], back_populates="followers")

    __table_args__ = (db.UniqueConstraint("follower_id", "followed_id", name="uq_follower_followed"),)

    def __repr__(self):
        return f"<Follow {self.follower_id} -> {self.followed_id}>"
