"""Application factory pattern for Instagram Pro."""
import os

os.environ.setdefault("USE_TF", "0")
os.environ.setdefault("TRANSFORMERS_NO_TF", "1")
os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

from flask import Flask
from config import config_map

from app.extensions import db, migrate, login_manager, csrf, mail


def create_app(config_name=None):
    """Create and configure the Flask application."""
    # .env is loaded in config.py before Config reads INSTAGRAM_* vars
    if config_name is None:
        config_name = os.environ.get("FLASK_ENV", "development")

    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object(config_map[config_name])

    # Ensure instance directory exists (needed for SQLite database)
    os.makedirs(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "instance"), exist_ok=True)

    # Ensure upload directories exist
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
    os.makedirs(os.path.join(app.config["UPLOAD_FOLDER"], "posts"), exist_ok=True)
    os.makedirs(os.path.join(app.config["UPLOAD_FOLDER"], "profiles"), exist_ok=True)
    os.makedirs(os.path.join(app.config["UPLOAD_FOLDER"], "stories"), exist_ok=True)
    os.makedirs(os.path.join(app.config["UPLOAD_FOLDER"], "reels"), exist_ok=True)
    os.makedirs(os.path.join(app.config["UPLOAD_FOLDER"], "messages"), exist_ok=True)
    os.makedirs(os.path.join(app.config["UPLOAD_FOLDER"], "audio"), exist_ok=True)

    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    csrf.init_app(app)
    mail.init_app(app)

    # User loader
    from app.models.user import User

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    @login_manager.unauthorized_handler
    def unauthorized():
        from flask import request, jsonify, redirect, url_for
        if request.path.startswith("/api/") or request.accept_mimetypes.best == "application/json":
            return jsonify({"error": "Authentication required"}), 401
        return redirect(url_for("auth.login", next=request.url))

    # Register blueprints
    from app.routes.main import main_bp
    from app.routes.auth import auth_bp
    from app.routes.profile import profile_bp
    from app.routes.post import post_bp
    from app.routes.story import story_bp
    from app.routes.reel import reel_bp
    from app.routes.explore import explore_bp
    from app.routes.message import message_bp
    from app.routes.notification import notification_bp
    from app.routes.search import search_bp
    from app.routes.settings import settings_bp
    from app.routes.admin import admin_bp
    from app.routes.api import api_bp
    from app.routes.mood import mood_bp
    from app.routes.social import social_bp
    from app.routes.pro import pro_bp
    from app.routes.live_ig import live_bp
    from app.routes.news import news_bp
    from app.routes.review import review_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(profile_bp, url_prefix="/profile")
    app.register_blueprint(post_bp, url_prefix="/post")
    app.register_blueprint(story_bp, url_prefix="/story")
    app.register_blueprint(reel_bp, url_prefix="/reels")
    app.register_blueprint(explore_bp, url_prefix="/explore")
    app.register_blueprint(message_bp, url_prefix="/messages")
    app.register_blueprint(notification_bp, url_prefix="/notifications")
    app.register_blueprint(search_bp, url_prefix="/search")
    app.register_blueprint(settings_bp, url_prefix="/settings")
    app.register_blueprint(admin_bp, url_prefix="/admin")
    app.register_blueprint(api_bp, url_prefix="/api")
    app.register_blueprint(mood_bp, url_prefix="/mood")
    app.register_blueprint(social_bp, url_prefix="/social")
    app.register_blueprint(pro_bp, url_prefix="/pro")
    app.register_blueprint(live_bp, url_prefix="/live")
    app.register_blueprint(news_bp, url_prefix="/daily")
    app.register_blueprint(review_bp, url_prefix="/reviews")

    # Context processor + template filters
    from app.utils.helpers import inject_global_context, media_url

    app.context_processor(inject_global_context)
    app.jinja_env.filters["media_url"] = media_url

    # Error handlers
    from app.utils.errors import register_error_handlers

    register_error_handlers(app)

    # Create tables on first run (development convenience)
    with app.app_context():
        from app.utils.schema import ensure_schema
        ensure_schema()
        # Brand logos only. Demo users/posts are not created — people sign up themselves.
        try:
            import shutil
            from pathlib import Path

            root = Path(app.root_path).parent
            seed_assets = root / "seed_assets"
            for logo in ("nila_icon.png", "nila_wordmark.png"):
                src = seed_assets / logo
                if src.exists():
                    shutil.copy2(src, Path(app.static_folder) / "images" / logo)
        except Exception as exc:
            app.logger.warning("Logo copy skipped: %s", exc)
        try:
            from app.services.seed_data import remove_demo_accounts
            removed = remove_demo_accounts()
            if removed:
                app.logger.info("Removed %s demo accounts.", removed)
        except Exception as exc:
            app.logger.exception("Demo cleanup skipped: %s", exc)
        try:
            from datetime import date
            from app.models.profile import Profile
            if not User.query.filter_by(is_super_admin=True).first():
                password = os.environ.get("SUPERADMIN_PASSWORD", "NilaAdmin#2026")
                admin = User(
                    username="superadmin",
                    email="superadmin@nila.local",
                    is_admin=True,
                    is_super_admin=True,
                    email_verified=True,
                    birth_date=date(1990, 1, 1),
                )
                admin.set_password(password)
                db.session.add(admin)
                db.session.flush()
                db.session.add(Profile(user_id=admin.id, full_name="Super Admin"))
                db.session.commit()
                app.logger.warning("Super admin ready: superadmin@nila.local")
        except Exception as exc:
            db.session.rollback()
            app.logger.exception("Super admin setup skipped: %s", exc)
        try:
            from datetime import timedelta
            from app.models.story import Story

            short = timedelta(hours=30)
            long = timedelta(hours=48)
            changed = False
            for story in Story.query.all():
                if story.created_at and story.expires_at and (story.expires_at - story.created_at) < short:
                    story.expires_at = story.created_at + long
                    changed = True
            if changed:
                db.session.commit()
        except Exception as exc:
            db.session.rollback()
            app.logger.exception("Story lifetime update skipped: %s", exc)

    return app
