"""Decorators for access control."""
from functools import wraps
from flask import abort, flash, redirect, url_for
from flask_login import current_user


def admin_required(f):
    """Require the current user to be an admin (or super admin)."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated:
            abort(403)
        if not (current_user.is_admin or getattr(current_user, "is_super_admin", False)):
            abort(403)
        return f(*args, **kwargs)
    return decorated


def super_admin_required(f):
    """Require super admin — feature flags, promote admins, hard controls."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not getattr(current_user, "is_super_admin", False):
            abort(403)
        return f(*args, **kwargs)
    return decorated


def feature_required(feature_key: str):
    """Block access when a feature is disabled globally or for this user."""
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            from app.services.feature_flags import feature_enabled
            if current_user.is_authenticated and feature_enabled(feature_key, current_user):
                return f(*args, **kwargs)
            flash("This Nila Social feature is disabled by the administrator.", "warning")
            return redirect(url_for("main.feed"))
        return decorated
    return decorator
