"""Utility helpers for templates, file uploads, and more."""
import os
import uuid
from datetime import datetime
from urllib.parse import urlparse
from flask import url_for
from flask_login import current_user
from werkzeug.utils import secure_filename

from app.extensions import db
from app.models.user import User
from app.models.notification import Notification
from app.models.message import Message, Conversation


def allowed_file(filename: str, allowed_extensions: set) -> bool:
    """Check if a filename has an allowed extension."""
    return "." in filename and filename.rsplit(".", 1)[1].lower() in allowed_extensions


def save_uploaded_file(file, subfolder: str, allowed_extensions: set) -> str | None:
    """Save an uploaded file and return the relative path for static serving."""
    if not file or not allowed_file(file.filename, allowed_extensions):
        return None

    ext = file.filename.rsplit(".", 1)[1].lower()
    safe_name = secure_filename(file.filename)
    unique_name = f"{uuid.uuid4().hex}_{safe_name.rsplit('.', 1)[0]}.{ext}"
    folder = os.path.join(current_app_upload_folder(), subfolder)
    os.makedirs(folder, exist_ok=True)
    file.save(os.path.join(folder, unique_name))
    return f"uploads/{subfolder}/{unique_name}"


def current_app_upload_folder():
    """Return the upload folder from current app config."""
    from flask import current_app
    return current_app.config["UPLOAD_FOLDER"]


def media_url(path: str | None) -> str:
    """Normalize local upload paths and absolute URLs for img/src attributes."""
    if not path:
        return ""
    path = str(path).strip()
    if path.startswith(("http://", "https://", "//", "data:")):
        return path
    if path.startswith("/static/"):
        return path
    cleaned = path.lstrip("/")
    if cleaned.startswith("static/"):
        cleaned = cleaned[7:]
    return url_for("static", filename=cleaned)


def time_ago(dt: datetime) -> str:
    """Return a human-readable 'time ago' string."""
    if not dt:
        return ""
    diff = datetime.utcnow() - dt
    seconds = diff.total_seconds()
    if seconds < 60:
        return "just now"
    elif seconds < 3600:
        return f"{int(seconds // 60)}m ago"
    elif seconds < 86400:
        return f"{int(seconds // 3600)}h ago"
    elif seconds < 604800:
        return f"{int(seconds // 86400)}d ago"
    else:
        return dt.strftime("%b %d, %Y")


def create_notification(user_id, actor_id, ntype, text="", post_id=None, story_id=None, reel_id=None):
    """Queue a notification (caller must commit)."""
    if user_id == actor_id:
        return None
    n = Notification(
        user_id=user_id,
        actor_id=actor_id,
        type=ntype,
        text=text,
        post_id=post_id,
        story_id=story_id,
        reel_id=reel_id,
    )
    db.session.add(n)
    return n


def is_safe_redirect(target: str | None) -> bool:
    """Allow only same-origin relative redirects (block open redirects)."""
    if not target:
        return False
    target = target.strip()
    if not target.startswith("/") or target.startswith("//"):
        return False
    parsed = urlparse(target)
    return parsed.netloc == ""


def can_view_user_content(viewer, owner) -> bool:
    """True if viewer may see owner's posts/stories/reels (private-account aware)."""
    if owner is None:
        return False
    if viewer is not None and getattr(viewer, "is_authenticated", False):
        if viewer.id == owner.id:
            return True
        if viewer.is_blocked_with(owner.id):
            return False
    if not getattr(owner, "is_private", False):
        return True
    if viewer is None or not getattr(viewer, "is_authenticated", False):
        return False
    return viewer.is_following(owner.id)


def blocked_user_ids(viewer) -> set[int]:
    """Ids the viewer blocked or who blocked the viewer."""
    if viewer is None or not getattr(viewer, "is_authenticated", False):
        return set()
    from app.models.block import UserBlock
    blocked = {
        b.blocked_id
        for b in UserBlock.query.filter_by(blocker_id=viewer.id).all()
    }
    blocked |= {
        b.blocker_id
        for b in UserBlock.query.filter_by(blocked_id=viewer.id).all()
    }
    return blocked


def apply_block_user(blocker_id: int, blocked_id: int) -> bool:
    """Block a user: create block, remove follows both ways. Returns True if newly blocked."""
    from app.models.block import UserBlock
    from app.models.follow import Follow

    if blocker_id == blocked_id:
        return False
    existing = UserBlock.query.filter_by(blocker_id=blocker_id, blocked_id=blocked_id).first()
    if existing:
        return False
    db.session.add(UserBlock(blocker_id=blocker_id, blocked_id=blocked_id))
    Follow.query.filter(
        db.or_(
            db.and_(Follow.follower_id == blocker_id, Follow.followed_id == blocked_id),
            db.and_(Follow.follower_id == blocked_id, Follow.followed_id == blocker_id),
        )
    ).delete(synchronize_session=False)
    return True


def remove_block_user(blocker_id: int, blocked_id: int) -> bool:
    from app.models.block import UserBlock
    row = UserBlock.query.filter_by(blocker_id=blocker_id, blocked_id=blocked_id).first()
    if not row:
        return False
    db.session.delete(row)
    return True


def toggle_mute_user(muter_id: int, muted_id: int) -> bool:
    """Returns True if now muted, False if unmuted."""
    from app.models.social_controls import UserMute
    if muter_id == muted_id:
        return False
    row = UserMute.query.filter_by(muter_id=muter_id, muted_id=muted_id).first()
    if row:
        db.session.delete(row)
        return False
    db.session.add(UserMute(muter_id=muter_id, muted_id=muted_id))
    return True


def toggle_restrict_user(restrictor_id: int, restricted_id: int) -> bool:
    """Returns True if now restricted."""
    from app.models.social_controls import UserRestrict
    if restrictor_id == restricted_id:
        return False
    row = UserRestrict.query.filter_by(restrictor_id=restrictor_id, restricted_id=restricted_id).first()
    if row:
        db.session.delete(row)
        return False
    db.session.add(UserRestrict(restrictor_id=restrictor_id, restricted_id=restricted_id))
    return True


def visible_comments_for(post, viewer):
    """Filter comments for restrict + AI removal like Instagram Restrict."""
    comments = [c for c in post.comments if getattr(c, "is_visible", True)]
    if viewer is None or not getattr(viewer, "is_authenticated", False):
        return comments
    # Restricted users' comments only visible to post owner + commenter
    is_owner = viewer.id == post.user_id
    out = []
    for c in comments:
        if is_owner or c.user_id == viewer.id:
            out.append(c)
            continue
        # If post owner has restricted this commenter, hide from others
        if post.user.has_restricted(c.user_id):
            continue
        out.append(c)
    # Pinned first
    out.sort(key=lambda c: (not getattr(c, "is_pinned", False), -(c.id or 0)))
    return out


def can_view_post(viewer, post) -> bool:
    if not post or not can_view_user_content(viewer, post.user):
        return False
    if getattr(post, "is_adult_content", False):
        if not getattr(viewer, "is_authenticated", False) or not getattr(viewer, "is_adult", False):
            # Owner can always see own content
            if not (getattr(viewer, "is_authenticated", False) and viewer.id == post.user_id):
                return False
    return True


def can_view_reel(viewer, reel) -> bool:
    if not reel or not can_view_user_content(viewer, reel.user):
        return False
    if getattr(reel, "is_adult_content", False):
        if not getattr(viewer, "is_authenticated", False) or not getattr(viewer, "is_adult", False):
            if not (getattr(viewer, "is_authenticated", False) and viewer.id == reel.user_id):
                return False
    return True


def can_view_story(viewer, story) -> bool:
    return bool(story) and can_view_user_content(viewer, story.user)


def story_tray_for_user(viewer) -> dict:
    """Instagram-like story tray: own ring first, then one ring per followed user."""
    from datetime import datetime
    from app.models.story import Story

    now = datetime.utcnow()
    following_ids = [f.followed_id for f in viewer.following if f.accepted]
    following_ids.append(viewer.id)
    blocked = blocked_user_ids(viewer)
    muted = muted_user_ids(viewer)

    raw = (
        Story.query
        .filter(
            Story.user_id.in_(following_ids),
            Story.expires_at > now,
        )
        .order_by(Story.created_at.asc())
        .all()
    )

    by_user: dict[int, dict] = {}
    for story in raw:
        if story.user_id in blocked or story.user_id in muted:
            continue
        if not can_view_story(viewer, story):
            continue
        entry = by_user.get(story.user_id)
        if not entry:
            by_user[story.user_id] = {
                "user": story.user,
                "first_story_id": story.id,
                "has_unseen": False,
            }
            entry = by_user[story.user_id]
        viewed = any(v.user_id == viewer.id for v in story.views)
        if not viewed and story.user_id != viewer.id:
            entry["has_unseen"] = True

    own_id = int(viewer.id)
    own = None
    others = []
    for uid, entry in by_user.items():
        if int(uid) == own_id:
            own = entry
        else:
            others.append(entry)
    others.sort(key=lambda e: (not e["has_unseen"], (e["user"].username or "").lower()))
    return {"own_story": own, "story_users": others}


def muted_user_ids(viewer) -> set[int]:
    if viewer is None or not getattr(viewer, "is_authenticated", False):
        return set()
    from app.models.social_controls import UserMute
    return {m.muted_id for m in UserMute.query.filter_by(muter_id=viewer.id).all()}


def hidden_post_ids(viewer) -> set[int]:
    if viewer is None or not getattr(viewer, "is_authenticated", False):
        return set()
    from app.models.social_controls import HiddenPost
    return {h.post_id for h in HiddenPost.query.filter_by(user_id=viewer.id).all()}


def filter_visible_posts(query, viewer=None):
    """Restrict a Post query to content the viewer is allowed to see."""
    from app.models.post import Post
    from app.models.follow import Follow

    viewer = viewer if viewer is not None else current_user
    blocked = blocked_user_ids(viewer)
    muted = muted_user_ids(viewer)
    hidden = hidden_post_ids(viewer)

    if getattr(viewer, "is_authenticated", False):
        followed = (
            db.session.query(Follow.followed_id)
            .filter(Follow.follower_id == viewer.id, Follow.accepted.is_(True))
        )
        q = query.join(User, Post.user_id == User.id).filter(
            db.or_(
                User.is_private.is_(False),
                Post.user_id == viewer.id,
                Post.user_id.in_(followed),
            )
        )
        # Own archived posts stay visible to owner; others never see archived
        q = q.filter(db.or_(Post.is_archived.is_(False), Post.user_id == viewer.id))
    else:
        q = query.join(User, Post.user_id == User.id).filter(
            User.is_private.is_(False),
            Post.is_archived.is_(False),
        )
    if blocked:
        q = q.filter(~Post.user_id.in_(blocked))
    if muted:
        q = q.filter(~Post.user_id.in_(muted))
    if hidden:
        q = q.filter(~Post.id.in_(hidden))
    # Age gate: under-18 (or unknown age) never see 18+ posts
    if not getattr(viewer, "is_authenticated", False) or not getattr(viewer, "is_adult", False):
        q = q.filter(db.or_(Post.is_adult_content.is_(False), Post.is_adult_content.is_(None)))
    return q


def filter_visible_reels(query, viewer=None):
    """Restrict a Reel query to content the viewer is allowed to see."""
    from app.models.reel import Reel
    from app.models.follow import Follow

    viewer = viewer if viewer is not None else current_user
    blocked = blocked_user_ids(viewer)
    if getattr(viewer, "is_authenticated", False):
        followed = (
            db.session.query(Follow.followed_id)
            .filter(Follow.follower_id == viewer.id, Follow.accepted.is_(True))
        )
        q = query.join(User, Reel.user_id == User.id).filter(
            db.or_(
                User.is_private.is_(False),
                Reel.user_id == viewer.id,
                Reel.user_id.in_(followed),
            )
        )
    else:
        q = query.join(User, Reel.user_id == User.id).filter(User.is_private.is_(False))
    if blocked:
        q = q.filter(~Reel.user_id.in_(blocked))
    muted = muted_user_ids(viewer)
    if muted:
        q = q.filter(~Reel.user_id.in_(muted))
    if not getattr(viewer, "is_authenticated", False) or not getattr(viewer, "is_adult", False):
        q = q.filter(db.or_(Reel.is_adult_content.is_(False), Reel.is_adult_content.is_(None)))
    return q


def cleanup_post_dependencies(post_id: int):
    """Remove rows that reference a post but lack ORM cascades, plus media files."""
    import os
    from flask import current_app
    from app.models.mood import PostMood
    from app.models.repost import Repost
    from app.models.post import Post, PostImage
    from app.models.social_controls import HiddenPost
    from app.models.report import Report

    # Collect media paths before the post row disappears
    filenames = [
        img.filename
        for img in PostImage.query.filter_by(post_id=post_id).all()
        if img.filename
    ]

    Notification.query.filter_by(post_id=post_id).delete(synchronize_session=False)
    PostMood.query.filter_by(post_id=post_id).delete(synchronize_session=False)
    Repost.query.filter_by(post_id=post_id).delete(synchronize_session=False)
    HiddenPost.query.filter_by(post_id=post_id).delete(synchronize_session=False)
    Report.query.filter_by(post_id=post_id).delete(synchronize_session=False)
    try:
        from app.models.ai_recommendation import AIRecommendation
        AIRecommendation.query.filter_by(post_id=post_id).delete(synchronize_session=False)
    except Exception:
        pass

    upload_root = str(current_app.config.get("UPLOAD_FOLDER") or "")
    for rel in filenames:
        try:
            rel_path = rel.replace("uploads/", "", 1) if rel.startswith("uploads/") else rel
            abs_path = os.path.join(upload_root, rel_path)
            if os.path.isfile(abs_path):
                os.remove(abs_path)
        except OSError:
            pass


def delete_user_account(user: User):
    """Delete a user and related rows that lack cascade from User."""
    from app.models.message import Conversation, Message
    from app.models.comment import Reply
    from app.models.report import Report
    from app.models.mood import UserMood
    from app.models.story import StoryView, StoryHighlight
    from app.models.social_features import CloseFriend, BroadcastChannel, BroadcastMember
    from app.models.post import Post

    uid = user.id

    Notification.query.filter_by(actor_id=uid).update(
        {Notification.actor_id: None}, synchronize_session=False
    )
    Message.query.filter_by(sender_id=uid).delete(synchronize_session=False)
    Conversation.query.filter_by(partner_id=uid).delete(synchronize_session=False)
    Reply.query.filter_by(user_id=uid).delete(synchronize_session=False)
    Report.query.filter_by(reporter_id=uid).delete(synchronize_session=False)
    UserMood.query.filter_by(user_id=uid).delete(synchronize_session=False)
    StoryView.query.filter_by(user_id=uid).delete(synchronize_session=False)
    StoryHighlight.query.filter_by(user_id=uid).delete(synchronize_session=False)

    CloseFriend.query.filter(
        db.or_(CloseFriend.user_id == uid, CloseFriend.friend_id == uid)
    ).delete(synchronize_session=False)

    from app.models.block import UserBlock
    UserBlock.query.filter(
        db.or_(UserBlock.blocker_id == uid, UserBlock.blocked_id == uid)
    ).delete(synchronize_session=False)

    from app.models.social_controls import UserMute, UserRestrict, HiddenPost, CommentLike
    UserMute.query.filter(
        db.or_(UserMute.muter_id == uid, UserMute.muted_id == uid)
    ).delete(synchronize_session=False)
    UserRestrict.query.filter(
        db.or_(UserRestrict.restrictor_id == uid, UserRestrict.restricted_id == uid)
    ).delete(synchronize_session=False)
    HiddenPost.query.filter_by(user_id=uid).delete(synchronize_session=False)
    CommentLike.query.filter_by(user_id=uid).delete(synchronize_session=False)

    BroadcastMember.query.filter_by(user_id=uid).delete(synchronize_session=False)
    for ch in BroadcastChannel.query.filter_by(creator_id=uid).all():
        db.session.delete(ch)

    for post in Post.query.filter_by(user_id=uid).all():
        cleanup_post_dependencies(post.id)

    try:
        from app.models.ai_recommendation import AIRecommendation
        AIRecommendation.query.filter_by(user_id=uid).delete(synchronize_session=False)
    except Exception:
        pass

    db.session.delete(user)


def inject_global_context():
    """Context processor: inject global variables into all templates."""
    from flask import session

    # Festival banner/theme disabled — always Classic (no monsoon/onam feed label)
    mode = {"id": "default", "name": "Classic", "emoji": "", "theme_class": "", "banner": ""}
    if session.get("festival_mode") and session.get("festival_mode") != "default":
        session.pop("festival_mode", None)

    context = {
        "current_year": datetime.utcnow().year,
        "media_url": media_url,
        "app_name": "Nila Social",
        "festival_mode": mode,
        "unread_notifications": 0,
        "unread_messages": 0,
        "instagram_live": False,
        "features": {},
        "is_super_admin": False,
    }
    try:
        from flask import current_app
        context["instagram_live"] = bool(current_app.config.get("INSTAGRAM_LIVE"))
    except Exception:
        pass
    if current_user.is_authenticated:
        try:
            context["is_super_admin"] = bool(getattr(current_user, "is_super_admin", False))
            from app.services.feature_flags import features_for_user
            feats = features_for_user(current_user)
            context["features"] = feats
            # Live Instagram also needs env flag
            context["instagram_live"] = (
                context["instagram_live"] and feats.get("live_instagram", True)
            )
        except Exception:
            pass
        try:
            context["unread_notifications"] = Notification.query.filter_by(
                user_id=current_user.id, is_read=False
            ).count()

            conv_ids = [
                c.id
                for c in Conversation.query.filter(
                    db.or_(
                        Conversation.user_id == current_user.id,
                        Conversation.partner_id == current_user.id,
                    )
                ).all()
            ]
            if conv_ids:
                context["unread_messages"] = (
                    Message.query.filter(
                        Message.conversation_id.in_(conv_ids),
                        Message.sender_id != current_user.id,
                        Message.is_seen.is_(False),
                    ).count()
                )
        except Exception:
            pass
    return context
