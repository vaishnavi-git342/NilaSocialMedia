"""Custom error handlers for the application."""
from flask import render_template, request, jsonify


def register_error_handlers(app):
    """Register 403, 404, 413, and 500 error handlers."""

    def wants_json():
        return (
            request.path.startswith("/api/")
            or request.accept_mimetypes.best == "application/json"
            or request.is_json
        )

    @app.errorhandler(403)
    def forbidden(e):
        if wants_json():
            return jsonify({"error": "Forbidden"}), 403
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(e):
        if wants_json():
            return jsonify({"error": "Not found"}), 404
        return render_template("errors/404.html"), 404

    @app.errorhandler(413)
    def too_large(e):
        if wants_json():
            return jsonify({"error": "File too large. Max upload is 100MB."}), 413
        return render_template("errors/413.html"), 413

    @app.errorhandler(500)
    def server_error(e):
        if wants_json():
            return jsonify({"error": "Server error"}), 500
        return render_template("errors/500.html"), 500
