"""Ensure SQLite schema has newer columns/tables without full migrations."""
from __future__ import annotations

from sqlalchemy import inspect, text
from app.extensions import db


def _table_columns(table: str) -> set[str]:
    try:
        insp = inspect(db.engine)
        return {c["name"] for c in insp.get_columns(table)}
    except Exception:
        return set()


def _add_column(table: str, column_sql: str):
    try:
        db.session.execute(text(f"ALTER TABLE {table} ADD COLUMN {column_sql}"))
        db.session.commit()
    except Exception:
        db.session.rollback()


def ensure_schema():
    """Add missing columns for Instagram Pro social features on existing DBs."""
    # Import models so create_all sees new tables
    import app.models  # noqa: F401
    db.create_all()

    users_cols = _table_columns("users")
    if users_cols and "filter_offensive_comments" not in users_cols:
        _add_column("users", "filter_offensive_comments BOOLEAN DEFAULT 1 NOT NULL")
    if users_cols and "is_super_admin" not in users_cols:
        _add_column("users", "is_super_admin BOOLEAN DEFAULT 0 NOT NULL")
    if users_cols and "deactivated_reason" not in users_cols:
        _add_column("users", "deactivated_reason VARCHAR(255)")
    if users_cols and "deactivated_at" not in users_cols:
        _add_column("users", "deactivated_at DATETIME")
    if users_cols and "birth_date" not in users_cols:
        _add_column("users", "birth_date DATE")

    profiles_cols = _table_columns("profiles")
    if profiles_cols and "profile_photo_label" not in profiles_cols:
        _add_column("profiles", "profile_photo_label VARCHAR(80)")
    if profiles_cols and "is_ai_profile_photo" not in profiles_cols:
        _add_column("profiles", "is_ai_profile_photo BOOLEAN DEFAULT 0 NOT NULL")

    comments_cols = _table_columns("comments")
    if comments_cols:
        if "is_hidden" not in comments_cols:
            _add_column("comments", "is_hidden BOOLEAN DEFAULT 0 NOT NULL")
        if "is_pinned" not in comments_cols:
            _add_column("comments", "is_pinned BOOLEAN DEFAULT 0 NOT NULL")
        if "moderation_status" not in comments_cols:
            _add_column("comments", "moderation_status VARCHAR(20) DEFAULT 'ok' NOT NULL")
        if "moderation_reason" not in comments_cols:
            _add_column("comments", "moderation_reason VARCHAR(255)")

    replies_cols = _table_columns("replies")
    if replies_cols and "is_hidden" not in replies_cols:
        _add_column("replies", "is_hidden BOOLEAN DEFAULT 0 NOT NULL")

    posts_cols = _table_columns("posts")
    if posts_cols:
        if "comments_disabled" not in posts_cols:
            _add_column("posts", "comments_disabled BOOLEAN DEFAULT 0 NOT NULL")
        if "hide_like_count" not in posts_cols:
            _add_column("posts", "hide_like_count BOOLEAN DEFAULT 0 NOT NULL")
        if "is_archived" not in posts_cols:
            _add_column("posts", "is_archived BOOLEAN DEFAULT 0 NOT NULL")
        if "is_adult_content" not in posts_cols:
            _add_column("posts", "is_adult_content BOOLEAN DEFAULT 0 NOT NULL")
        if "content_rating" not in posts_cols:
            _add_column("posts", "content_rating VARCHAR(20) DEFAULT 'general' NOT NULL")
        if "audio_filename" not in posts_cols:
            _add_column("posts", "audio_filename VARCHAR(512)")
        if "audio_name" not in posts_cols:
            _add_column("posts", "audio_name VARCHAR(255)")

    stories_cols = _table_columns("stories")
    if stories_cols and "audio_filename" not in stories_cols:
        _add_column("stories", "audio_filename VARCHAR(512)")

    reels_cols = _table_columns("reels")
    if reels_cols and "audio_filename" not in reels_cols:
        _add_column("reels", "audio_filename VARCHAR(512)")
    if reels_cols:
        if "is_adult_content" not in reels_cols:
            _add_column("reels", "is_adult_content BOOLEAN DEFAULT 0 NOT NULL")
        if "content_rating" not in reels_cols:
            _add_column("reels", "content_rating VARCHAR(20) DEFAULT 'general' NOT NULL")

    reports_cols = _table_columns("reports")
    if reports_cols:
        if "comment_id" not in reports_cols:
            _add_column("reports", "comment_id INTEGER")
        if "reported_user_id" not in reports_cols:
            _add_column("reports", "reported_user_id INTEGER")

    # Feature flag rows + promote seed admin to super admin on existing DBs
    try:
        from app.services.feature_flags import ensure_feature_flags
        ensure_feature_flags()
    except Exception:
        db.session.rollback()

    try:
        from app.models.user import User
        from datetime import date
        # Ensure seed admin has an adult birth date so demo feed works
        seed = User.query.filter_by(username="ananya_kochi").first()
        if seed and seed.is_admin and not getattr(seed, "is_super_admin", False):
            seed.is_super_admin = True
            db.session.commit()
        # Backfill missing birth dates for demo accounts (adult default)
        missing = User.query.filter(User.birth_date.is_(None)).limit(50).all()
        if missing:
            for u in missing:
                # Demo users → adult; others stay unset until they edit
                if u.email and u.email.endswith("@kerala.app"):
                    u.birth_date = date(1998, 1, 1)
            db.session.commit()
    except Exception:
        db.session.rollback()
