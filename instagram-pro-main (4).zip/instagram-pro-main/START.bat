@echo off
title Nila Social - Start
cd /d "%~dp0"
python tools\installer.py start
pause
