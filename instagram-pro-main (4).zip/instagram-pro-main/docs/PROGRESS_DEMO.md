# Progress demo for sir (~30% of completed Instagram Pro)

Use **`social_lite/`** when you need to show *work in progress*.  
Use the **repo root (Instagram Pro)** for the *final* viva.

| | Progress demo (~30%) | Final (100%) |
|--|----------------------|--------------|
| Folder | `social_lite/` | repo root |
| Start | `social_lite/START.bat` | `INSTALL.bat` / `START.bat` |
| URL | http://127.0.0.1:**5001** | http://127.0.0.1:**5000** |
| Login | `demo@social.lite` / `password123` | `ananya@kerala.app` / `password123` |

---

## What “30%” includes (real code)

Taken from the completed app’s patterns (`run.py` entry style + `app/routes/api.py` AI contracts):

1. **Auth** — register, login, logout, hashed passwords  
2. **Feed & posts** — create image post, like, delete, profile  
3. **JSON API** — `POST /api/post/<id>/like` (same idea as Pro)  
4. **Local AI API subset** (same route names as Pro `api.py`):
   - `/api/ai/status`
   - `/api/ai/caption`
   - `/api/ai/hashtags`
   - `/api/ai/bilingual`
   - `/api/ai/places`
   - `/api/ai/privacy`
   - `/api/ai/safety`
5. **AI UI** — Local AI Studio, Mood, Festival, Journey labels  
6. **Front extras** — explore / search / messages / notifications (UI)

Engine in this demo: `social_lite_rules_v1` (rule-based, no PyTorch).  
Final Pro uses the full `ai_*.py` stack (BLIP/CLIP when installed).

---

## What stays only in the final project (~70%)

- Stories & Reels (full upload + playback)  
- Real DMs / conversations in DB  
- Follow graph, private accounts, block/mute/restrict  
- Super Admin feature flags & user deactivate  
- Full AI analyze / vision / reel frames / comment moderation pipeline  
- Offline installer package for the full stack  
- Kerala seed dataset & college report for the full system  

---

## What to say to sir

> “This is the progress build — about 30% of the final Instagram Pro.  
> It already has auth, feed, posts, likes, and the Local AI API routes  
> (`/api/ai/caption`, hashtags, bilingual, privacy…).  
> The completed project on port 5000 adds reels, stories, privacy controls,  
> super admin, and the full local AI models.”

---

## Quick demo script (5 minutes)

1. `cd social_lite` → `START.bat`  
2. Login with demo account  
3. Create a post  
4. Open **AI Studio** → click **AI Caption / Hashtags** (watch `/api/ai/...` responses)  
5. Show home feed + like  
6. (Optional) Open final app on 5000 to contrast full features  
