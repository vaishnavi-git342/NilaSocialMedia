# Nila Social — College Project Documentation

**Project Title:** Instagram Pro – AI-Powered Social Media Web Application  
**Type:** Full-stack Web Application (College Mini / Major Project)  
**Technology Stack:** Python, Flask, SQLAlchemy, SQLite, Jinja2, Bootstrap 5, Local AI (BLIP/CLIP)  
**Database:** SQLite (`instance/instagram_clone.db`)  
**Deployment Mode:** Local / Offline-first one-click installer  

---

## 1. Abstract

Instagram Pro is a feature-rich Instagram-like social networking web application built with the Flask framework. It supports posts, stories, reels, direct messaging, private accounts, follow requests, block/mute/restrict controls, and a Local AI Studio for captions, hashtags, moderation, bilingual (English–Manglish) captions, Kerala place intelligence, festival modes, and journey maps. The system is designed to run fully on a local machine with SQLite, making it suitable for offline college demonstrations.

---

## 2. Objectives

1. Design and implement a modular Instagram-like social platform.
2. Model a relational database covering users, content, social graph, and messaging.
3. Integrate **local AI** for captioning, moderation, and content intelligence without mandatory cloud APIs.
4. Enforce privacy (private accounts, blocks, mutes, restricts) similar to real Instagram.
5. Provide a one-click Windows installer with database reset and repair tools.
6. Document architecture, ER model, use cases, and database structure for academic evaluation.

---

## 3. Scope

### In Scope
- Authentication (register, login, password change)
- Profiles, posts, likes, comments, saves
- Stories (24h), Reels, Explore, Search
- Follow / unfollow with private-account approval
- Direct messages
- Block, Mute, Restrict, Report, Not Interested
- AI comment moderation and Local AI Studio
- Festival modes, mood feed, travel journey
- Admin panel basics, settings, local installer

### Out of Scope
- Mobile native apps (iOS/Android)
- Real-time WebSocket chat at production scale
- Cloud hosting / CDN delivery
- Payment / shopping features

---

## 4. System Architecture

![System Architecture](images/architecture_diagram.png)

### Layered Design

| Layer | Components |
|-------|------------|
| **Presentation** | Jinja2 templates, Bootstrap 5 (vendored offline), `app.js` |
| **Application** | Flask blueprints: `auth`, `main`, `post`, `reel`, `story`, `message`, `profile`, `settings`, `api`, `pro`, `mood`, `social`, `admin` |
| **Service** | Local AI engine, toxicity/spam moderation, feed ranking, place/festival helpers |
| **Data** | SQLAlchemy ORM → SQLite |
| **Storage** | `app/static/uploads/` (posts, profiles, stories, reels, messages) |

### Request Flow
Browser → Flask route → Service / ORM → SQLite + files → HTML/JSON response.

---

## 5. Use Case Diagram

![Use Case Diagram](images/use_case_diagram.png)

### Actors

| Actor | Description |
|-------|-------------|
| **Guest** | Can view landing / login / register |
| **Registered User** | Full social features |
| **Private Account User** | Approves follow requests |
| **Admin** | Moderates reports / users |

### Major Use Cases

| ID | Use Case | Actor | Description |
|----|----------|-------|-------------|
| UC01 | Register / Login | Guest, User | Account creation and session |
| UC02 | Create Post | User | Upload image/video + caption |
| UC03 | Like / Comment / Save | User | Engage with posts/reels |
| UC04 | Follow / Accept | User | Social graph with privacy |
| UC05 | Upload Story / Reel | User | Ephemeral & short video |
| UC06 | Send DM | User | Private messaging |
| UC07 | Block / Mute / Restrict | User | Safety controls |
| UC08 | AI Studio | User | Caption, hashtags, bilingual, places |
| UC09 | Mood Feed / Festival | User | Personalized / seasonal UX |
| UC10 | Report Content | User | Flag posts/comments/users |
| UC11 | Moderate | Admin | Review reports |

---

## 6. Entity-Relationship (ER) Diagram

![ER Diagram](images/er_diagram.png)

### Mermaid ER (for tools that render Mermaid)

```mermaid
erDiagram
    USERS ||--o| PROFILES : has
    USERS ||--o{ POSTS : creates
    USERS ||--o{ REELS : creates
    USERS ||--o{ STORIES : creates
    USERS ||--o{ COMMENTS : writes
    USERS ||--o{ LIKES : gives
    USERS ||--o{ FOLLOWERS : follows
    USERS ||--o{ CONVERSATIONS : chats
    USERS ||--o{ NOTIFICATIONS : receives
    USERS ||--o{ USER_BLOCKS : blocks
    USERS ||--o{ USER_MUTES : mutes
    USERS ||--o{ USER_RESTRICTS : restricts
    POSTS ||--o{ POST_IMAGES : contains
    POSTS ||--o{ COMMENTS : has
    POSTS ||--o{ LIKES : has
    POSTS ||--o{ SAVED_POSTS : saved_as
    POSTS }o--o{ HASHTAGS : tagged
    COMMENTS ||--o{ REPLIES : has
    COMMENTS ||--o{ COMMENT_LIKES : liked
    CONVERSATIONS ||--o{ MESSAGES : contains
    STORIES ||--o{ STORY_VIEWS : viewed
    REELS ||--o{ COMMENTS : has
    REELS ||--o{ LIKES : has
    MOODS ||--o{ POST_MOODS : tags
    MOODS ||--o{ USER_MOODS : selects
```

### Cardinality Summary

| Relationship | Type |
|--------------|------|
| User ↔ Profile | 1 : 1 |
| User → Posts / Reels / Stories | 1 : N |
| Post → PostImages | 1 : N |
| Post ↔ Hashtags | M : N (via `post_hashtags`) |
| User ↔ User (Follow) | M : N (via `followers`, `accepted` flag) |
| Post → Comments → Replies | 1 : N : N |
| Conversation → Messages | 1 : N |

---

## 7. Database Information & Structure

### 7.1 Database Engine
- **RDBMS:** SQLite 3  
- **File path:** `instance/instagram_clone.db`  
- **ORM:** SQLAlchemy 2.x via Flask-SQLAlchemy  
- **Schema updates:** `app/utils/schema.py` (`ensure_schema`) adds columns on existing DBs  

### 7.2 Table Inventory (33 tables)

| # | Table | Purpose |
|---|-------|---------|
| 1 | `users` | Accounts, privacy, admin flags |
| 2 | `profiles` | Bio, photos, website |
| 3 | `posts` | Feed posts (caption, location, archive flags) |
| 4 | `post_images` | Media files for posts |
| 5 | `comments` | Comments + AI moderation fields |
| 6 | `replies` | Nested replies |
| 7 | `comment_likes` | Likes on comments |
| 8 | `likes` | Post/reel likes |
| 9 | `saved_posts` | Bookmarks |
| 10 | `followers` | Follow graph + pending (`accepted`) |
| 11 | `stories` | 24h stories |
| 12 | `story_views` | Story view tracking |
| 13 | `story_highlights` | Highlight albums |
| 14 | `reels` | Short videos + thumbnails |
| 15 | `conversations` | DM threads |
| 16 | `messages` | DM messages |
| 17 | `notifications` | Activity alerts |
| 18 | `hashtags` | Tag dictionary |
| 19 | `post_hashtags` | Post↔hashtag link |
| 20 | `reports` | Post/comment/user reports |
| 21 | `reposts` | Shares |
| 22 | `moods` | Mood catalog |
| 23 | `user_moods` | User selected mood |
| 24 | `post_moods` | Post mood tags |
| 25 | `ai_recommendations` | Feed scores |
| 26 | `close_friends` | Close friends list |
| 27 | `broadcast_channels` | Broadcast channels |
| 28 | `broadcast_members` | Channel members |
| 29 | `broadcast_messages` | Channel posts |
| 30 | `user_blocks` | Block list |
| 31 | `user_mutes` | Mute list |
| 32 | `user_restricts` | Restrict list |
| 33 | `hidden_posts` | Not Interested |

### 7.3 Core Table Schemas

#### `users`
| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| username | VARCHAR(80) UNIQUE | |
| email | VARCHAR(255) UNIQUE | |
| password_hash | VARCHAR(255) | Werkzeug hash |
| is_admin | BOOLEAN | |
| is_active_account | BOOLEAN | Maps to Flask-Login `is_active` |
| email_verified | BOOLEAN | |
| is_private | BOOLEAN | Private account |
| dark_mode | BOOLEAN | |
| filter_offensive_comments | BOOLEAN | AI comment filter |
| created_at / last_seen | DATETIME | |

#### `posts`
| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| user_id | FK → users | |
| caption, location | TEXT / VARCHAR | |
| is_video, is_carousel | BOOLEAN | |
| comments_disabled | BOOLEAN | Owner control |
| hide_like_count | BOOLEAN | Owner control |
| is_archived | BOOLEAN | Hidden from public |

#### `comments`
| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| user_id | FK → users | |
| post_id / reel_id | FK nullable | Exactly one used |
| body | TEXT | |
| is_hidden, is_pinned | BOOLEAN | |
| moderation_status | VARCHAR | ok / removed / flagged |
| moderation_reason | VARCHAR | AI reason |

#### `followers`
| Column | Type | Notes |
|--------|------|-------|
| follower_id, followed_id | FK → users | Unique pair |
| accepted | BOOLEAN | False = pending request |

### 7.4 Folder / Project Structure

```
instagram_clone/
├── INSTALL.bat / InstagramPro.bat / START.bat   # One-click tools
├── run.py                                      # App entry
├── config.py                                   # Settings
├── requirements.txt / requirements-core.txt
├── reset_db.py
├── tools/installer.py                          # Installer logic
├── instance/instagram_clone.db                 # SQLite DB
├── docs/                                       # This documentation
│   ├── PROJECT_REPORT.md
│   ├── DATABASE.md
│   └── images/
├── app/
│   ├── __init__.py                             # App factory
│   ├── models/                                 # ORM models
│   ├── routes/                                 # Blueprints
│   ├── services/                               # AI + business logic
│   ├── forms/                                  # WTForms
│   ├── templates/                              # Jinja2 UI
│   └── static/
│       ├── css/ style.css
│       ├── js/ app.js
│       ├── vendor/                             # Offline Bootstrap
│       └── uploads/                            # User media
```

---

## 8. Modules & Features

### Social (Instagram-like)
- Feed, Explore, Search  
- Posts, Stories, Reels  
- Likes, Comments (like/pin/delete), Saves  
- Follow requests for private accounts  
- DMs with toxicity filter  
- Block / Mute / Restrict / Report / Not Interested  
- Archive, hide likes, turn off comments  

### AI (Local / Offline capable)
- BLIP captions & hashtags (if models cached)  
- CLIP tags, NSFW hints  
- Toxicity / spam comment rejection  
- Bilingual EN + Manglish captions  
- Kerala place intelligence  
- Privacy clarity & safety score  
- Reel best-frame thumbnail  
- Festival modes & journey map  

### Installer
- One-click venv + deps + DB seed  
- Reset DB, repair, clean junk  
- Offline vendor assets + optional wheels  

---

## 9. Security Considerations

| Control | Implementation |
|---------|----------------|
| Passwords | Werkzeug salted hashes |
| CSRF | Flask-WTF on forms + `X-CSRFToken` for APIs |
| Auth | Flask-Login; deactivated users blocked via `is_active` |
| Privacy | Private posts/reels/stories gated; block filters |
| Open redirect | Login `next` validated to relative paths only |
| Uploads | Extension whitelist + size limit (100MB) |
| Comments | AI moderation + owner delete |

---

## 10. Testing Summary

| Area | Result |
|------|--------|
| Pro AI APIs (bilingual, places, privacy, safety) | Pass |
| Private post URL leak fix | 403 for non-followers |
| Pending follow UI | Shows Requested |
| Block / Mute / Restrict | Pass |
| Toxic comment auto-remove | Pass |
| Comment like / pin | Pass |
| Installer clean + app boot | Pass |

---

## 11. Installation & Demo

1. Install Python 3.10+ (Add to PATH).  
2. Run `INSTALL.bat` or `InstagramPro.bat` → Install.  
3. Open http://127.0.0.1:5000  

**Demo credentials**

| Role | Email | Password |
|------|-------|----------|
| Admin / Demo | `ananya@kerala.app` | `password123` |

Reset data anytime: `RESET_DATABASE.bat`.

---

## 12. Future Enhancements

- Real-time chat (WebSockets / Socket.IO)  
- Push notifications  
- Mobile Progressive Web App (PWA)  
- PostgreSQL for multi-user production  
- Better multilingual (true Malayalam script NLP)  

---

## 13. Conclusion

Instagram Pro demonstrates a complete social media stack suitable for academic evaluation: relational modeling, MVC-style Flask structure, privacy-aware features, and practical local AI integration with an offline-friendly installer. The ER model, use cases, and database catalog in this document map directly to the implemented SQLite schema (33 tables).

---

## 14. References

1. Flask Documentation — https://flask.palletsprojects.com/  
2. SQLAlchemy — https://www.sqlalchemy.org/  
3. Hugging Face Transformers (BLIP) — Salesforce/blip-image-captioning-base  
4. Bootstrap 5 — https://getbootstrap.com/  

---

*Document generated for college project submission — Instagram Pro*
