# Nila Social — AI Content Detection — Profile Photos & Adult Media

This document describes how **Nila Social** detects heavily edited / AI-generated profile photos and flags **18+** posts and reels using **local open-source AI**, image **metadata (EXIF)**, and **OpenCV** analysis — not filename tricks or caption keyword lists as the primary signal.

---

## Overview

| Feature | Goal | Primary engines |
|--------|------|-----------------|
| Profile photo on signup | Photo required; **heavy edit → block**; **AI-generated → allow + label** | EXIF + CLIP + OpenCV |
| Adult posts / reels | Mark `is_adult_content` / `content_rating=18+`; hide from under-18 feeds | CLIP NSFW on pixels (+ video frame) |
| Age gate | Users under 18 cannot publish or view 18+ media | Birth date + content flags |

**Code:** `app/services/ai_age_gate.py`, `app/services/ai_vision.py`, `app/services/ai_nsfw.py`  
**Wired from:** `app/routes/auth.py` (register / profile photo), `app/routes/post.py`, `app/routes/reel.py`

All inference runs **on-device** (CPU/GPU). No cloud vision API is required after models are cached.

---

## Open-source stack

| Component | Package / model | Role |
|-----------|-----------------|------|
| **CLIP** | `openai/clip-vit-base-patch32` via Hugging Face `transformers` + `torch` | Zero-shot authenticity & NSFW scoring on image pixels |
| **OpenCV** | `opencv-python-headless` | Face detection (Haar), skin-region ratio, smoothness |
| **Pillow** | `Pillow` | EXIF / metadata, image decode |
| **BLIP** (optional) | `Salesforce/blip-image-captioning-base` via `ai_engine` | Captions elsewhere in the app; not the adult gate |

Declared in `requirements.txt`. First CLIP load downloads weights and caches them locally under the Hugging Face cache.

---

## 1. Profile photo on signup

### Requirement

The register form requires a profile image (`FileRequired`). Signup cannot complete without a photo.

### Pipeline (`analyze_profile_photo`)

```
Upload (FileStorage)
    → temp file on disk
    → (1) EXIF / metadata
    → (2) OpenCV faces + skin smoothness + quality
    → (3) CLIP authenticity zero-shot
    → decision: allow / block / AI label
    → cleanup temp file
```

### (1) Metadata (EXIF)

Extracted with Pillow:

- Camera **Make** / **Model**
- **Software**, Artist, ImageDescription
- Format, width × height, DateTime when present

| Signal | Effect |
|--------|--------|
| Software matches heavy editors (Photoshop, Facetune, Meitu, BeautyPlus, …) | **Heavily edited → blocked** |
| Software matches AI tools (Stable Diffusion, Midjourney, DALL·E, Firefly, …) | **AI-generated → allowed + labeled** |
| Mild editors only (Lightroom, Snapseed, VSCO, Canva, …) | Noted; **allowed** |
| Camera Make/Model present | Supports “real photo” |

### (2) OpenCV visual analysis

- **Haar face detection** — face count for portraits  
- **YCrCb skin mask** — skin coverage ratio  
- **Smoothness** — inverse of local Laplacian variance on skin (beauty filters flatten texture)  
- Optional quality metrics via `ai_quality` (blur, brightness, contrast)

**Heavy-edit heuristic:** high smoothness + significant skin + face present + **no camera EXIF** → treat as heavily retouched / beauty-filtered → **block**.

### (3) CLIP authenticity (open-source)

Zero-shot labels (examples):

- Natural unedited smartphone portrait / real camera photograph  
- AI-generated synthetic digital portrait / anime–CGI character  
- Heavily photoshopped / Facetune beauty-filtered portrait  

Scores: `real_score`, `ai_score`, `edited_score`.

| Condition (approx.) | Result |
|---------------------|--------|
| `edited_score` high and ≥ real | **Block** (heavily edited) |
| `ai_score` high and ≥ real | **Allow** + set `is_ai_profile_photo` / label |
| `real_score` leads | Natural photo |

If CLIP/torch is unavailable, the gate still uses **EXIF + OpenCV** only.

### Stored on profile

- `profile_photo` — upload path  
- `is_ai_profile_photo` — boolean  
- `profile_photo_label` — e.g. `AI-generated profile photo`  

Shown on the profile page when AI-generated.

### Outcomes (summary)

| Detection | Signup | Profile UI |
|-----------|--------|------------|
| Heavily edited | **Rejected** with flash reasons | — |
| AI-generated | **Accepted** | Badge / label |
| Natural / mild edit | **Accepted** | No AI label |

---

## 2. Adult content (posts & reels)

### Pipeline (`rate_media_file`)

```
Media path (image or video)
    → if video: extract middle frame (OpenCV) or use reel thumbnail
    → CLIP NSFW zero-shot on pixels
    → if no CLIP: OpenCV high skin-fill fallback
    → set is_adult_content + content_rating
```

**Caption keyword lists are not used as the primary adult detector.** Adult words in the caption alone do not flag content.

### CLIP NSFW scoring

Softmax over a **balanced** label set (safe everyday, clothed portrait, food, landscape, **and** explicit/pornographic classes) so normal portraits and food photos are not falsely marked 18+.

A high adult score is returned only when:

- The **top** label is an explicit/unsafe class with sufficient probability, **or**  
- Unsafe label mass clearly beats safe mass  

Threshold used by the age gate: **`nsfw_score >= 0.55`** → `is_adult_content=True`, `content_rating="18+"`.

### OpenCV fallback (no CLIP)

Very high skin-pixel fill (full-frame skin) can elevate the score. Normal face portraits do not meet this bar.

### Enforcement

- **Publish:** under-18 users cannot create posts/reels flagged 18+  
- **Feed:** `filter_visible_posts` / `filter_visible_reels` hide 18+ items from non-adult viewers  
- Viewer adulthood: `User.is_adult` from date of birth (`is_adult_age`)

---

## 3. Age from birth date

Helpers in `ai_age_gate.py`:

- `parse_birth_date` / `age_from_birth_date` / `is_adult_age`  
- Register requires age ≥ 13; **18+** unlocks adult feed and publishing of 18+ media  

---

## API-style return shapes

### `analyze_profile_photo(file_storage)`

```json
{
  "allowed": true,
  "is_edited": false,
  "is_ai_generated": false,
  "reasons": ["CLIP leans natural photo (real=0.50)."],
  "label": null,
  "signals": {
    "metadata": { "make": "", "model": "", "software": "", "has_camera_exif": false },
    "opencv": { "face_count": 1, "skin_ratio": 0.24, "smoothness": 0.1 },
    "clip_authenticity": { "real_score": 0.5, "ai_score": 0.1, "edited_score": 0.1 },
    "clip_status": { "available": true, "model": "openai/clip-vit-base-patch32" }
  }
}
```

### `rate_media_file(path, caption="")`

```json
{
  "is_adult_content": false,
  "rating": "general",
  "nsfw_score": 0.024,
  "engine": "clip",
  "signals": ["nsfw_score=0.024", "skin_ratio=0.245"],
  "summary": "Suitable for all ages (vision AI clip, score=0.02)",
  "caption_ignored": true
}
```

---

## Demo / college talking points

1. **Not cloud AI** — CLIP + OpenCV + EXIF run locally; suitable for offline/lab demos.  
2. **Not filename gating** — renaming `photo.jpg` does not bypass vision checks.  
3. **Not caption keyword adult filter** — writing “nsfw” in a caption does not auto-flag; the **image** is scored.  
4. **Explainable** — each decision returns human-readable `reasons` / `signals` for viva or reports.  
5. **Limits** — CLIP zero-shot is approximate; it is an educational community-safety demo, not a production NSFW classifier (e.g. dedicated NudeNet). False positives/negatives can still occur; thresholds are tunable in `ai_vision.py` / `ai_age_gate.py`.

---

## How to exercise it

1. Install AI deps: `pip install -r requirements.txt` (includes `torch`, `transformers`, `opencv-python-headless`, `Pillow`).  
2. Run the app; first CLIP use may take minutes while the model downloads.  
3. **Register** with a normal selfie → should pass.  
4. Upload a photo whose EXIF Software is Photoshop / Facetune (or a heavily smoothed beauty export without camera EXIF) → expect **block**.  
5. Upload an AI export tagged in EXIF / scored high as synthetic by CLIP → expect **allow + “AI-generated profile photo”**.  
6. Create a post with a normal travel/food image and adult words in the caption → should stay **general**.  
7. Log in as under-18 vs 18+ and confirm 18+ posts/reels visibility rules.

---

## Related files

| File | Purpose |
|------|---------|
| `app/services/ai_age_gate.py` | Profile analyze + media rate + age helpers |
| `app/services/ai_vision.py` | CLIP load, authenticity, NSFW probability, faces, video frame |
| `app/services/ai_nsfw.py` | Thin wrapper `nsfw_score` / `is_nsfw` |
| `app/services/ai_quality.py` | Blur / brightness / contrast |
| `app/routes/auth.py` | Calls `analyze_profile_photo` on register |
| `app/routes/post.py` / `reel.py` | Calls `rate_media_file` on create |
| `app/utils/helpers.py` | Feed filters for adult content |
| `app/models/profile.py` | `is_ai_profile_photo`, `profile_photo_label` |
| `app/models/post.py` / `reel.py` | `is_adult_content`, `content_rating` |

---

*Nila Social — local AI content safety documentation.*
