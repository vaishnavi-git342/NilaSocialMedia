# Instagram Pro — Database Catalog

**Engine:** SQLite 3  
**Path:** `instance/instagram_clone.db`  
**ORM:** Flask-SQLAlchemy  
**Tables:** 33  

---

## ER Diagram

![ER Diagram](images/er_diagram.png)

---

## Relationships (Key)

```
users 1──1 profiles
users 1──N posts / reels / stories / comments / likes / notifications
users N──N users          (followers, user_blocks, user_mutes, user_restricts, close_friends)
posts 1──N post_images / comments / likes / saved_posts / reports
posts N──N hashtags       (post_hashtags)
posts N──N moods          (post_moods)
comments 1──N replies / comment_likes
conversations 1──N messages
stories 1──N story_views
reels 1──N comments / likes
```

---

## Full Table Reference

### users
Primary account table.

| Column | Type | Null | Notes |
|--------|------|------|-------|
| id | INTEGER | N | PK |
| username | VARCHAR(80) | N | UNIQUE |
| email | VARCHAR(255) | N | UNIQUE |
| password_hash | VARCHAR(255) | N | |
| is_admin | BOOLEAN | N | default False |
| is_active_account | BOOLEAN | N | |
| email_verified | BOOLEAN | N | |
| is_private | BOOLEAN | N | |
| dark_mode | BOOLEAN | N | |
| filter_offensive_comments | BOOLEAN | N | AI filter |
| created_at | DATETIME | N | |
| last_seen | DATETIME | Y | |

### profiles
| Column | Type | Null | FK |
|--------|------|------|-----|
| id | INTEGER | N | PK |
| user_id | INTEGER | N | → users.id |
| full_name | VARCHAR(120) | Y | |
| bio | TEXT | Y | |
| website | VARCHAR(255) | Y | |
| profile_photo | VARCHAR(512) | Y | |
| cover_photo | VARCHAR(512) | Y | |
| gender | VARCHAR(20) | Y | |
| updated_at | DATETIME | Y | |

### posts
| Column | Type | Null | FK |
|--------|------|------|-----|
| id | INTEGER | N | PK |
| user_id | INTEGER | N | → users.id |
| caption | TEXT | Y | |
| location | VARCHAR(255) | Y | |
| is_video | BOOLEAN | N | |
| is_carousel | BOOLEAN | N | |
| comments_disabled | BOOLEAN | N | |
| hide_like_count | BOOLEAN | N | |
| is_archived | BOOLEAN | N | |
| created_at | DATETIME | N | |
| updated_at | DATETIME | Y | |

### post_images
| Column | Type | Null | FK |
|--------|------|------|-----|
| id | INTEGER | N | PK |
| post_id | INTEGER | N | → posts.id |
| filename | VARCHAR(512) | N | relative upload path or URL |
| position | INTEGER | N | carousel order |
| is_video | BOOLEAN | N | |

### comments
| Column | Type | Null | FK |
|--------|------|------|-----|
| id | INTEGER | N | PK |
| user_id | INTEGER | N | → users.id |
| post_id | INTEGER | Y | → posts.id |
| reel_id | INTEGER | Y | → reels.id |
| body | TEXT | N | |
| is_hidden | BOOLEAN | N | |
| is_pinned | BOOLEAN | N | |
| moderation_status | VARCHAR(20) | N | ok / flagged / removed |
| moderation_reason | VARCHAR(255) | Y | |
| created_at | DATETIME | N | |

### replies
| Column | Type | Null | FK |
|--------|------|------|-----|
| id | INTEGER | N | PK |
| comment_id | INTEGER | N | → comments.id |
| user_id | INTEGER | N | → users.id |
| body | TEXT | N | |
| is_hidden | BOOLEAN | N | |
| created_at | DATETIME | N | |

### likes
| Column | Type | Null | FK |
|--------|------|------|-----|
| id | INTEGER | N | PK |
| user_id | INTEGER | N | → users.id |
| post_id | INTEGER | Y | → posts.id |
| reel_id | INTEGER | Y | → reels.id |
| created_at | DATETIME | N | |

### followers
| Column | Type | Null | FK |
|--------|------|------|-----|
| id | INTEGER | N | PK |
| follower_id | INTEGER | N | → users.id |
| followed_id | INTEGER | N | → users.id |
| accepted | BOOLEAN | N | False = pending |
| created_at | DATETIME | N | |

### conversations / messages
| Table | Key columns |
|-------|-------------|
| conversations | user_id, partner_id (canonical ordered pair) |
| messages | conversation_id, sender_id, body, image_filename, is_seen |

### stories / reels
| Table | Key columns |
|-------|-------------|
| stories | user_id, filename, is_video, caption, expires_at |
| story_views | story_id, user_id, viewed_at |
| story_highlights | user_id, title, cover_filename |
| reels | user_id, filename, thumbnail, caption, audio_name, views |

### Safety / controls
| Table | Meaning |
|-------|---------|
| user_blocks | blocker_id → blocked_id |
| user_mutes | muter_id → muted_id |
| user_restricts | restrictor_id → restricted_id |
| hidden_posts | user_id + post_id (Not Interested) |
| reports | post_id / comment_id / reported_user_id + reason + status |

### Mood / AI / social extras
| Table | Meaning |
|-------|---------|
| moods | Catalog (happy, relaxed, …) |
| user_moods | Current user mood |
| post_moods | Post tagged with mood |
| ai_recommendations | Cached recommendation scores |
| hashtags / post_hashtags | Tagging |
| saved_posts | Bookmarks |
| close_friends | Close Friends list |
| broadcast_* | Broadcast channels |

---

## Indexes & Constraints

- Unique usernames and emails on `users`
- Unique `(follower_id, followed_id)` style pairs on follow/block/mute/restrict/close_friends
- Unique `(user_id, post_id)` on `saved_posts` and `hidden_posts`
- Unique `(user_id, comment_id)` on `comment_likes`
- Foreign keys from content tables to `users` and parent content

---

## Seed Data

On first boot / reset, Kerala-themed demo users are seeded (marker: `ananya_kochi`).

| Email | Password | Role |
|-------|----------|------|
| ananya@kerala.app | password123 | Admin demo |

Reset command: `RESET_DATABASE.bat` or `python tools/installer.py reset-db --yes`
