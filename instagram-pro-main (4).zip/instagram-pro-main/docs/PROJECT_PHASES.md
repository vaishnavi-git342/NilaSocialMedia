# Project delivery phases (for incremental reviews)

Your guide wants completion **one by one**. Use this order.

---

## How to present

| Review | Show this | Folder | Demo login |
|--------|-----------|--------|------------|
| **1st check** | Social Lite (basic) | `social_lite/` | `demo@social.lite` / `password123` |
| **Final** | Instagram Pro (full) | repo root | `ananya@kerala.app` / `password123` |

Ports: Phase 1 → **5001** · Final → **5000**

---

## Phase 1 — Social Lite (basic)

**Goal:** Prove auth + feed + CRUD basics.

Include when sir asks for “first completion”:

- Register / Login / Logout  
- Home feed  
- Create post (image + caption)  
- Like / Unlike  
- Delete own post  
- Profile page  
- Installer (`INSTALL.bat`, `START.bat`)  
- PPT: `social_lite/docs/Social_Lite_Phase1.pptx`

**Do not** demo AI, reels, admin, or DMs here — those belong to the final.

---

## Suggested middle phases (optional, if he asks step-by-step)

You can describe these as already done in the **final** codebase when asked:

| Phase | Features (in Instagram Pro) |
|-------|------------------------------|
| 2 | Follow graph, private accounts, explore |
| 3 | Stories, reels, messaging |
| 4 | Block / mute / restrict, reports |
| 5 | Local AI Studio, mood, festival |
| 6 | Super Admin feature flags + deactivate users |

---

## Final — Instagram Pro

**Goal:** Full project viva / submission.

- Root `README.md`, `INSTALL.bat`, `docs/`  
- PPT: `docs/Instagram_Pro_Mini_Project.pptx`  
- Slides content: `docs/MINI_PROJECT_SLIDES.md`  
- GitHub: https://github.com/anandhx/instagram-pro  

---

## What to say in viva

> “We delivered the project in phases. Phase 1 is Social Lite — core auth and feed with its own installer. The final Instagram Pro builds on the same Flask patterns and adds privacy, AI, and super-admin modules.”
