# Nila Social — Diagrams Index

| Diagram | File | Description |
|---------|------|-------------|
| ER Diagram | [images/er_diagram.png](images/er_diagram.png) | Entity-Relationship model |
| Use Case | [images/use_case_diagram.png](images/use_case_diagram.png) | UML use cases & actors |
| Architecture | [images/architecture_diagram.png](images/architecture_diagram.png) | Layered system design |

| Document | File |
|----------|------|
| Full project report | [PROJECT_REPORT.md](PROJECT_REPORT.md) |
| Database details | [DATABASE.md](DATABASE.md) |
| AI content detection (profile photo + 18+) | [AI_CONTENT_DETECTION.md](AI_CONTENT_DETECTION.md) |
| Mini project slides (markdown) | [MINI_PROJECT_SLIDES.md](MINI_PROJECT_SLIDES.md) |
| **PowerPoint presentation** | [Instagram_Pro_Mini_Project.pptx](Instagram_Pro_Mini_Project.pptx) |

**Demo login (Super Admin):** `ananya@kerala.app` / `password123`
