# Nila Social — Mini Project Slide Contents

**Use this document to fill each PowerPoint / Google Slides slide exactly as required.**  
Copy one section per slide. Keep bullets short on slides; keep details in speaker notes if needed.

---

## SLIDE 1 — Title Slide

| Field | Value |
|-------|--------|
| **Project Title** | Instagram Pro – AI-Powered Social Media Web Application |
| **Subtitle** | A Flask-based Instagram Clone with Local AI, Privacy Controls & Super Admin |
| **Submitted by** | *(Your Name / Roll No.)* |
| **Guided by** | *(Guide Name / Designation)* |
| **Department** | *(Dept. of Computer Science / IT)* |
| **College** | *(Your College Name)* |
| **Year** | 2025–2026 |
| **Type** | Mini Project |

**On-slide text suggestion:**

> **INSTAGRAM PRO**  
> AI-Powered Social Media Web Application  
> Mini Project Presentation  
> Department of ………………  
> ……………… College  
> 2025–2026

---

## SLIDE 2 — Introduction (bullets)

- Social media platforms like Instagram dominate digital communication and content sharing.
- Existing clones often lack **privacy controls**, **local AI**, and **admin governance**.
- **Instagram Pro** is a full-stack web clone built with **Python Flask + SQLite**.
- It supports posts, stories, reels, DMs, follow requests, block/mute/restrict.
- Integrates **Local AI Studio** (captions, hashtags, toxicity filter, bilingual Manglish).
- Includes **Super Admin** to enable/disable features and deactivate users.
- Designed for **offline college demo** with one-click Windows installer.
- Kerala-themed seed data for realistic classroom presentation.

---

## SLIDE 3 — Abstract (bullets)

- Instagram Pro is an Instagram-like social networking web app developed using Flask.
- Core modules: Auth, Feed, Posts, Stories, Reels, Messages, Explore, Settings.
- Privacy: private accounts, follow approval, block, mute, restrict, report.
- Local AI: image captioning, hashtags, comment moderation, mood feed, festival mode.
- Super Admin: global/per-user feature flags and account deactivate/activate.
- Data stored in SQLite; media in local upload folders; no cloud dependency required.
- Suitable for academic evaluation of full-stack design, DB modeling, and AI integration.
- Result: a working offline demo with seeded users and measurable feature coverage.

---

## SLIDE 4 — Problem Definition (ONE sentence)

> Existing Instagram-style academic clones provide basic posting features but lack integrated local AI assistance, Instagram-like privacy/safety controls, and a super-admin governance layer to manage users and feature access—creating a gap that Instagram Pro addresses as a complete offline educational platform.

---

## SLIDE 5 — Literature Survey (TABLE format)

Copy this table onto the slide (may split across 2 slides if needed).

| TITLE & YEAR | AUTHOR & PUBLICATION | ALGORITHM USED | FEATURE EXTRACTED / METHODOLOGY | PERFORMANCE METRIC | RESULT / FINDINGS |
|--------------|----------------------|----------------|----------------------------------|--------------------|-------------------|
| Deep Residual Learning for Image Recognition (2016) | He et al., IEEE CVPR | ResNet / CNN | Hierarchical visual features from images | Top-5 error on ImageNet | Residual nets enable deep visual understanding for captioning backends |
| BLIP: Bootstrapping Language-Image Pre-training (2022) | Li et al., ICML | Vision-Language Transformer | Image–text matching & caption generation | CIDEr / SPICE | Strong zero-shot captioning useful for social media AI studios |
| CLIP: Learning Transferable Visual Models (2021) | Radford et al., PMLR | Contrastive Language–Image Pretraining | Joint image–text embeddings | Zero-shot accuracy | Enables tagging / similarity without task-specific training |
| Toxicity Detection in Online Comments (2017–2020) | Jigsaw / Perspective API studies | Logistic Regression, BERT | Lexical & contextual toxicity features | Precision / Recall / F1 | Automated moderation reduces abusive comments at scale |
| Social Network Privacy Models (2013) | Squicciarini et al., ACM TIST | Access-control / policy rules | Privacy preferences, audience control | Policy compliance rate | Private accounts & audience limits improve user trust |
| Recommender Systems Handbook (ch. Social Rec.) | Ricci et al. (eds.) | Collaborative Filtering, Ranking | User–item interaction signals | NDCG / CTR | Feed ranking improves engagement vs chronological-only |
| Flask Web Development (2nd ed., 2018) | Grinberg, O’Reilly | MVC / Application Factory | Blueprint modular web design | Maintainability | Flask blueprints suit multi-module social apps |
| Instagram Engagement & Hashtag Studies (2019+) | Various (IEEE Access / Elsevier) | NLP, TF–IDF, clustering | Hashtags, captions, engagement | Engagement rate | Smart hashtags increase discoverability |

**Slide tip:** Keep 4–5 rows on one slide; put remaining in appendix / report.

---

## SLIDE 6 — Design Diagrams

Use existing images under `docs/images/` if available, **or** redraw from Mermaid below in draw.io / Lucidchart / PowerPoint.

### 6.1 DFD — Context (Level 0)

```mermaid
flowchart LR
  U[User / Browser] -->|HTTP Requests| S[Instagram Pro System]
  A[Super Admin] -->|Manage users & features| S
  S -->|HTML / JSON / Media| U
  S -->|HTML / Stats| A
  S --> DB[(SQLite DB)]
  S --> FS[(Upload Files)]
```

### 6.2 DFD — Level 1 (major processes)

```mermaid
flowchart TB
  U[User] --> P1[1.0 Authentication]
  U --> P2[2.0 Content Management]
  U --> P3[3.0 Social Graph]
  U --> P4[4.0 Messaging]
  U --> P5[5.0 Local AI Studio]
  A[Admin] --> P6[6.0 Admin & Feature Control]
  P1 --> DB[(SQLite)]
  P2 --> DB
  P2 --> FS[(Uploads)]
  P3 --> DB
  P4 --> DB
  P5 --> DB
  P6 --> DB
```

### 6.3 Use Case Diagram (textual + Mermaid)

**Actors:** Guest, Registered User, Super Admin  

```mermaid
flowchart LR
  Guest -->|Register / Login| SYS[Instagram Pro]
  User[Registered User] -->|Create Post/Story/Reel| SYS
  User -->|Like Comment Follow DM| SYS
  User -->|Block Mute Restrict| SYS
  User -->|AI Studio Mood Festival| SYS
  Admin[Super Admin] -->|Deactivate Users| SYS
  Admin -->|Toggle Features| SYS
  Admin -->|Review Reports| SYS
```

*(Also use: `docs/images/use_case_diagram.png` if present.)*

### 6.4 Class Diagram (core)

```mermaid
classDiagram
  User --> Profile
  User --> Post
  User --> Reel
  User --> Story
  User --> Comment
  User --> Follow
  User --> Message
  User --> FeatureOverride
  Post --> PostImage
  Post --> Like
  Post --> Comment
  FeatureFlag <|-- FeatureOverride : overrides
  class User {
    +username
    +email
    +is_admin
    +is_super_admin
    +is_active_account
  }
  class FeatureFlag {
    +key
    +enabled
  }
  class Post {
    +caption
    +is_archived
  }
```

### 6.5 State Diagram — User Account

```mermaid
stateDiagram-v2
  [*] --> Registered
  Registered --> Active: email verified / login
  Active --> Deactivated: Super Admin deactivate
  Deactivated --> Active: Super Admin activate
  Active --> LoggedIn: valid credentials
  LoggedIn --> Active: logout
  Deactivated --> [*]: cannot login
```

### 6.6 Activity Diagram — Create Post with AI Assist

```mermaid
flowchart TD
  A[Start] --> B[Login]
  B --> C[Open Create Post]
  C --> D[Upload Image]
  D --> E{Use AI Studio?}
  E -->|Yes| F[Generate caption / hashtags]
  E -->|No| G[Manual caption]
  F --> H[Save Post to DB + file]
  G --> H
  H --> I[Show on Feed]
  I --> J[End]
```

### 6.7 Sequence Diagram — Login & Feed

```mermaid
sequenceDiagram
  participant B as Browser
  participant F as Flask Auth
  participant DB as SQLite
  participant Feed as Main Feed
  B->>F: POST /auth/login (email, password)
  F->>DB: Lookup user + verify hash
  alt inactive account
    F-->>B: Flash deactivated reason
  else success
    F-->>B: Session cookie
    B->>Feed: GET /feed
    Feed->>DB: Load posts (privacy filtered)
    Feed-->>B: Render feed HTML
  end
```

---

## SLIDE 7 — Module Description

| Module | Description |
|--------|-------------|
| **Authentication** | Register, login, logout, password reset tokens, session via Flask-Login |
| **Profile** | Bio, photo, private account, followers/following |
| **Posts & Feed** | Upload images/videos, likes, comments, saves, archive, hide likes |
| **Stories** | 24-hour stories, views, highlights |
| **Reels** | Short video upload, best-frame thumbnail via AI |
| **Explore & Search** | Discover users/posts/hashtags |
| **Messaging** | Direct conversations and messages |
| **Social Safety** | Block, mute, restrict, report, not interested |
| **Local AI Studio** | Caption, hashtags, bilingual, places, privacy meter, toxicity |
| **Mood & Festival** | Mood feed; Onam/festival UI themes |
| **Travel Journey** | Map of user’s location-tagged posts |
| **Super Admin** | Feature flags (global + per-user), deactivate users, promote admins |
| **Settings** | Privacy, email, blocked/muted lists |
| **Installer** | Offline Windows install / start / reset DB / repair |

---

## SLIDE 8 — Software & Hardware Requirements

### Software Requirements

| Component | Specification |
|-----------|---------------|
| OS | Windows 10/11 (also Linux/macOS for dev) |
| Language | Python 3.10+ |
| Framework | Flask 3.x |
| ORM / DB | SQLAlchemy, SQLite 3 |
| Frontend | Jinja2, Bootstrap 5 (local vendor), JavaScript |
| AI (optional) | PyTorch, Transformers (BLIP), OpenCV |
| Tools | Git, VS Code / Cursor, pip |
| Browser | Chrome / Edge / Firefox (latest) |

### Hardware Requirements

| Item | Minimum | Recommended |
|------|-- -------|-------------|
| CPU | Dual-core | Quad-core |
| RAM | 4 GB | 8 GB+ (16 GB if running local AI models) |
| Storage | 2 GB free | 5 GB+ (models + uploads) |
| Display | 1366×768 | 1920×1080 |
| Network | Not required for local demo | Optional for image CDNs / Live IG |

---

## SLIDE 9 — Algorithm

### Algorithm 1: User Login & Deactivation Check

```
Step 1: Read email and password from login form
Step 2: Query users table by email
Step 3: If user not found → show error and stop
Step 4: If password hash mismatch → show error and stop
Step 5: If is_active_account = False → show deactivated_reason and stop
Step 6: Create Flask-Login session
Step 7: Redirect to /feed
```

### Algorithm 2: Feature Access Resolution (Super Admin)

```
Step 1: Input feature_key and user_id
Step 2: Look up UserFeatureOverride(user_id, feature_key)
Step 3: If override exists → return override.enabled
Step 4: Look up FeatureFlag(key)
Step 5: If flag exists → return flag.enabled
Step 6: Else return True (default enabled)
Step 7: Route/UI uses result to allow or block feature
```

### Algorithm 3: Privacy-Aware Feed Load

```
Step 1: Get current_user
Step 2: Fetch candidate posts (following + public / AI ranked)
Step 3: For each post author:
        - Skip if blocked either way
        - Skip if private and not accepted follower
        - Skip if archived / hidden (not interested)
Step 4: Return filtered list to template
Step 5: Render feed page
```

### Algorithm 4: AI Comment Moderation (high level)

```
Step 1: Receive new comment text
Step 2: If user.filter_offensive_comments enabled:
        Run toxicity / keyword safety score
Step 3: If score above threshold → reject or hide comment
Step 4: Else save comment and notify post owner
```

---

## SLIDE 10 — Architecture

**Layered Architecture**

| Layer | Technology / Components |
|-------|-------------------------|
| Presentation | Jinja2 templates, Bootstrap 5, `app.js` |
| Application | Flask blueprints (`auth`, `post`, `reel`, `story`, `message`, `admin`, `pro`, …) |
| Service | Local AI, feature flags, feed ranking, moderation |
| Data | SQLAlchemy ORM → SQLite |
| Storage | `app/static/uploads/` for media |

**Request flow (one line for slide):**  
`Browser → Flask Route → Service/ORM → SQLite + Files → HTML/JSON`

*(Insert architecture diagram: `docs/images/architecture_diagram.png`)*

```mermaid
flowchart TB
  subgraph Client
    BR[Browser]
  end
  subgraph App[Flask Application]
    BP[Blueprints / Routes]
    SVC[Services AI / Features / Privacy]
    ORM[SQLAlchemy Models]
  end
  subgraph Data
    DB[(SQLite)]
    UP[Uploads Folder]
  end
  BR --> BP --> SVC --> ORM --> DB
  BP --> UP
```

---

## SLIDE 11 — Analysis on Results

| Metric / Aspect | Observation |
|-----------------|-------------|
| Functional modules delivered | Auth, Feed, Posts, Stories, Reels, DM, Explore, AI, Admin |
| Seeded demo users | 8 Kerala-themed accounts (password `password123`) |
| Database tables | 30+ relational tables including social controls & feature flags |
| Privacy enforcement | Private posts/reels gated; blocks prevent interaction |
| Super Admin control | Global + per-user feature toggles; deactivate blocks login |
| Local AI | Caption/hashtag/moderation available offline after model download |
| Installer | One-click install/start/reset suitable for lab demo |
| Performance (local) | Feed loads interactively on SQLite for demo-scale data |
| Usability | Demo credential buttons on login for quick viva demo |

**Result statement (for slide):**  
> The system successfully demonstrates a complete Instagram-like workflow with AI assistance and admin governance in an offline college environment.

---

## SLIDE 12 — Comparison with Existing (by analysis)

| Feature | Basic IG Clone | Cloud Social Apps | **Instagram Pro** |
|---------|----------------|-------------------|-------------------|
| Posts / Likes / Comments | Yes | Yes | **Yes** |
| Stories & Reels | Rare | Yes | **Yes** |
| Private account + follow request | Rare | Yes | **Yes** |
| Block / Mute / Restrict | Rare | Yes | **Yes** |
| Local AI (no cloud key) | No | Cloud AI | **Yes (BLIP/local)** |
| Super Admin feature flags | No | Backend ops | **Yes** |
| User deactivate with reason | Basic | Yes | **Yes** |
| Offline Windows installer | No | N/A | **Yes** |
| Cost for demo | Low | High / API fees | **Low (local)** |
| Suitable for college viva | Partial | Hard to host | **Strong** |

**Analysis:** Instagram Pro bridges the gap between toy clones and commercial apps by adding privacy, AI, and admin control while remaining fully demonstrable offline.

---

## SLIDE 13 — Conclusion

- Successfully designed and implemented **Instagram Pro**, a Flask-based social media mini project.
- Achieved core Instagram-like features: feed, stories, reels, messaging, and privacy tools.
- Integrated **local AI** for captions, hashtags, and comment safety without mandatory cloud APIs.
- Added **Super Admin** module for feature governance and user activation control.
- Relational SQLite design supports scalable academic documentation (ER, DFD, use cases).
- Offline installer and demo accounts make evaluation and viva presentation practical.
- Project meets stated objectives of full-stack development, DB design, and AI integration.

---

## SLIDE 14 — Future Scope

- Real-time chat using WebSockets (Socket.IO).
- Mobile-responsive PWA / Flutter companion app.
- Stronger recommendation ranking with online learning.
- Cloud deployment (Docker + PostgreSQL) for multi-user labs.
- Official Meta Graph API integration (OAuth) instead of unofficial scrapers.
- Advanced analytics dashboard for Super Admin.
- End-to-end encrypted DMs and 2FA.
- Multilingual UI beyond English–Manglish captions.

---

## SLIDE 15 — References (IEEE format)

[1] M. Grinberg, *Flask Web Development*, 2nd ed. Sebastopol, CA, USA: O’Reilly Media, 2018.

[2] A. Ronacher et al., “Flask Documentation,” Pallets Projects. [Online]. Available: https://flask.palletsprojects.com/

[3] K. He, X. Zhang, S. Ren, and J. Sun, “Deep residual learning for image recognition,” in *Proc. IEEE CVPR*, 2016, pp. 770–778.

[4] J. Li, D. Li, C. Xiong, and S. Hoi, “BLIP: Bootstrapping language-image pre-training for unified vision-language understanding and generation,” in *Proc. ICML*, 2022.

[5] A. Radford et al., “Learning transferable visual models from natural language supervision,” in *Proc. ICML*, 2021.

[6] F. Ricci, L. Rokach, and B. Shapira, Eds., *Recommender Systems Handbook*, 2nd ed. Springer, 2015.

[7] A. C. Squicciarini, F. Paci, and S. Sundareswaran, “Privacy policies for social networks,” *ACM Trans. Intell. Syst. Technol.*, 2013.

[8] SQLAlchemy Authors, “SQLAlchemy Documentation.” [Online]. Available: https://docs.sqlalchemy.org/

[9] Meta Platforms, Inc., “Instagram Help Center – Privacy and Safety.” [Online]. Available: https://help.instagram.com/

[10] Jigsaw, “Perspective API – Toxicity detection,” Google Jigsaw. [Online]. Available: https://perspectiveapi.com/

[11] Python Software Foundation, “Python 3 Documentation.” [Online]. Available: https://docs.python.org/3/

[12] Bootstrap Team, “Bootstrap 5 Documentation.” [Online]. Available: https://getbootstrap.com/docs/5.0/

---

## SLIDE 16 — Thank You

**On-slide text:**

> **Thank You**  
>  
> Questions?  
>  
> **Demo login (Super Admin):**  
> `ananya@kerala.app` / `password123`  
>  
> **Project:** Instagram Pro  
> **Repo:** https://github.com/anandhx/instagram-pro

---

## Quick Fill Checklist (for you)

| Slide | Status in this doc | What you still type |
|-------|--------------------|---------------------|
| 1 Title | Ready | Your name, guide, college |
| 2 Introduction | Ready | — |
| 3 Abstract | Ready | — |
| 4 Problem | Ready (1 sentence) | — |
| 5 Literature | Ready (table) | Optional: add 1–2 papers your guide prefers |
| 6 Diagrams | Mermaid + image refs | Export diagrams to PNG for PPT |
| 7 Modules | Ready | — |
| 8 S/W & H/W | Ready | — |
| 9 Algorithm | Ready | — |
| 10 Architecture | Ready | — |
| 11 Results | Ready | Add screenshots of running app |
| 12 Comparison | Ready | — |
| 13 Conclusion | Ready | — |
| 14 Future scope | Ready | — |
| 15 References | IEEE ready | — |
| 16 Thank you | Ready | Your contact if required |

---

## Suggested Demo Screenshots to Insert

1. Login page with demo credentials  
2. Home feed  
3. Create post / AI Studio  
4. Private follow request  
5. Super Admin → Features page  
6. Super Admin → Deactivate user  
7. Stories / Reels  
8. Architecture / ER diagram  

---

*Document prepared for Mini Project Slide Contents — Instagram Pro (Flask).*
