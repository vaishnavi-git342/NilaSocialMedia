"""Application configuration using environment variables with safe defaults."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# Load .env before reading any Instagram / Flask env vars
try:
    from dotenv import load_dotenv

    load_dotenv(BASE_DIR / ".env")
except Exception:
    pass

# Ensure the instance directory exists before SQLAlchemy tries to open the DB
INSTANCE_DIR = BASE_DIR / "instance"
INSTANCE_DIR.mkdir(parents=True, exist_ok=True)


class Config:
    """Base configuration shared across environments."""

    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key-change-in-production")

    # SQLite database stored in instance/
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL",
        f"sqlite:///{BASE_DIR / 'instance' / 'instagram_clone.db'}",
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # File upload settings
    UPLOAD_FOLDER = BASE_DIR / "app" / "static" / "uploads"
    MAX_CONTENT_LENGTH = 100 * 1024 * 1024  # 100 MB (reels / videos)
    ALLOWED_IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}
    ALLOWED_VIDEO_EXTENSIONS = {"mp4", "webm", "mov"}
    ALLOWED_AUDIO_EXTENSIONS = {"mp3", "wav", "m4a", "ogg", "aac"}

    # Flask-Mail settings (console backend for development)
    MAIL_SERVER = os.environ.get("MAIL_SERVER", "localhost")
    MAIL_PORT = int(os.environ.get("MAIL_PORT", 25))
    MAIL_USE_TLS = os.environ.get("MAIL_USE_TLS", "false").lower() == "true"
    MAIL_USE_SSL = os.environ.get("MAIL_USE_SSL", "false").lower() == "true"
    MAIL_USERNAME = os.environ.get("MAIL_USERNAME")
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD")
    MAIL_DEFAULT_SENDER = os.environ.get("MAIL_DEFAULT_SENDER", "noreply@instagramclone.local")

    # Token expiry for password reset / email verification (seconds)
    TOKEN_EXPIRY = 3600  # 1 hour

    # Pagination
    POSTS_PER_PAGE = 12
    REELS_PER_PAGE = 10
    COMMENTS_PER_PAGE = 20

    # Optional real Instagram (instagrapi) — READ ONLY viewer
    # INSTAGRAM_LIVE=0 → local demo only (default)
    # INSTAGRAM_LIVE=1 → fetch Instagram timeline/posts for viewing
    INSTAGRAM_LIVE = os.environ.get("INSTAGRAM_LIVE", "0").strip() in (
        "1",
        "true",
        "True",
        "yes",
        "YES",
    )
    INSTAGRAM_USERNAME = os.environ.get("INSTAGRAM_USERNAME", "").strip()
    INSTAGRAM_PASSWORD = os.environ.get("INSTAGRAM_PASSWORD", "").strip()
    INSTAGRAM_SESSION_FILE = os.environ.get(
        "INSTAGRAM_SESSION_FILE",
        str(INSTANCE_DIR / "ig_session.json"),
    )
    INSTAGRAM_FEED_LIMIT = int(os.environ.get("INSTAGRAM_FEED_LIMIT", "12"))


class DevelopmentConfig(Config):
    """Development environment with debug enabled."""

    DEBUG = True
    SQLALCHEMY_ECHO = False


class ProductionConfig(Config):
    """Production environment."""

    DEBUG = False


class TestingConfig(Config):
    """Testing environment with in-memory database."""

    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = False


config_map = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "testing": TestingConfig,
    "default": DevelopmentConfig,
}
