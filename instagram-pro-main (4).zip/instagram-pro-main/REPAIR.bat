@echo off
title Instagram Pro - Repair
cd /d "%~dp0"
python tools\installer.py repair
pause
