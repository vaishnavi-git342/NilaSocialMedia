@echo off
title Social Lite - Reset Database
cd /d "%~dp0"
echo This deletes the local SQLite DB and uploaded posts.
pause
python tools\installer.py reset-db
pause
