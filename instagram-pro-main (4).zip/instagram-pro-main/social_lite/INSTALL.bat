@echo off
title Social Lite - Install
cd /d "%~dp0"
python tools\installer.py install
if errorlevel 1 (
  echo.
  echo Install failed. Make sure Python 3.10+ is installed and on PATH.
  pause
  exit /b 1
)
echo.
pause
