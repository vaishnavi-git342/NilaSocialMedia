# Social Lite

Phase-1 starter for the Instagram Pro college project.

A small Flask social feed with **register, login, logout, home feed, create post, like, delete, and profile** — ready for incremental reviews before the full Instagram Pro app.

## Quick start (Windows)

1. Double-click `INSTALL.bat`
2. Double-click `START.bat`
3. Open http://127.0.0.1:5001

**Demo login:** `demo@social.lite` / `password123`

## Manual start

```bash
cd social_lite
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt
.venv\Scripts\python run.py
```

## What’s included (Phase 1)

| Feature | Route | Notes |
|---------|--------|--------|
| Landing | `/` | |
| Register / Login / Logout | `/auth/...` | Real backend |
| Home feed + stories rail | `/home` | Stories = UI only |
| New post / Like / Delete | `/post/...` | Real backend |
| Profile | `/u/<username>` | Real backend |
| Explore | `/explore` | **Front-end demo** |
| Search | `/search` | **Client-side filter** |
| Messages | `/messages` | **UI chat preview** |
| Notifications | `/notifications` | **Sample alerts** |
| **Local AI Studio** | `/ai-studio` | Labels from Pro (caption, hashtags, …) |
| **AI Mood Feed** | `/mood` | Mood picker UI |
| **Festival Mode** | `/festival` | Onam / Vishu / Monsoon |
| **Travel Journey** | `/journey` | Sample journey map |

## Layout

```
social_lite/
  run.py                 # entrypoint (port 5001)
  config.py
  requirements.txt
  INSTALL.bat / START.bat / RESET_DATABASE.bat
  tools/installer.py
  app/
    models/              # User, Post, Like
    forms/               # WTForms
    routes/              # auth, main, post
    templates/           # Jinja pages
    static/css/app.css
    services/seed.py     # demo user
```

## Relation to final project

| Delivery | Folder | Scope |
|----------|--------|--------|
| **Progress (~30%)** | `social_lite/` | Auth, feed, posts, likes, Local AI API subset |
| **Final (100%)** | repo root (`Instagram Pro`) | Reels, stories, DM, privacy, full AI, super admin |

See [`docs/PROGRESS_DEMO.md`](../docs/PROGRESS_DEMO.md) for the review script.

## PPT

`docs/Social_Lite_Phase1.pptx` — slides for Phase-1 presentation.
