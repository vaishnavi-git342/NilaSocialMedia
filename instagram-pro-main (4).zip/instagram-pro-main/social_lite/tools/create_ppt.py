"""Generate Social Lite Phase-1 PowerPoint."""
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

OUT = Path(__file__).resolve().parent.parent / "docs" / "Social_Lite_Phase1.pptx"

BG = RGBColor(0x11, 0x11, 0x12)
ACCENT = RGBColor(0x00, 0x95, 0xF6)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT = RGBColor(0xF7, 0xF7, 0xF8)
DARK = RGBColor(0x1A, 0x1A, 0x1B)
MUTED = RGBColor(0x6B, 0x6B, 0x70)
ROW = RGBColor(0xEE, 0xF2, 0xF7)


def run_style(run, size=16, bold=False, color=DARK):
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    run.font.name = "Calibri"


def bg(slide, color=LIGHT):
    sh = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(7.5))
    sh.fill.solid()
    sh.fill.fore_color.rgb = color
    sh.line.fill.background()
    spTree = slide.shapes._spTree
    sp = sh._element
    spTree.remove(sp)
    spTree.insert(2, sp)


def bar(slide):
    b = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(0.12), Inches(7.5))
    b.fill.solid()
    b.fill.fore_color.rgb = ACCENT
    b.line.fill.background()


def title(slide, text):
    box = slide.shapes.add_textbox(Inches(0.5), Inches(0.35), Inches(12.3), Inches(0.7))
    p = box.text_frame.paragraphs[0]
    r = p.add_run()
    r.text = text
    run_style(r, 28, True, DARK)


def bullets(slide, items, top=1.2, size=16):
    box = slide.shapes.add_textbox(Inches(0.55), Inches(top), Inches(12.2), Inches(5.5))
    tf = box.text_frame
    tf.word_wrap = True
    for i, item in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = item
        p.level = 0
        p.space_after = Pt(8)
        p.font.size = Pt(size)
        p.font.color.rgb = DARK
        p.font.name = "Calibri"


def footer(slide, n, total=12):
    box = slide.shapes.add_textbox(Inches(0.5), Inches(7.05), Inches(12), Inches(0.3))
    p = box.text_frame.paragraphs[0]
    r = p.add_run()
    r.text = f"Social Lite · Phase 1 · {n}/{total}"
    run_style(r, 11, False, MUTED)
    p.alignment = PP_ALIGN.RIGHT


def table(slide, rows, left, top, width, height, widths):
    shape = slide.shapes.add_table(len(rows), len(rows[0]), Inches(left), Inches(top), Inches(width), Inches(height))
    t = shape.table
    for i, w in enumerate(widths):
        t.columns[i].width = Inches(w)
    for r, row in enumerate(rows):
        for c, val in enumerate(row):
            cell = t.cell(r, c)
            cell.text = str(val)
            for p in cell.text_frame.paragraphs:
                for run in p.runs:
                    run_style(run, 11 if r else 12, r == 0, WHITE if r == 0 else DARK)
            cell.fill.solid()
            cell.fill.fore_color.rgb = ACCENT if r == 0 else (ROW if r % 2 else WHITE)


def build():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    # 1 Title
    s = prs.slides.add_slide(prs.slide_layouts[6])
    bg(s, BG)
    top = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(0.15))
    top.fill.solid()
    top.fill.fore_color.rgb = ACCENT
    top.line.fill.background()
    box = s.shapes.add_textbox(Inches(0.9), Inches(2.1), Inches(11.5), Inches(4))
    tf = box.text_frame
    lines = [
        ("SOCIAL LITE", 40, True, WHITE),
        ("Phase 1 — Core Social Feed Application", 22, False, LIGHT),
        ("Register · Login · Home · Posts · Likes · Profile", 16, False, MUTED),
        ("", 12, False, MUTED),
        ("Mini Project — Incremental Delivery", 16, False, WHITE),
        ("Submitted by: ________________________", 14, False, MUTED),
        ("Guided by / College: ________________________", 14, False, MUTED),
    ]
    for i, (text, size, bold, color) in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        r = p.add_run()
        r.text = text
        run_style(r, size, bold, color)
        p.space_after = Pt(6)

    # 2 Why phase 1
    s = prs.slides.add_slide(prs.slide_layouts[6]); bg(s); bar(s)
    title(s, "Why Phase 1?")
    bullets(s, [
        "Project is reviewed incrementally — first show a working core, then the full system.",
        "Social Lite proves authentication, routing, templates, and SQLite persistence.",
        "Same Flask patterns are reused later in Instagram Pro (final project).",
        "Separate folder + installer keep Phase 1 demos clean and easy to run.",
        "Port 5001 avoids clashing with the final app on port 5000.",
    ])
    footer(s, 2)

    # 3 Intro
    s = prs.slides.add_slide(prs.slide_layouts[6]); bg(s); bar(s)
    title(s, "Introduction")
    bullets(s, [
        "Social Lite is a lightweight Instagram-style web app built with Flask.",
        "Users can register, log in, share photo posts, like content, and view profiles.",
        "Stack: Python, Flask, SQLAlchemy, SQLite, Jinja2, WTForms.",
        "Designed for offline lab demo with one-click Windows installer.",
        "This is Delivery #1 of the overall Instagram Pro college project.",
    ])
    footer(s, 3)

    # 4 Problem
    s = prs.slides.add_slide(prs.slide_layouts[6]); bg(s); bar(s)
    title(s, "Problem Definition")
    card = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.7), Inches(2.3), Inches(11.9), Inches(2.6))
    card.fill.solid(); card.fill.fore_color.rgb = WHITE; card.line.color.rgb = ACCENT
    box = s.shapes.add_textbox(Inches(1.0), Inches(2.6), Inches(11.3), Inches(2.0))
    p = box.text_frame.paragraphs[0]
    r = p.add_run()
    r.text = (
        "Students need a clear first milestone that demonstrates secure login, "
        "content upload, and a working feed before advanced modules (AI, reels, admin) "
        "are introduced in the final Instagram Pro system."
    )
    run_style(r, 18, False, DARK)
    footer(s, 4)

    # 5 Objectives
    s = prs.slides.add_slide(prs.slide_layouts[6]); bg(s); bar(s)
    title(s, "Objectives")
    bullets(s, [
        "Implement secure registration and login with hashed passwords.",
        "Build a chronological home feed backed by SQLite.",
        "Allow image post creation, like toggle, and owner delete.",
        "Provide a simple profile page listing a user’s posts.",
        "Ship an offline installer suitable for classroom review.",
    ])
    footer(s, 5)

    # 6 Modules
    s = prs.slides.add_slide(prs.slide_layouts[6]); bg(s); bar(s)
    title(s, "Modules")
    table(s, [
        ["Module", "Responsibility"],
        ["Auth", "Register, login, logout, session via Flask-Login"],
        ["Main / Home", "Landing page and chronological feed"],
        ["Post", "Upload image, caption, like toggle, delete"],
        ["Profile", "Public user page with post grid"],
        ["Installer", "venv create, pip install, start, reset DB"],
    ], 0.5, 1.15, 12.3, 4.8, [2.8, 9.5])
    footer(s, 6)

    # 7 Architecture
    s = prs.slides.add_slide(prs.slide_layouts[6]); bg(s); bar(s)
    title(s, "Architecture")
    bullets(s, [
        "Presentation: Jinja2 templates + CSS",
        "Application: Flask blueprints (auth, main, post)",
        "Data: SQLAlchemy models → SQLite (instance/social_lite.db)",
        "Files: app/static/uploads/posts/",
        "Flow: Browser → Route → ORM / Disk → HTML response",
        "App factory (create_app) keeps config and extensions testable.",
    ])
    footer(s, 7)

    # 8 Tech
    s = prs.slides.add_slide(prs.slide_layouts[6]); bg(s); bar(s)
    title(s, "Software & Hardware")
    table(s, [
        ["Item", "Requirement"],
        ["OS", "Windows 10/11"],
        ["Python", "3.10+"],
        ["Framework", "Flask 3, Flask-Login, Flask-WTF, SQLAlchemy"],
        ["Database", "SQLite"],
        ["RAM / Disk", "4 GB RAM · ~500 MB free"],
    ], 0.5, 1.15, 12.3, 4.5, [3.0, 9.3])
    footer(s, 8)

    # 9 Algorithm
    s = prs.slides.add_slide(prs.slide_layouts[6]); bg(s); bar(s)
    title(s, "Key Algorithms")
    bullets(s, [
        "Login: lookup email → verify password hash → reject if inactive → create session",
        "Create post: validate image → UUID filename → save disk → insert Post row",
        "Like toggle: if Like row exists delete it, else insert (unique user+post)",
        "Feed: SELECT posts ORDER BY created_at DESC LIMIT 50 → render cards",
    ])
    footer(s, 9)

    # 10 How to run
    s = prs.slides.add_slide(prs.slide_layouts[6]); bg(s); bar(s)
    title(s, "Demo / How to Run")
    bullets(s, [
        "1. Open folder social_lite",
        "2. Run INSTALL.bat (creates .venv and installs packages)",
        "3. Run START.bat",
        "4. Browser → http://127.0.0.1:5001",
        "5. Login: demo@social.lite / password123",
        "6. Create a post, like it, open profile, logout",
    ])
    footer(s, 10)

    # 11 Next / Final
    s = prs.slides.add_slide(prs.slide_layouts[6]); bg(s); bar(s)
    title(s, "Next Steps → Final Project")
    bullets(s, [
        "Phase 1 (done): Social Lite — auth + feed + posts",
        "Final: Instagram Pro (repo root) — stories, reels, DMs, privacy,",
        "       local AI studio, festival mode, super admin feature flags",
        "Final PPT: docs/Instagram_Pro_Mini_Project.pptx",
        "Final demo: ananya@kerala.app / password123  (port 5000)",
    ])
    footer(s, 11)

    # 12 Thanks
    s = prs.slides.add_slide(prs.slide_layouts[6])
    bg(s, BG)
    top = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(0.15))
    top.fill.solid(); top.fill.fore_color.rgb = ACCENT; top.line.fill.background()
    box = s.shapes.add_textbox(Inches(1), Inches(2.4), Inches(11.3), Inches(3))
    tf = box.text_frame
    for i, (text, size, bold, color) in enumerate([
        ("Thank You", 44, True, WHITE),
        ("Questions?", 22, False, LIGHT),
        ("demo@social.lite  /  password123", 16, False, WHITE),
        ("http://127.0.0.1:5001", 14, False, MUTED),
    ]):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        r = p.add_run()
        r.text = text
        run_style(r, size, bold, color)
        p.alignment = PP_ALIGN.CENTER
        p.space_after = Pt(8)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    prs.save(OUT)
    print("Saved", OUT)


if __name__ == "__main__":
    build()
