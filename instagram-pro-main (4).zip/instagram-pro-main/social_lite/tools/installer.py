"""
Social Lite — local installer / start / reset tools.

Creates a venv, installs requirements, and launches the Phase-1 app.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VENV = ROOT / ".venv"
PY = VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
PIP = VENV / ("Scripts/pip.exe" if os.name == "nt" else "bin/pip")
DB = ROOT / "instance" / "social_lite.db"
REQ = ROOT / "requirements.txt"
MARKER = ROOT / ".social_lite_installed"


def banner():
    print()
    print("=" * 52)
    print("   Social Lite  ·  Phase 1 Installer")
    print("=" * 52)
    print(f"   Folder: {ROOT}")
    print(f"   DB:     {DB}")
    print("=" * 52)


def run(cmd, **kwargs):
    print(">", " ".join(str(c) for c in cmd))
    return subprocess.call(cmd, cwd=str(ROOT), **kwargs)


def ensure_dirs():
    (ROOT / "instance").mkdir(exist_ok=True)
    (ROOT / "app" / "static" / "uploads" / "posts").mkdir(parents=True, exist_ok=True)
    (ROOT / "app" / "static" / "uploads" / "profiles").mkdir(parents=True, exist_ok=True)


def install():
    banner()
    ensure_dirs()
    if not VENV.exists():
        print("Creating virtualenv…")
        if run([sys.executable, "-m", "venv", str(VENV)]) != 0:
            print("Failed to create venv.")
            return 1
    print("Installing dependencies…")
    if run([str(PIP), "install", "--upgrade", "pip"]) != 0:
        return 1
    if run([str(PIP), "install", "-r", str(REQ)]) != 0:
        print("pip install failed.")
        return 1
    MARKER.write_text("ok\n", encoding="utf-8")
    print()
    print("Install complete.")
    print("Next: run START.bat  or  python tools/installer.py start")
    print("Demo login: demo@social.lite / password123")
    print("URL: http://127.0.0.1:5001")
    return 0


def start():
    banner()
    if not PY.exists():
        print("Virtualenv missing. Run install first.")
        return install() or start()
    ensure_dirs()
    print("Starting Social Lite on http://127.0.0.1:5001 …")
    return run([str(PY), str(ROOT / "run.py")])


def reset_db():
    banner()
    if DB.exists():
        DB.unlink()
        print("Deleted", DB)
    else:
        print("No database file found.")
    # Also clear uploaded posts so the demo starts clean
    posts = ROOT / "app" / "static" / "uploads" / "posts"
    if posts.exists():
        for f in posts.iterdir():
            if f.is_file() and f.name != ".gitkeep":
                f.unlink()
    print("Database will be recreated on next start (demo user seeded).")
    return 0


def main():
    action = (sys.argv[1] if len(sys.argv) > 1 else "install").lower()
    if action in ("install", "setup"):
        return install()
    if action in ("start", "run"):
        return start()
    if action in ("reset", "reset-db"):
        return reset_db()
    print("Usage: python tools/installer.py [install|start|reset-db]")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
