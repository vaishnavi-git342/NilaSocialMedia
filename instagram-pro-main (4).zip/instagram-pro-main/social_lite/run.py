"""Process entrypoint — Social Lite progress demo (~30% of Instagram Pro).

Port 5001 keeps this separate from the final app on 5000.
"""
import os
from app import create_app

app = create_app()

if __name__ == "__main__":
    host = os.environ.get("FLASK_HOST", "127.0.0.1")
    port = int(os.environ.get("FLASK_PORT", "5001"))
    print("=" * 56)
    print("  Social Lite  ·  Progress Demo (~30% of Instagram Pro)")
    print("=" * 56)
    print(f"  URL:   http://{host}:{port}")
    print("  Demo:  demo@social.lite / password123")
    print("  Scope: auth, feed, posts, likes, Local AI API subset")
    print("  Final: run root Instagram Pro on port 5000")
    print("=" * 56)
    app.run(debug=True, host=host, port=port, use_reloader=False)
