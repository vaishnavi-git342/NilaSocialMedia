"""Static UI fixtures for Phase-1 front-end demos.

These are display-only samples so reviewers can see Stories, Explore,
Messages, and Notifications without a full social backend yet.
"""

# Gradient rings + initials stand in for real story media
DEMO_STORIES = [
    {"username": "your story", "initial": "+", "self": True, "seen": False},
    {"username": "ananya_k", "initial": "A", "self": False, "seen": False},
    {"username": "arjun_b", "initial": "R", "self": False, "seen": False},
    {"username": "meera_m", "initial": "M", "self": False, "seen": True},
    {"username": "rahul_t", "initial": "R", "self": False, "seen": False},
    {"username": "priya_w", "initial": "P", "self": False, "seen": True},
    {"username": "vishnu_c", "initial": "V", "self": False, "seen": False},
]

DEMO_EXPLORE = [
    {"title": "Backwaters", "color": "#0ea5e9", "likes": "12.4k"},
    {"title": "Tea gardens", "color": "#16a34a", "likes": "8.1k"},
    {"title": "Beach dusk", "color": "#f59e0b", "likes": "21k"},
    {"title": "Temple lights", "color": "#dc2626", "likes": "5.6k"},
    {"title": "Street food", "color": "#db2777", "likes": "9.9k"},
    {"title": "Monsoon", "color": "#6366f1", "likes": "14.2k"},
    {"title": "Hill station", "color": "#059669", "likes": "7.3k"},
    {"title": "City night", "color": "#334155", "likes": "18k"},
    {"title": "Festival", "color": "#ea580c", "likes": "32k"},
]

DEMO_INBOX = [
    {"name": "Ananya", "preview": "See you at the cafe?", "time": "2m", "unread": True},
    {"name": "Arjun", "preview": "Sent a photo", "time": "1h", "unread": True},
    {"name": "Meera", "preview": "That reel was amazing 🔥", "time": "3h", "unread": False},
    {"name": "Rahul", "preview": "Are we still on for Sunday?", "time": "Yesterday", "unread": False},
    {"name": "Priya", "preview": "Liked your message", "time": "Yesterday", "unread": False},
]

DEMO_NOTIFICATIONS = [
    {"text": "ananya_k started following you", "time": "5m", "kind": "follow"},
    {"text": "arjun_b liked your photo", "time": "22m", "kind": "like"},
    {"text": "meera_m commented: “Beautiful shot!”", "time": "1h", "kind": "comment"},
    {"text": "rahul_t mentioned you in a comment", "time": "3h", "kind": "mention"},
    {"text": "priya_w liked your photo", "time": "Yesterday", "kind": "like"},
]

DEMO_SUGGESTIONS = [
    {"username": "travel_kerala", "subtitle": "Suggested for you"},
    {"username": "foodie_kochi", "subtitle": "Followed by ananya_k"},
    {"username": "munnar_views", "subtitle": "Popular"},
]

# Feature labels aligned with Instagram Pro Local AI Studio
AI_STUDIO_TOOLS = [
    {
        "id": "caption",
        "name": "AI Caption",
        "desc": "Generate an English caption from the photo context.",
        "sample": "Golden hour over the backwaters — slow boats and quieter minds.",
    },
    {
        "id": "hashtags",
        "name": "Smart Hashtags",
        "desc": "Suggest discoverable tags for the post.",
        "sample": "#Kerala #Backwaters #TravelDiaries #GoldenHour #IndieTravel",
    },
    {
        "id": "bilingual",
        "name": "Bilingual (EN + Manglish)",
        "desc": "Rewrite caption in English and Manglish.",
        "sample": "EN: Peaceful evening by the lake.\nManglish: Lake side oru calm evening alle?",
    },
    {
        "id": "places",
        "name": "Kerala Places",
        "desc": "Infer likely place tags from scene cues.",
        "sample": "Suggested: Alleppey · Kumarakom · Vembanad Lake",
    },
    {
        "id": "privacy",
        "name": "Privacy Meter",
        "desc": "Estimate how public vs private this post should be.",
        "sample": "Privacy score: 72/100 · Tip: Prefer Close Friends for face-forward shots.",
    },
    {
        "id": "safety",
        "name": "Safety Score",
        "desc": "Quick content-safety check before sharing.",
        "sample": "Safety: OK · No toxic / NSFW signals in caption draft.",
    },
    {
        "id": "moderation",
        "name": "AI Comment Filter",
        "desc": "Auto-hide toxic comments (same idea as Pro).",
        "sample": "Auto-hide enabled for high-toxicity phrases.",
    },
    {
        "id": "reel_frame",
        "name": "Reel Best Frame",
        "desc": "Pick a strong thumbnail frame from video.",
        "sample": "Best frame @ 00:02.4 — high contrast + subject centered.",
    },
]

AI_MOODS = [
    {"id": "happy", "label": "Happy", "emoji": "😊", "color": "#fbbf24"},
    {"id": "chill", "label": "Chill", "emoji": "🌊", "color": "#38bdf8"},
    {"id": "inspired", "label": "Inspired", "emoji": "✨", "color": "#a78bfa"},
    {"id": "nostalgic", "label": "Nostalgic", "emoji": "📷", "color": "#fb7185"},
    {"id": "energy", "label": "Energy", "emoji": "⚡", "color": "#34d399"},
    {"id": "focus", "label": "Focus", "emoji": "🎯", "color": "#94a3b8"},
]

AI_FESTIVALS = [
    {"id": "default", "name": "Classic", "emoji": "✨", "banner": "Default Instagram-like theme"},
    {"id": "onam", "name": "Onam", "emoji": "🌼", "banner": "Floral Pookalam vibes across the UI"},
    {"id": "vishu", "name": "Vishu", "emoji": "💥", "banner": "Bright Vishukkani gold accents"},
    {"id": "monsoon", "name": "Monsoon", "emoji": "🌧️", "banner": "Cool rainy-season palette"},
]

AI_JOURNEY_STOPS = [
    {"place": "Kochi", "note": "Harbor morning", "day": "Day 1"},
    {"place": "Alleppey", "note": "Houseboat evening", "day": "Day 2"},
    {"place": "Munnar", "note": "Tea estate walk", "day": "Day 4"},
    {"place": "Varkala", "note": "Cliff sunset", "day": "Day 6"},
]
