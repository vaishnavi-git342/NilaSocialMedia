"""Rule-based Local AI helpers — trimmed from Instagram Pro services.

Phase-1 / ~30% progress demo uses the same *feature contracts* as Pro
(`/api/ai/caption`, hashtags, bilingual, places, privacy, safety) without
requiring PyTorch. The final Instagram Pro app swaps in BLIP/CLIP models.
"""
from __future__ import annotations

import re
from typing import Any


PHRASE_MAP = [
    (r"\bbeautiful\b", "sundaram"),
    (r"\blove\b", "sneham"),
    (r"\bthank you\b", "nanni"),
    (r"\bhello\b", "namaskaram"),
    (r"\brain\b", "mazha"),
    (r"\bbeach\b", "kadappuram"),
    (r"\btravel\b", "yathra"),
    (r"\bsunset\b", "asthyamayam"),
    (r"\bhappy\b", "santhosham"),
    (r"\bfestival\b", "ulsavam"),
]

PLACE_CUES = {
    "beach": ["Varkala", "Kovalam", "Fort Kochi Beach"],
    "lake": ["Alleppey", "Kumarakom", "Vembanad Lake"],
    "tea": ["Munnar", "Wayanad"],
    "temple": ["Guruvayur", "Sabarimala", "Thrissur"],
    "rain": ["Monsoon Kerala", "Wayanad"],
    "food": ["Kochi", "Calicut"],
}

BASE_TAGS = ["#kerala", "#instagram", "#photooftheday", "#travel", "#india"]


def engine_name() -> str:
    return "social_lite_rules_v1"


def suggest_captions(caption_hint: str = "") -> list[str]:
    hint = (caption_hint or "").strip()
    if hint:
        return [
            hint,
            f"{hint} — captured in the moment.",
            f"Living for this: {hint}",
        ]
    return [
        "Golden hour over the backwaters — slow boats and quieter minds.",
        "Another Kerala frame for the diary.",
        "Soft light, softer plans.",
    ]


def recommend_hashtags(caption: str = "", count: int = 8) -> list[str]:
    text = (caption or "").lower()
    tags = list(BASE_TAGS)
    extras = {
        "beach": "#beachvibes",
        "rain": "#monsoon",
        "food": "#foodie",
        "temple": "#temple",
        "travel": "#wanderlust",
        "tea": "#teagardens",
        "sunset": "#goldenhour",
    }
    for key, tag in extras.items():
        if key in text and tag not in tags:
            tags.append(tag)
    tags.extend(["#godowncountry", "#mallu", "#reels"])
    # de-dupe preserve order
    seen = set()
    out = []
    for t in tags:
        if t.lower() not in seen:
            seen.add(t.lower())
            out.append(t)
        if len(out) >= count:
            break
    return out


def to_manglish(text: str) -> str:
    out = text or ""
    for pattern, repl in PHRASE_MAP:
        out = re.sub(pattern, repl, out, flags=re.IGNORECASE)
    return out


def bilingual_caption(text: str) -> dict[str, str]:
    en = (text or "").strip() or "Peaceful evening by the lake."
    return {
        "english": en,
        "manglish": to_manglish(en),
        "combined": f"{en}\n\n{to_manglish(en)}",
    }


def suggest_places(caption: str = "") -> list[str]:
    text = (caption or "").lower()
    found: list[str] = []
    for cue, places in PLACE_CUES.items():
        if cue in text:
            found.extend(places)
    if not found:
        found = ["Kochi", "Alleppey", "Munnar"]
    # unique
    seen = set()
    out = []
    for p in found:
        if p not in seen:
            seen.add(p)
            out.append(p)
    return out[:5]


def privacy_meter(audience: str = "public") -> dict[str, Any]:
    matrix = {
        "public": {"label": "Public", "score": 35, "risk": "high",
                   "who": "Anyone can see this post",
                   "tips": ["Avoid home address", "Review tagged people"]},
        "followers": {"label": "Followers only", "score": 65, "risk": "medium",
                      "who": "Only followers can see this",
                      "tips": ["Audit follower list regularly"]},
        "close_friends": {"label": "Close Friends", "score": 90, "risk": "low",
                          "who": "Only Close Friends list",
                          "tips": ["Best for personal moments"]},
    }
    data = matrix.get(audience, matrix["public"])
    return {
        "audience": audience,
        "clarity_score": data["score"],
        "risk": data["risk"],
        "label": data["label"],
        "who_can_see": data["who"],
        "tips": data["tips"],
        "summary": f"{data['label']}: {data['who']} (score {data['score']}/100)",
        "engine": engine_name(),
    }


def safety_score(caption: str = "") -> dict[str, Any]:
    text = (caption or "").lower()
    toxic_hits = [w for w in ("kill", "hate", "stupid", "idiot") if w in text]
    score = 95 if not toxic_hits else max(20, 95 - 25 * len(toxic_hits))
    return {
        "score": score,
        "status": "ok" if score >= 70 else "review",
        "flags": toxic_hits,
        "summary": "Safety: OK" if score >= 70 else "Safety: needs review",
        "engine": engine_name(),
    }


def feature_status() -> dict[str, Any]:
    """Subset of Pro `/api/ai/status` features — the ~30% progress surface."""
    return {
        "engine": engine_name(),
        "mode": "progress_demo_30pct",
        "features": {
            "caption": True,
            "hashtags": True,
            "bilingual": True,
            "places": True,
            "privacy_meter": True,
            "safety_score": True,
            "comment_moderation": True,
            "journey": True,
            "festival": True,
            "mood_feed": True,
            # Explicitly off in this demo slice
            "reels": False,
            "stories": False,
            "messages_backend": False,
            "super_admin": False,
            "clip_zero_shot": False,
        },
    }
