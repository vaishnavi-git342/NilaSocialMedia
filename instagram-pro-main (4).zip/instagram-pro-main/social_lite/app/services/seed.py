"""Seed a single demo account so lab reviewers can log in without registering."""
from app.extensions import db
from app.models.user import User

DEMO_EMAIL = "demo@social.lite"
DEMO_USERNAME = "demo_user"
DEMO_PASSWORD = "password123"


def ensure_demo_user() -> None:
    existing = User.query.filter_by(email=DEMO_EMAIL).first()
    if existing:
        return
    user = User(
        username=DEMO_USERNAME,
        email=DEMO_EMAIL,
        full_name="Demo User",
        bio="Phase-1 demo account for Social Lite.",
    )
    user.set_password(DEMO_PASSWORD)
    db.session.add(user)
    db.session.commit()
