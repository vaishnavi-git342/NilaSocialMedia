/**
 * Social Lite UI + real /api calls for the ~30% progress demo.
 * AI buttons hit the same route names as Instagram Pro (caption, hashtags, …).
 */
(function () {
  function $(sel, root) {
    return (root || document).querySelector(sel);
  }
  function $all(sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  }

  function csrfToken() {
    var m = document.querySelector('meta[name="csrf-token"]');
    if (m) return m.getAttribute("content");
    var hidden = document.querySelector('input[name="csrf_token"]');
    return hidden ? hidden.value : "";
  }

  function apiPost(url, body) {
    return fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": csrfToken(),
      },
      credentials: "same-origin",
      body: JSON.stringify(body || {}),
    }).then(function (r) {
      return r.json().then(function (data) {
        if (!r.ok) throw new Error((data && data.error) || "Request failed");
        return data;
      });
    });
  }

  function captionValue() {
    var el = $("#caption");
    return el ? el.value || "" : "";
  }

  function showOut(el, text) {
    if (!el) return;
    el.hidden = false;
    el.textContent = text;
  }

  // Stories modal
  var modal = $("#storyModal");
  var storyUser = $("#storyUser");
  var storyBody = $("#storyBody");
  $all("[data-story-user]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var name = btn.getAttribute("data-story-user");
      if (storyUser) storyUser.textContent = name;
      if (storyBody) {
        storyBody.textContent =
          name === "your story"
            ? "Add to your story (UI placeholder)."
            : "Viewing @" + name + "'s story — front-end preview only.";
      }
      if (modal) modal.hidden = false;
      btn.classList.add("is-seen");
    });
  });
  $all("[data-close-story]").forEach(function (el) {
    el.addEventListener("click", function () {
      if (modal) modal.hidden = true;
    });
  });

  $all("[data-follow]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var on = btn.classList.toggle("is-following");
      btn.textContent = on ? "Following" : "Follow";
    });
  });

  $all("[data-save-ui]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var on = btn.classList.toggle("is-saved");
      btn.textContent = on ? "Saved" : "Save";
    });
  });

  $all("[data-menu]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      alert("More options — UI placeholder for Phase 1.");
    });
  });

  $all("[data-explore-title]").forEach(function (tile) {
    tile.addEventListener("click", function () {
      alert(tile.getAttribute("data-explore-title") + "\n(Explore tile — UI only)");
    });
  });

  // Messages UI
  var dmPanel = $("#dmPanel");
  var dmName = $("#dmName");
  var dmThread = $("#dmThread");
  var dmForm = $("#dmForm");
  var dmInput = $("#dmInput");
  $all("[data-dm]").forEach(function (row) {
    row.addEventListener("click", function () {
      if (dmName) dmName.textContent = row.getAttribute("data-dm");
      if (dmPanel) dmPanel.hidden = false;
      row.classList.remove("is-unread");
    });
  });
  var dmClose = $("#dmClose");
  if (dmClose) {
    dmClose.addEventListener("click", function () {
      if (dmPanel) dmPanel.hidden = true;
    });
  }
  if (dmForm && dmThread && dmInput) {
    dmForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var text = (dmInput.value || "").trim();
      if (!text) return;
      var bubble = document.createElement("div");
      bubble.className = "sl-dm-bubble me";
      bubble.textContent = text;
      dmThread.appendChild(bubble);
      dmInput.value = "";
      dmThread.scrollTop = dmThread.scrollHeight;
    });
  }

  // --- Real AI API (same paths as Instagram Pro) ---
  var AI_ENDPOINTS = {
    caption: "/api/ai/caption",
    hashtags: "/api/ai/hashtags",
    bilingual: "/api/ai/bilingual",
    places: "/api/ai/places",
    privacy: "/api/ai/privacy",
    safety: "/api/ai/safety",
  };

  function formatAiResponse(key, data) {
    if (key === "caption") return (data.captions || []).join("\n");
    if (key === "hashtags") return (data.hashtags || []).join(" ");
    if (key === "bilingual") return data.combined || (data.english + "\n" + data.manglish);
    if (key === "places") return "Suggested: " + (data.places || []).join(" · ");
    if (key === "privacy") return data.summary || JSON.stringify(data);
    if (key === "safety") return data.summary + " (score " + data.score + ")";
    return JSON.stringify(data, null, 2);
  }

  function runAi(key, outEl, captionEl) {
    var url = AI_ENDPOINTS[key];
    if (!url) return;
    showOut(outEl, "Calling " + url + " …");
    var body = { caption: captionValue(), audience: "public" };
    apiPost(url, body)
      .then(function (data) {
        var text = formatAiResponse(key, data);
        showOut(outEl, text + "\n\nengine: " + (data.engine || "ok"));
        if (captionEl && (key === "caption" || key === "bilingual" || key === "hashtags")) {
          if (key === "caption" && data.captions && data.captions[0]) {
            captionEl.value = data.captions[0];
          } else if (key === "hashtags" && data.hashtags) {
            captionEl.value = (captionEl.value + " " + data.hashtags.join(" ")).trim();
          } else if (key === "bilingual" && data.english) {
            captionEl.value = data.combined || data.english;
          }
        }
      })
      .catch(function (err) {
        showOut(outEl, "AI error: " + err.message);
      });
  }

  $all("[data-run-ai]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var card = btn.closest("[data-ai-tool]");
      if (!card) return;
      var key = card.getAttribute("data-ai-tool");
      var out = card.querySelector(".sl-ai-output");
      // Tools without API in this 30% slice keep sample text
      if (!AI_ENDPOINTS[key]) {
        showOut(out, card.getAttribute("data-ai-sample") || "Preview only in progress demo.");
        return;
      }
      btn.disabled = true;
      runAi(key, out, $("#caption"));
      setTimeout(function () { btn.disabled = false; }, 800);
    });
  });

  $all("[data-ai-fill]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var key = btn.getAttribute("data-ai-fill");
      runAi(key, $("#createAiOut"), $("#caption"));
    });
  });

  // Load AI status badge if present
  var statusBox = $("#aiStatusBox");
  if (statusBox) {
    fetch("/api/ai/status", { credentials: "same-origin" })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        statusBox.textContent =
          "API mode: " + (data.mode || "?") + " · engine: " + (data.engine || "?");
      })
      .catch(function () {
        statusBox.textContent = "AI status unavailable";
      });
  }

  // Mood / festival UI
  $all("[data-mood]").forEach(function (card) {
    card.addEventListener("click", function () {
      $all("[data-mood]").forEach(function (c) { c.classList.remove("is-active"); });
      card.classList.add("is-active");
      var label = card.getAttribute("data-mood");
      var box = $("#moodResult");
      var title = $("#moodTitle");
      var copy = $("#moodCopy");
      if (box) box.hidden = false;
      if (title) title.textContent = "AI Mood Feed · " + label;
      if (copy) {
        copy.textContent =
          "Showing posts ranked for “" + label + "” mood (UI preview — full ranking in Instagram Pro).";
      }
    });
  });

  $all("[data-festival]").forEach(function (row) {
    row.addEventListener("click", function () {
      var banner = $("#festivalBanner");
      var text = row.getAttribute("data-festival") + " — " + row.getAttribute("data-banner");
      if (banner) {
        banner.hidden = false;
        banner.textContent = text;
      }
      $all("[data-festival]").forEach(function (r) { r.classList.remove("is-active"); });
      row.classList.add("is-active");
    });
  });

  var searchInput = $("#searchInput");
  if (searchInput) {
    searchInput.addEventListener("input", function () {
      var q = searchInput.value.trim().toLowerCase();
      $all("[data-search-name]").forEach(function (row) {
        var name = (row.getAttribute("data-search-name") || "").toLowerCase();
        row.style.display = !q || name.indexOf(q) !== -1 ? "" : "none";
      });
    });
  }
})();
