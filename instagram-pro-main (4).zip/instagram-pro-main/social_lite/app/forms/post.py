"""Forms for creating posts."""
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileRequired, FileAllowed
from wtforms import TextAreaField, SubmitField
from wtforms.validators import Optional, Length


class PostForm(FlaskForm):
    caption = TextAreaField("Caption", validators=[Optional(), Length(max=2200)])
    image = FileField(
        "Photo",
        validators=[
            FileRequired(),
            FileAllowed(["jpg", "jpeg", "png", "gif", "webp"], "Images only."),
        ],
    )
    submit = SubmitField("Share")
