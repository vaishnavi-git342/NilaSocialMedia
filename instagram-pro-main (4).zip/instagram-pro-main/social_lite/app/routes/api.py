"""JSON API subset (~30%) patterned after Instagram Pro `app/routes/api.py`.

Includes:
  - POST like toggle (same contract as Pro)
  - Local AI endpoints: caption, hashtags, bilingual, places, privacy, safety, status

Full Pro also has follow/block/mute/reels/stories/ moderation pipelines — those
stay in the final project.
"""
from functools import wraps

from flask import Blueprint, request, jsonify, current_app
from flask_login import login_required, current_user

from app.extensions import db
from app.models.post import Post, Like
from app.services import ai_lite

api_bp = Blueprint("api", __name__)


def ai_safe(fn):
    """Match Pro: AI failures return JSON 503 instead of HTML 500."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except Exception as exc:
            current_app.logger.exception("AI endpoint error in %s", fn.__name__)
            return jsonify({"error": "AI unavailable", "detail": str(exc)}), 503
    return wrapper


def _caption_from_request() -> str:
    if request.is_json:
        return (request.get_json(silent=True) or {}).get("caption", "") or ""
    return request.form.get("caption", "") or ""


@api_bp.route("/post/<int:post_id>/like", methods=["POST"])
@login_required
def toggle_like(post_id):
    post = Post.query.get_or_404(post_id)
    existing = Like.query.filter_by(user_id=current_user.id, post_id=post.id).first()
    if existing:
        db.session.delete(existing)
        liked = False
    else:
        db.session.add(Like(user_id=current_user.id, post_id=post.id))
        liked = True
    db.session.commit()
    return jsonify({"liked": liked, "count": post.like_count})


@api_bp.route("/ai/status")
@login_required
def ai_status():
    return jsonify(ai_lite.feature_status())


@api_bp.route("/ai/caption", methods=["POST"])
@login_required
@ai_safe
def ai_caption():
    caption = _caption_from_request()
    captions = ai_lite.suggest_captions(caption)
    return jsonify({"captions": captions, "engine": ai_lite.engine_name()})


@api_bp.route("/ai/hashtags", methods=["POST"])
@login_required
@ai_safe
def ai_hashtags():
    caption = _caption_from_request()
    tags = ai_lite.recommend_hashtags(caption)
    return jsonify({"hashtags": tags, "engine": ai_lite.engine_name()})


@api_bp.route("/ai/bilingual", methods=["POST"])
@login_required
@ai_safe
def ai_bilingual():
    caption = _caption_from_request()
    result = ai_lite.bilingual_caption(caption)
    result["engine"] = ai_lite.engine_name()
    return jsonify(result)


@api_bp.route("/ai/places", methods=["POST"])
@login_required
@ai_safe
def ai_places():
    caption = _caption_from_request()
    places = ai_lite.suggest_places(caption)
    return jsonify({"places": places, "engine": ai_lite.engine_name()})


@api_bp.route("/ai/privacy", methods=["POST"])
@login_required
@ai_safe
def ai_privacy():
    audience = "public"
    if request.is_json:
        audience = (request.get_json(silent=True) or {}).get("audience", "public")
    else:
        audience = request.form.get("audience", "public")
    return jsonify(ai_lite.privacy_meter(audience))


@api_bp.route("/ai/safety", methods=["POST"])
@login_required
@ai_safe
def ai_safety():
    caption = _caption_from_request()
    return jsonify(ai_lite.safety_score(caption))
