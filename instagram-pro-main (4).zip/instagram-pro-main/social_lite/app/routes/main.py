"""Main surface: landing, feed, profile, plus front-end-only demo screens."""
from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required, current_user
from app.models.user import User
from app.models.post import Post
from app.services.ui_demo import (
    DEMO_STORIES,
    DEMO_EXPLORE,
    DEMO_INBOX,
    DEMO_NOTIFICATIONS,
    DEMO_SUGGESTIONS,
    AI_STUDIO_TOOLS,
    AI_MOODS,
    AI_FESTIVALS,
    AI_JOURNEY_STOPS,
)

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    """Public landing — bounce signed-in users straight into the feed."""
    if current_user.is_authenticated:
        return redirect(url_for("main.home"))
    return render_template("main/index.html")


@main_bp.route("/home")
@login_required
def home():
    """Chronological feed plus UI-only stories / suggestions rails."""
    posts = Post.query.order_by(Post.created_at.desc()).limit(50).all()
    return render_template(
        "main/home.html",
        posts=posts,
        stories=DEMO_STORIES,
        suggestions=DEMO_SUGGESTIONS,
    )


@main_bp.route("/u/<username>")
@login_required
def profile(username):
    user = User.query.filter_by(username=username).first_or_404()
    posts = (
        Post.query.filter_by(user_id=user.id)
        .order_by(Post.created_at.desc())
        .all()
    )
    return render_template("main/profile.html", profile_user=user, posts=posts)


# --- Front-end demo screens (no persistence / no real social graph) ---

@main_bp.route("/explore")
@login_required
def explore():
    return render_template("main/explore.html", tiles=DEMO_EXPLORE)


@main_bp.route("/messages")
@login_required
def messages():
    return render_template("main/messages.html", inbox=DEMO_INBOX)


@main_bp.route("/notifications")
@login_required
def notifications():
    return render_template("main/notifications.html", items=DEMO_NOTIFICATIONS)


@main_bp.route("/search")
@login_required
def search():
    # Client-side filter only — names are demo fixtures
    people = [s for s in DEMO_STORIES if not s.get("self")] + [
        {"username": s["username"], "initial": s["username"][0].upper()}
        for s in DEMO_SUGGESTIONS
    ]
    return render_template("main/search.html", people=people)


@main_bp.route("/ai-studio")
@login_required
def ai_studio():
    """Local AI Studio labels — UI preview mirroring Instagram Pro tools."""
    return render_template("main/ai_studio.html", tools=AI_STUDIO_TOOLS)


@main_bp.route("/mood")
@login_required
def mood():
    return render_template("main/mood.html", moods=AI_MOODS)


@main_bp.route("/festival")
@login_required
def festival():
    return render_template("main/festival.html", modes=AI_FESTIVALS)


@main_bp.route("/journey")
@login_required
def journey():
    return render_template("main/journey.html", stops=AI_JOURNEY_STOPS)
