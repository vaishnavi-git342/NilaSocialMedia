"""Post create / like / delete routes."""
from flask import Blueprint, render_template, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from app.extensions import db
from app.models.post import Post, Like
from app.forms.post import PostForm
from app.utils.uploads import save_image

post_bp = Blueprint("post", __name__)


@post_bp.route("/new", methods=["GET", "POST"])
@login_required
def create():
    form = PostForm()
    if form.validate_on_submit():
        relative_path = save_image(form.image.data, subfolder="posts")
        post = Post(
            user_id=current_user.id,
            caption=(form.caption.data or "").strip(),
            image_filename=relative_path,
        )
        db.session.add(post)
        db.session.commit()
        flash("Post shared.", "success")
        return redirect(url_for("main.home"))
    return render_template("post/create.html", form=form)


@post_bp.route("/<int:post_id>/like", methods=["POST"])
@login_required
def like(post_id):
    """Toggle like — one row per (user, post); delete if it already exists."""
    post = Post.query.get_or_404(post_id)
    existing = Like.query.filter_by(user_id=current_user.id, post_id=post.id).first()
    if existing:
        db.session.delete(existing)
    else:
        db.session.add(Like(user_id=current_user.id, post_id=post.id))
    db.session.commit()
    return redirect(url_for("main.home"))


@post_bp.route("/<int:post_id>/delete", methods=["POST"])
@login_required
def delete(post_id):
    post = Post.query.get_or_404(post_id)
    if post.user_id != current_user.id:
        abort(403)
    db.session.delete(post)
    db.session.commit()
    flash("Post deleted.", "info")
    return redirect(url_for("main.home"))
