"""Upload helpers — keep filename generation and validation in one place."""
import uuid
from pathlib import Path
from werkzeug.utils import secure_filename
from flask import current_app


def allowed_image(filename: str) -> bool:
    if not filename or "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in current_app.config["ALLOWED_IMAGE_EXTENSIONS"]


def save_image(file_storage, subfolder: str = "posts") -> str:
    """Persist an uploaded image and return the relative path used in the DB.

    We prefix a UUID so two users uploading `photo.jpg` never collide on disk.
    """
    original = secure_filename(file_storage.filename or "upload.jpg")
    ext = original.rsplit(".", 1)[-1].lower() if "." in original else "jpg"
    stored_name = f"{uuid.uuid4().hex}.{ext}"
    dest_dir = Path(current_app.config["UPLOAD_FOLDER"]) / subfolder
    dest_dir.mkdir(parents=True, exist_ok=True)
    file_storage.save(dest_dir / stored_name)
    # Relative to the uploads root — templates prepend /static/uploads/
    return f"{subfolder}/{stored_name}"
