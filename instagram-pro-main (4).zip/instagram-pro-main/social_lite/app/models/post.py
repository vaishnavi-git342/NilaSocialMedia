"""Post and Like models for the Phase-1 feed.

Posts store a relative filename under static/uploads/posts so templates can
build URLs without hard-coding absolute paths. Likes use a unique constraint
to keep toggle logic simple (insert vs delete one row).
"""
from datetime import datetime
from app.extensions import db


class Post(db.Model):
    __tablename__ = "posts"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    caption = db.Column(db.Text, default="")
    image_filename = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)

    author = db.relationship("User", back_populates="posts")
    likes = db.relationship("Like", back_populates="post", cascade="all, delete-orphan")

    @property
    def like_count(self) -> int:
        return len(self.likes)

    def liked_by(self, user) -> bool:
        if user is None or not getattr(user, "is_authenticated", False):
            return False
        return any(like.user_id == user.id for like in self.likes)

    def __repr__(self):
        return f"<Post {self.id} by={self.user_id}>"


class Like(db.Model):
    __tablename__ = "likes"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id", ondelete="CASCADE"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = db.relationship("User", back_populates="likes")
    post = db.relationship("Post", back_populates="likes")

    __table_args__ = (
        db.UniqueConstraint("user_id", "post_id", name="uq_user_post_like"),
    )
