"""Model package exports — import here so db.create_all() sees every table."""
from app.models.user import User
from app.models.post import Post, Like

__all__ = ["User", "Post", "Like"]
