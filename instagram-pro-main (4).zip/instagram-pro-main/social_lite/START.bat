@echo off
title Social Lite - Start
cd /d "%~dp0"
python tools\installer.py start
pause
