"""Generate Instagram Pro Mini Project PowerPoint."""
from pathlib import Path

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import nsmap
from pptx.oxml import parse_xml

OUT = Path(__file__).resolve().parent.parent / "docs" / "Instagram_Pro_Mini_Project.pptx"

# Colors — clean academic (avoid purple AI look)
BG = RGBColor(0x0F, 0x0F, 0x10)
ACCENT = RGBColor(0xE1, 0x30, 0x6C)  # Instagram-ish pink/magenta
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT = RGBColor(0xF5, 0xF5, 0xF5)
DARK = RGBColor(0x1A, 0x1A, 0x1B)
MUTED = RGBColor(0x6B, 0x6B, 0x70)
CARD = RGBColor(0xFF, 0xFF, 0xFF)
ROW_ALT = RGBColor(0xF3, 0xF4, 0xF6)


def set_run(run, size=18, bold=False, color=DARK, font="Calibri"):
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    run.font.name = font


def add_bg(slide, color=LIGHT):
    shape = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(7.5)
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = color
    shape.line.fill.background()
    # send to back
    spTree = slide.shapes._spTree
    sp = shape._element
    spTree.remove(sp)
    spTree.insert(2, sp)


def add_accent_bar(slide):
    bar = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(0.12), Inches(7.5)
    )
    bar.fill.solid()
    bar.fill.fore_color.rgb = ACCENT
    bar.line.fill.background()


def add_footer(slide, page, total=16):
    box = slide.shapes.add_textbox(Inches(0.5), Inches(7.05), Inches(12), Inches(0.35))
    tf = box.text_frame
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = f"Instagram Pro  ·  Mini Project  ·  {page}/{total}"
    set_run(run, 11, False, MUTED)
    p.alignment = PP_ALIGN.RIGHT


def title_box(slide, text, top=0.35, size=28):
    box = slide.shapes.add_textbox(Inches(0.5), Inches(top), Inches(12.3), Inches(0.7))
    tf = box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = text
    set_run(run, size, True, DARK)
    return box


def bullets(slide, items, top=1.15, left=0.55, width=12.2, size=16, spacing=True):
    box = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(5.6))
    tf = box.text_frame
    tf.word_wrap = True
    for i, item in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = item
        p.level = 0
        p.space_after = Pt(8 if spacing else 4)
        for run in p.runs:
            set_run(run, size, False, DARK)
        # ensure formatting on paragraph font
        p.font.size = Pt(size)
        p.font.color.rgb = DARK
        p.font.name = "Calibri"
    return box


def add_table(slide, rows, left, top, width, height, col_widths=None):
    cols = len(rows[0])
    table_shape = slide.shapes.add_table(len(rows), cols, Inches(left), Inches(top), Inches(width), Inches(height))
    table = table_shape.table
    if col_widths:
        for i, w in enumerate(col_widths):
            table.columns[i].width = Inches(w)
    for r, row in enumerate(rows):
        for c, val in enumerate(row):
            cell = table.cell(r, c)
            cell.text = str(val)
            for p in cell.text_frame.paragraphs:
                for run in p.runs:
                    is_header = r == 0
                    set_run(run, 9 if not is_header else 10, is_header, WHITE if is_header else DARK)
                p.font.size = Pt(9 if r else 10)
                p.font.bold = r == 0
                p.font.color.rgb = WHITE if r == 0 else DARK
            # fill
            fill = cell.fill
            fill.solid()
            fill.fore_color.rgb = ACCENT if r == 0 else (ROW_ALT if r % 2 else WHITE)
    return table_shape


def new_content_slide(prs):
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # blank
    add_bg(slide, LIGHT)
    add_accent_bar(slide)
    return slide


def build():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    # ---- 1 Title ----
    s = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(s, BG)
    # accent stripe
    stripe = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(0.15))
    stripe.fill.solid()
    stripe.fill.fore_color.rgb = ACCENT
    stripe.line.fill.background()

    box = s.shapes.add_textbox(Inches(0.8), Inches(2.0), Inches(11.5), Inches(4))
    tf = box.text_frame
    tf.word_wrap = True
    lines = [
        ("INSTAGRAM PRO", 40, True, WHITE),
        ("AI-Powered Social Media Web Application", 22, False, LIGHT),
        ("A Flask-based Instagram Clone with Local AI, Privacy Controls & Super Admin", 14, False, MUTED),
        ("", 12, False, MUTED),
        ("Mini Project Presentation  |  2025–2026", 16, False, WHITE),
        ("Submitted by: ________________________", 14, False, MUTED),
        ("Guided by: ________________________", 14, False, MUTED),
        ("Department / College: ________________________", 14, False, MUTED),
    ]
    for i, (text, size, bold, color) in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        run = p.add_run()
        run.text = text
        set_run(run, size, bold, color)
        p.space_after = Pt(6)

    # ---- 2 Introduction ----
    s = new_content_slide(prs)
    title_box(s, "Introduction")
    bullets(s, [
        "Social media platforms like Instagram dominate digital communication and content sharing.",
        "Existing academic clones often lack privacy controls, local AI, and admin governance.",
        "Instagram Pro is a full-stack web clone built with Python Flask + SQLite.",
        "Supports posts, stories, reels, DMs, follow requests, block / mute / restrict.",
        "Integrates Local AI Studio: captions, hashtags, toxicity filter, bilingual Manglish.",
        "Includes Super Admin to enable/disable features and deactivate users.",
        "Designed for offline college demo with one-click Windows installer.",
        "Kerala-themed seed data for realistic classroom presentation.",
    ], size=15)
    add_footer(s, 2)

    # ---- 3 Abstract ----
    s = new_content_slide(prs)
    title_box(s, "Abstract")
    bullets(s, [
        "Instagram Pro is an Instagram-like social networking web app developed using Flask.",
        "Core modules: Auth, Feed, Posts, Stories, Reels, Messages, Explore, Settings.",
        "Privacy: private accounts, follow approval, block, mute, restrict, report.",
        "Local AI: image captioning, hashtags, comment moderation, mood feed, festival mode.",
        "Super Admin: global/per-user feature flags and account deactivate/activate.",
        "Data in SQLite; media in local uploads; no cloud dependency required for demo.",
        "Suitable for academic evaluation of full-stack design, DB modeling, and AI integration.",
        "Result: working offline demo with seeded users and measurable feature coverage.",
    ], size=15)
    add_footer(s, 3)

    # ---- 4 Problem ----
    s = new_content_slide(prs)
    title_box(s, "Problem Definition")
    card = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.7), Inches(2.2), Inches(11.9), Inches(2.8))
    card.fill.solid()
    card.fill.fore_color.rgb = WHITE
    card.line.color.rgb = ACCENT
    box = s.shapes.add_textbox(Inches(1.0), Inches(2.5), Inches(11.3), Inches(2.2))
    tf = box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = (
        "Existing Instagram-style academic clones provide basic posting features but lack "
        "integrated local AI assistance, Instagram-like privacy/safety controls, and a "
        "super-admin governance layer to manage users and feature access—creating a gap "
        "that Instagram Pro addresses as a complete offline educational platform."
    )
    set_run(run, 18, False, DARK)
    p.alignment = PP_ALIGN.LEFT
    add_footer(s, 4)

    # ---- 5 Literature (part 1) ----
    s = new_content_slide(prs)
    title_box(s, "Literature Survey (1/2)")
    rows1 = [
        ["TITLE & YEAR", "AUTHOR & PUBLICATION", "ALGORITHM", "METHODOLOGY", "METRIC", "RESULT"],
        ["Deep Residual Learning (2016)", "He et al., CVPR", "ResNet / CNN", "Visual features", "Top-5 error", "Deep vision for captioning"],
        ["BLIP (2022)", "Li et al., ICML", "V-L Transformer", "Image–text matching", "CIDEr/SPICE", "Strong captioning"],
        ["CLIP (2021)", "Radford et al.", "Contrastive pretrain", "Joint embeddings", "Zero-shot acc.", "Tagging / similarity"],
        ["Toxicity Detection (2017–20)", "Jigsaw studies", "LR / BERT", "Toxicity features", "P / R / F1", "Safer comments"],
    ]
    add_table(s, rows1, 0.4, 1.15, 12.5, 5.2, [2.4, 2.2, 1.8, 2.0, 1.5, 2.6])
    add_footer(s, 5)

    # ---- 5b Literature part 2 ----
    s = new_content_slide(prs)
    title_box(s, "Literature Survey (2/2)")
    rows2 = [
        ["TITLE & YEAR", "AUTHOR & PUBLICATION", "ALGORITHM", "METHODOLOGY", "METRIC", "RESULT"],
        ["Social Network Privacy (2013)", "Squicciarini, ACM TIST", "Access control", "Privacy preferences", "Compliance", "Private accounts build trust"],
        ["Recommender Systems Handbook", "Ricci et al.", "CF / Ranking", "User–item signals", "NDCG / CTR", "Feed ranking helps"],
        ["Flask Web Development (2018)", "Grinberg, O’Reilly", "App Factory", "Blueprint modules", "Maintainability", "Fits multi-module apps"],
        ["Hashtag / Engagement studies", "IEEE Access et al.", "NLP / TF–IDF", "Captions & tags", "Engagement rate", "Smart tags help discovery"],
    ]
    add_table(s, rows2, 0.4, 1.15, 12.5, 5.2, [2.4, 2.2, 1.8, 2.0, 1.5, 2.6])
    add_footer(s, 6)

    # ---- 6 Design diagrams ----
    s = new_content_slide(prs)
    title_box(s, "Design Diagrams")
    bullets(s, [
        "DFD Level 0: User / Super Admin ↔ Instagram Pro ↔ SQLite + Uploads",
        "DFD Level 1: Auth, Content, Social Graph, Messaging, AI Studio, Admin Control",
        "Use Case: Guest (login/register), User (post/story/reel/DM/AI), Super Admin (features/users)",
        "Class Diagram: User, Profile, Post, Reel, Story, FeatureFlag, UserFeatureOverride",
        "State Diagram: Registered → Active ⇄ Deactivated; Active → LoggedIn",
        "Activity: Login → Upload → AI Assist? → Save Post → Feed",
        "Sequence: Browser → Auth → DB verify → Feed (privacy filtered)",
        "See docs/MINI_PROJECT_SLIDES.md (Mermaid) and docs/images/ for PNG diagrams.",
    ], size=15)
    add_footer(s, 7)

    # ---- 7 Modules ----
    s = new_content_slide(prs)
    title_box(s, "Module Description")
    mod_rows = [
        ["Module", "Description"],
        ["Authentication", "Register, login, logout, password reset, Flask-Login sessions"],
        ["Profile & Feed", "Bio, photo, private account, posts, likes, comments, saves"],
        ["Stories & Reels", "24h stories, highlights; short videos + AI best-frame thumb"],
        ["Messaging", "Direct conversations and private messages"],
        ["Social Safety", "Block, mute, restrict, report, not interested"],
        ["Local AI Studio", "Caption, hashtags, bilingual, places, toxicity moderation"],
        ["Mood & Festival", "Mood feed; festival/Onam UI themes; travel journey map"],
        ["Super Admin", "Feature flags (global/per-user), deactivate users, roles"],
        ["Installer", "Offline Windows install / start / reset DB / repair"],
    ]
    add_table(s, mod_rows, 0.5, 1.1, 12.3, 5.5, [2.8, 9.5])
    add_footer(s, 8)

    # ---- 8 Requirements ----
    s = new_content_slide(prs)
    title_box(s, "Software & Hardware Requirements")
    sw = [
        ["Software", "Specification"],
        ["OS", "Windows 10/11 (Linux/macOS for development)"],
        ["Language / Framework", "Python 3.10+, Flask 3.x, SQLAlchemy, SQLite"],
        ["Frontend", "Jinja2, Bootstrap 5 (local), JavaScript"],
        ["AI (optional)", "PyTorch, Transformers (BLIP), OpenCV"],
        ["Tools / Browser", "Git, VS Code/Cursor, Chrome/Edge/Firefox"],
    ]
    add_table(s, sw, 0.5, 1.1, 6.0, 4.2, [2.2, 3.8])
    hw = [
        ["Hardware", "Minimum", "Recommended"],
        ["CPU", "Dual-core", "Quad-core"],
        ["RAM", "4 GB", "8–16 GB (AI)"],
        ["Storage", "2 GB free", "5 GB+"],
        ["Display", "1366×768", "1920×1080"],
        ["Network", "Not required (local)", "Optional for CDN / Live IG"],
    ]
    add_table(s, hw, 6.8, 1.1, 6.0, 4.2, [1.6, 2.0, 2.4])
    add_footer(s, 9)

    # ---- 9 Algorithm ----
    s = new_content_slide(prs)
    title_box(s, "Algorithm")
    bullets(s, [
        "Algorithm 1 — Login: verify email/password → if inactive show reason → else create session → /feed",
        "Algorithm 2 — Feature flags: user override → else global FeatureFlag → else default True",
        "Algorithm 3 — Privacy feed: load candidates → skip blocked / private non-followers / hidden → render",
        "Algorithm 4 — Comment moderation: score toxicity → reject/hide if above threshold → else save",
        "",
        "Feature resolution (pseudocode):",
        "  if UserFeatureOverride exists: return override.enabled",
        "  if FeatureFlag exists: return flag.enabled",
        "  return True",
    ], size=15)
    add_footer(s, 10)

    # ---- 10 Architecture ----
    s = new_content_slide(prs)
    title_box(s, "System Architecture")
    arch = [
        ["Layer", "Components"],
        ["Presentation", "Jinja2 templates, Bootstrap 5, app.js"],
        ["Application", "Flask blueprints: auth, post, reel, story, message, admin, pro…"],
        ["Service", "Local AI, feature flags, feed ranking, moderation"],
        ["Data", "SQLAlchemy ORM → SQLite"],
        ["Storage", "app/static/uploads/ (posts, profiles, stories, reels)"],
    ]
    add_table(s, arch, 0.5, 1.15, 12.3, 3.8, [2.5, 9.8])
    box = s.shapes.add_textbox(Inches(0.55), Inches(5.3), Inches(12), Inches(1))
    tf = box.text_frame
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = "Flow:  Browser  →  Flask Route  →  Service / ORM  →  SQLite + Files  →  HTML / JSON"
    set_run(run, 16, True, ACCENT)
    add_footer(s, 11)

    # ---- 11 Results ----
    s = new_content_slide(prs)
    title_box(s, "Analysis on Results")
    res = [
        ["Aspect", "Observation"],
        ["Modules delivered", "Auth, Feed, Posts, Stories, Reels, DM, Explore, AI, Admin"],
        ["Demo users", "8 Kerala accounts — password: password123"],
        ["Database", "30+ tables incl. social controls & feature flags"],
        ["Privacy", "Private content gated; blocks prevent interaction"],
        ["Super Admin", "Global + per-user toggles; deactivate blocks login"],
        ["Local AI", "Caption / hashtag / moderation offline after model download"],
        ["Installer", "One-click install/start/reset for lab demo"],
        ["Usability", "Click-to-fill demo credentials on login page"],
    ]
    add_table(s, res, 0.5, 1.1, 12.3, 5.5, [2.8, 9.5])
    add_footer(s, 12)

    # ---- 12 Comparison ----
    s = new_content_slide(prs)
    title_box(s, "Comparison with Existing Systems")
    cmp_rows = [
        ["Feature", "Basic IG Clone", "Cloud Social Apps", "Instagram Pro"],
        ["Posts / Likes / Comments", "Yes", "Yes", "Yes"],
        ["Stories & Reels", "Rare", "Yes", "Yes"],
        ["Private + follow request", "Rare", "Yes", "Yes"],
        ["Block / Mute / Restrict", "Rare", "Yes", "Yes"],
        ["Local AI (no API key)", "No", "Cloud AI", "Yes"],
        ["Super Admin feature flags", "No", "Ops tools", "Yes"],
        ["Offline Windows installer", "No", "N/A", "Yes"],
        ["College viva suitability", "Partial", "Hard to host", "Strong"],
    ]
    add_table(s, cmp_rows, 0.4, 1.1, 12.5, 5.5, [3.5, 2.8, 3.0, 3.2])
    add_footer(s, 13)

    # ---- 13 Conclusion ----
    s = new_content_slide(prs)
    title_box(s, "Conclusion")
    bullets(s, [
        "Successfully designed and implemented Instagram Pro using Flask + SQLite.",
        "Delivered Instagram-like features: feed, stories, reels, messaging, privacy tools.",
        "Integrated local AI for captions, hashtags, and comment safety.",
        "Added Super Admin for feature governance and user activation control.",
        "Relational design supports ER, DFD, and use-case academic documentation.",
        "Offline installer and demo accounts make viva presentation practical.",
        "Project meets objectives of full-stack development, DB design, and AI integration.",
    ], size=16)
    add_footer(s, 14)

    # ---- 14 Future scope ----
    s = new_content_slide(prs)
    title_box(s, "Future Scope")
    bullets(s, [
        "Real-time chat using WebSockets (Socket.IO).",
        "Mobile-responsive PWA / Flutter companion app.",
        "Stronger recommendation ranking with online learning.",
        "Cloud deployment (Docker + PostgreSQL) for multi-user labs.",
        "Official Meta Graph API (OAuth) instead of unofficial scrapers.",
        "Advanced analytics dashboard for Super Admin.",
        "End-to-end encrypted DMs and two-factor authentication.",
        "Multilingual UI beyond English–Manglish captions.",
    ], size=16)
    add_footer(s, 15)

    # ---- 15 References ----
    s = new_content_slide(prs)
    title_box(s, "References (IEEE)")
    bullets(s, [
        "[1] M. Grinberg, Flask Web Development, 2nd ed. O’Reilly Media, 2018.",
        "[2] A. Ronacher et al., “Flask Documentation,” Pallets Projects.",
        "[3] K. He et al., “Deep residual learning for image recognition,” IEEE CVPR, 2016.",
        "[4] J. Li et al., “BLIP: Bootstrapping language-image pre-training,” ICML, 2022.",
        "[5] A. Radford et al., “Learning transferable visual models…,” ICML, 2021.",
        "[6] F. Ricci et al., Eds., Recommender Systems Handbook, 2nd ed. Springer, 2015.",
        "[7] A. C. Squicciarini et al., “Privacy policies for social networks,” ACM TIST, 2013.",
        "[8] SQLAlchemy Authors, “SQLAlchemy Documentation.” https://docs.sqlalchemy.org/",
        "[9] Meta, “Instagram Help Center – Privacy and Safety.” https://help.instagram.com/",
        "[10] Jigsaw, “Perspective API.” https://perspectiveapi.com/",
    ], size=13, spacing=False)
    add_footer(s, 16)

    # ---- 16 Thank you ----
    s = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(s, BG)
    stripe = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(0.15))
    stripe.fill.solid()
    stripe.fill.fore_color.rgb = ACCENT
    stripe.line.fill.background()
    box = s.shapes.add_textbox(Inches(1), Inches(2.2), Inches(11.3), Inches(3.5))
    tf = box.text_frame
    tf.word_wrap = True
    thanks = [
        ("Thank You", 44, True, WHITE),
        ("Questions?", 22, False, LIGHT),
        ("", 12, False, MUTED),
        ("Demo Super Admin:  ananya@kerala.app  /  password123", 16, False, WHITE),
        ("Project: Instagram Pro", 14, False, MUTED),
        ("https://github.com/anandhx/instagram-pro", 14, False, MUTED),
    ]
    for i, (text, size, bold, color) in enumerate(thanks):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        run = p.add_run()
        run.text = text
        set_run(run, size, bold, color)
        p.alignment = PP_ALIGN.CENTER
        p.space_after = Pt(8)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    prs.save(OUT)
    print(f"Saved: {OUT}")
    print(f"Slides: {len(prs.slides)}")


if __name__ == "__main__":
    build()
