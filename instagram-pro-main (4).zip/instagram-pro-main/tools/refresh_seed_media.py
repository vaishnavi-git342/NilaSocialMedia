"""Copy generated seed images into static/uploads and refresh DB media + activity."""
from __future__ import annotations

import shutil
import sys
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

ASSETS = ROOT / "seed_assets"
UPLOADS = ROOT / "app" / "static" / "uploads"
BRAND = ROOT / "app" / "static" / "images"

PROFILE_MAP = {
    "ananya_kochi": "seed_profile_ananya.png",
    "arjun_alleppey": "seed_profile_arjun.png",
    "meera_munnar": "seed_profile_meera.png",
    "rahul_tvm": "seed_profile_rahul.png",
    "priya_wayanad": "seed_profile_priya.png",
    "vishnu_calicut": "seed_profile_vishnu.png",
    "lekha_thrissur": "seed_profile_lekha.png",
    "nithin_varkala": "seed_profile_nithin.png",
}

POST_IMAGES = [
    "seed_post_kochi.png",
    "seed_post_backwaters.png",
    "seed_post_munnar.png",
    "seed_post_dosa.png",
    "seed_post_waterfall.png",
    "seed_post_biryani.png",
    "seed_post_pooram.png",
    "seed_post_varkala.png",
    "seed_post_sadya.png",
    "seed_post_chai.png",
    "seed_post_munnar.png",
    "seed_post_waterfall.png",
    "seed_post_varkala.png",
    "seed_post_biryani.png",
    "seed_post_backwaters.png",
]

REEL_MEDIA = [
    ("arjun_alleppey", "seed_reel_houseboat.mp4", "seed_reel_houseboat.png", "Kerala Rain Ambience"),
    ("meera_munnar", "seed_reel_tea.mp4", "seed_reel_tea.png", "Mountain Breeze"),
    ("nithin_varkala", "seed_reel_beach.mp4", "seed_reel_beach.png", "Arabian Sea Waves"),
    ("lekha_thrissur", "seed_reel_pooram.mp4", "seed_post_pooram.png", "Chenda Melam Vibes"),
    ("ananya_kochi", "seed_reel_dosa.mp4", "seed_post_dosa.png", "Malabar Beats"),
]

STORY_IMAGES = [
    ("ananya_kochi", "seed_post_kochi.png", "Kochi morning"),
    ("arjun_alleppey", "seed_post_backwaters.png", "Backwater breeze"),
    ("meera_munnar", "seed_post_munnar.png", "Tea mist"),
    ("nithin_varkala", "seed_post_varkala.png", "Cliff light"),
    ("priya_wayanad", "seed_post_waterfall.png", "Forest trail"),
    ("vishnu_calicut", "seed_post_biryani.png", "Lunch special"),
]


def _copy(src_name: str, dest: Path) -> str:
    src = ASSETS / src_name
    if not src.exists():
        raise FileNotFoundError(f"Missing asset: {src}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
    rel = dest.relative_to(ROOT / "app" / "static").as_posix()
    return rel


def install_files() -> dict:
    paths = {}
    # Prefer Nila logos; fall back to older seed names
    for candidate, dest_name in (
        ("nila_icon.png", "nila_icon.png"),
        ("nila_wordmark.png", "nila_wordmark.png"),
        ("nila_icon.png", "ig_pro_icon.png"),
        ("nila_wordmark.png", "ig_pro_wordmark.png"),
        ("nila_icon.png", "instagram_pro_logo.png"),
        ("instagram_pro_logo.png", "instagram_pro_logo.png"),
    ):
        src = ASSETS / candidate
        if src.exists():
            paths[dest_name] = _copy(candidate, BRAND / dest_name)

    for user, fname in PROFILE_MAP.items():
        rel = _copy(fname, UPLOADS / "profiles" / fname)
        paths[f"profile:{user}"] = rel

    for fname in set(POST_IMAGES + [r[2] for r in REEL_MEDIA] + [s[1] for s in STORY_IMAGES]):
        if fname.startswith("seed_post") or fname.startswith("seed_reel"):
            folder = "reels" if "reel" in fname else "posts"
            if (ASSETS / fname).exists():
                _copy(fname, UPLOADS / folder / fname)
            if not fname.startswith("seed_reel") and (ASSETS / fname).exists():
                _copy(fname, UPLOADS / "stories" / fname)
                _copy(fname, UPLOADS / "reels" / fname)

    # Keep existing generated MP4s in uploads/reels (do not overwrite from assets)
    for _, video, thumb, _ in REEL_MEDIA:
        if (ASSETS / thumb).exists():
            _copy(thumb, UPLOADS / "reels" / thumb)
        # video files are created locally via ffmpeg; just ensure path exists
        if not (UPLOADS / "reels" / video).exists():
            # PNG stills are enough after git clone; MP4s are optional (ffmpeg)
            pass

    return paths


def refresh_db():
    """Demo seed is off. People sign up and post their own photos."""
    print("Demo accounts are not created. Sign up in the app.")
    return
    from app import create_app
    from app.extensions import db
    from app.models.user import User
    from app.models.profile import Profile
    from app.models.post import Post, PostImage
    from app.models.story import Story
    from app.models.reel import Reel
    from app.models.like import Like
    from app.models.comment import Comment
    from app.models.message import Conversation, Message
    from app.models.notification import Notification
    from app.models.follow import Follow
    from app.services.seed_data import SAMPLE_USERS, SAMPLE_POSTS, SAMPLE_COMMENTS, run_seed

    app = create_app()
    with app.app_context():
        # Ensure base seed accounts exist
        if not User.query.filter_by(username="ananya_kochi").first():
            run_seed(force=False)

        user_map = {}
        for u in SAMPLE_USERS:
            user = User.query.filter_by(username=u["username"]).first()
            if not user:
                continue
            user_map[u["username"]] = user
            profile = user.profile
            if not profile:
                profile = Profile(user_id=user.id, full_name=u["full_name"], bio=u["bio"])
                db.session.add(profile)
            photo = f"uploads/profiles/{PROFILE_MAP[u['username']]}"
            profile.profile_photo = photo
            profile.full_name = u["full_name"]
            profile.bio = u["bio"]
        db.session.commit()

        # Refresh post images for sample users' posts (by caption match / order)
        sample_usernames = set(PROFILE_MAP.keys())
        posts = (
            Post.query.join(User)
            .filter(User.username.in_(sample_usernames))
            .order_by(Post.created_at.desc())
            .all()
        )
        for idx, post in enumerate(posts):
            img_name = POST_IMAGES[idx % len(POST_IMAGES)]
            rel = f"uploads/posts/{img_name}"
            if post.images:
                post.images[0].filename = rel
            else:
                db.session.add(PostImage(post_id=post.id, filename=rel, position=0, is_video=False))
        db.session.commit()

        # If few posts, create missing SAMPLE_POSTS
        if len(posts) < len(SAMPLE_POSTS):
            existing_caps = {p.caption for p in posts}
            for idx, p in enumerate(SAMPLE_POSTS):
                if p["caption"] in existing_caps:
                    continue
                user = user_map.get(p["user"])
                if not user:
                    continue
                img_name = POST_IMAGES[idx % len(POST_IMAGES)]
                post = Post(
                    user_id=user.id,
                    caption=p["caption"],
                    location=p["location"],
                    created_at=datetime.utcnow() - timedelta(hours=idx * 2 + 1),
                )
                db.session.add(post)
                db.session.flush()
                db.session.add(
                    PostImage(post_id=post.id, filename=f"uploads/posts/{img_name}", position=0)
                )
                # activity
                for uname, other in user_map.items():
                    if uname != p["user"] and hash(uname + p["caption"]) % 2 == 0:
                        if not Like.query.filter_by(user_id=other.id, post_id=post.id).first():
                            db.session.add(Like(user_id=other.id, post_id=post.id))
                commenter = list(user_map.values())[(idx + 1) % len(user_map)]
                db.session.add(
                    Comment(
                        user_id=commenter.id,
                        post_id=post.id,
                        body=SAMPLE_COMMENTS[idx % len(SAMPLE_COMMENTS)],
                    )
                )
            db.session.commit()

        # Stories: replace sample users' stories with local images
        for uname in sample_usernames:
            user = user_map.get(uname)
            if not user:
                continue
            Story.query.filter_by(user_id=user.id).delete()
        for uname, fname, caption in STORY_IMAGES:
            user = user_map.get(uname)
            if not user:
                continue
            db.session.add(
                Story(
                    user_id=user.id,
                    filename=f"uploads/stories/{fname}",
                    is_video=False,
                    caption=caption,
                    created_at=datetime.utcnow() - timedelta(hours=1),
                )
            )
        db.session.commit()

        # Reels: replace sample users' reels with local media
        for uname in sample_usernames:
            user = user_map.get(uname)
            if user:
                for old in Reel.query.filter_by(user_id=user.id).all():
                    Like.query.filter_by(reel_id=old.id).delete()
                    Comment.query.filter_by(reel_id=old.id).delete()
                    db.session.delete(old)
        db.session.commit()
        for uname, video, thumb, audio in REEL_MEDIA:
            user = user_map.get(uname)
            if not user:
                continue
            # Prefer MP4 when installer/ffmpeg created it; else PNG still (works after git clone)
            media_name = video if (UPLOADS / "reels" / video).exists() else thumb
            thumb_name = thumb if (UPLOADS / "reels" / thumb).exists() else media_name
            reel = Reel(
                user_id=user.id,
                filename=f"uploads/reels/{media_name}",
                thumbnail=f"uploads/reels/{thumb_name}",
                caption={
                    "arjun_alleppey": "Houseboat glide through Alappuzha canals #backwaters #kerala #reels",
                    "meera_munnar": "Tea estate walk in the mist #munnar #kerala #nature",
                    "nithin_varkala": "Varkala cliff sunset reel #varkala #beach #kerala",
                    "lekha_thrissur": "Festival drums and colours #thrissur #pooram #kerala",
                    "ananya_kochi": "Kochi street food in 15 seconds #kochi #foodie #kerala",
                }.get(uname, "#kerala #reels"),
                audio_name=audio,
                views=1200 + hash(media_name) % 8000,
            )
            db.session.add(reel)
            db.session.flush()
            for other_name, other in user_map.items():
                if other_name == uname:
                    continue
                if hash(other_name + media_name) % 3 == 0:
                    continue
                if not Like.query.filter_by(user_id=other.id, reel_id=reel.id).first():
                    db.session.add(Like(user_id=other.id, reel_id=reel.id))
            commenter = list(user_map.values())[hash(media_name) % len(user_map)]
            if commenter.id != user.id:
                db.session.add(
                    Comment(user_id=commenter.id, reel_id=reel.id, body="This reel is fire!")
                )
            db.session.commit()

        # Ensure follows among sample users
        names = list(user_map.keys())
        for a in names:
            for b in names:
                if a == b:
                    continue
                if not Follow.query.filter_by(
                    follower_id=user_map[a].id, followed_id=user_map[b].id
                ).first():
                    db.session.add(
                        Follow(
                            follower_id=user_map[a].id,
                            followed_id=user_map[b].id,
                            accepted=True,
                        )
                    )
        db.session.commit()

        # Richer DM threads
        pairs = [
            ("ananya_kochi", "arjun_alleppey", [
                ("ananya_kochi", "Eda, backwaters trip this weekend?"),
                ("arjun_alleppey", "Yes! Houseboat from Alappuzha. Pack light."),
                ("ananya_kochi", "Perfect. I'll bring homemade chips."),
                ("arjun_alleppey", "Also send the Fort Kochi photos from last time."),
            ]),
            ("meera_munnar", "priya_wayanad", [
                ("meera_munnar", "Wayanad trails were unreal yesterday."),
                ("priya_wayanad", "Come again for the waterfall trek!"),
                ("meera_munnar", "Deal. Bring the thermos."),
            ]),
            ("rahul_tvm", "nithin_varkala", [
                ("rahul_tvm", "Cliff yoga at sunrise?"),
                ("nithin_varkala", "6:30 sharp. Bring water."),
            ]),
            ("vishnu_calicut", "lekha_thrissur", [
                ("vishnu_calicut", "Pooram photos are stunning."),
                ("lekha_thrissur", "Thanks! Next year you're coming."),
            ]),
        ]
        for u1n, u2n, msgs in pairs:
            a, b = user_map.get(u1n), user_map.get(u2n)
            if not a or not b:
                continue
            uid1, uid2 = sorted([a.id, b.id])
            conv = Conversation.query.filter_by(user_id=uid1, partner_id=uid2).first()
            if not conv:
                conv = Conversation(user_id=uid1, partner_id=uid2)
                db.session.add(conv)
                db.session.flush()
            if not Message.query.filter_by(conversation_id=conv.id).first():
                for i, (sender_name, body) in enumerate(msgs):
                    sender = user_map[sender_name]
                    db.session.add(
                        Message(
                            conversation_id=conv.id,
                            sender_id=sender.id,
                            body=body,
                            created_at=datetime.utcnow() - timedelta(minutes=30 - i),
                        )
                    )
        db.session.commit()

        # A few notifications for ananya
        ananya = user_map.get("ananya_kochi")
        if ananya:
            actors = [user_map[n] for n in ("arjun_alleppey", "meera_munnar", "rahul_tvm") if n in user_map]
            for actor in actors:
                exists = Notification.query.filter_by(
                    user_id=ananya.id, actor_id=actor.id, type="like"
                ).first()
                if not exists:
                    db.session.add(
                        Notification(
                            user_id=ananya.id,
                            actor_id=actor.id,
                            type="like",
                            text=f"{actor.username} liked your post",
                        )
                    )
            db.session.commit()

        print("Seed media installed and database refreshed.")
        print("Demo login: ananya@kerala.app / password123")


if __name__ == "__main__":
    print("Installing local seed images...")
    paths = install_files()
    print(f"Copied logo + mapped profiles ({len(paths)} entries).")
    refresh_db()
