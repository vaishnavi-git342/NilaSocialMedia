"""
Nila Social — local installer / repair / database + seed media tools.

Works on any PC after git clone: creates venv, installs requirements (incl. AI),
copies seed_assets into app/static/uploads (relative paths — not machine-specific),
creates SQLite DB with demo accounts so the feed is never empty.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VENV = ROOT / ".venv"
PY = VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
PIP = VENV / ("Scripts/pip.exe" if os.name == "nt" else "bin/pip")
DB = ROOT / "instance" / "instagram_clone.db"
REQ = ROOT / "requirements.txt"
REQ_CORE = ROOT / "requirements-core.txt"
WHEELS = ROOT / "wheels"
MARKER = ROOT / ".nila_social_installed"
SEED_ASSETS = ROOT / "seed_assets"
UPLOADS = ROOT / "app" / "static" / "uploads"
IMAGES = ROOT / "app" / "static" / "images"

APP_NAME = "Nila Social"
APP_URL = "http://127.0.0.1:5000"


def banner():
    print()
    print("=" * 56)
    print(f"   {APP_NAME}  ·  Local Installer & Tools")
    print("=" * 56)
    print(f"   Folder: {ROOT}")
    print(f"   DB:     {DB}")
    print(f"   Venv:   {VENV}")
    print("=" * 56)


def run(cmd, **kwargs):
    print(">", " ".join(str(c) for c in cmd))
    return subprocess.call(cmd, cwd=str(ROOT), **kwargs)


def ensure_dirs():
    (ROOT / "instance").mkdir(exist_ok=True)
    for sub in ("posts", "profiles", "stories", "reels", "messages"):
        (UPLOADS / sub).mkdir(parents=True, exist_ok=True)
    IMAGES.mkdir(parents=True, exist_ok=True)
    WHEELS.mkdir(exist_ok=True)


def clean_junk():
    removed = []
    for p in ROOT.rglob("__pycache__"):
        if p.is_dir():
            shutil.rmtree(p, ignore_errors=True)
            try:
                removed.append(str(p.relative_to(ROOT)))
            except ValueError:
                pass
    tmp = UPLOADS / "tmp_ai"
    if tmp.exists():
        shutil.rmtree(tmp, ignore_errors=True)
        removed.append("app/static/uploads/tmp_ai")
    for p in ROOT.rglob("*.pyc"):
        try:
            p.unlink()
            removed.append(str(p.relative_to(ROOT)))
        except OSError:
            pass
    print(f"Cleaned {len(removed)} cache items.")


def create_venv():
    if PY.exists():
        print("Virtual environment already exists.")
        return 0
    print("Creating virtual environment (.venv)...")
    return run([sys.executable, "-m", "venv", str(VENV)])


def install_deps(offline_preferred: bool = True):
    if not PIP.exists():
        print("ERROR: venv pip not found. Run install first.")
        return 1
    env = os.environ.copy()
    env.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
    env.setdefault("TRANSFORMERS_OFFLINE", "0")

    run([str(PY), "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"], env=env)

    wheel_files = list(WHEELS.glob("*.whl")) if WHEELS.exists() else []
    if offline_preferred and wheel_files:
        print(f"Installing from local wheels/ ({len(wheel_files)} files) — offline mode...")
        code = run(
            [str(PIP), "install", "--no-index", f"--find-links={WHEELS}", "-r", str(REQ)],
            env=env,
        )
        if code == 0:
            return 0

    print("Installing full requirements (Flask + Pillow + OpenCV + torch/transformers AI)...")
    print("  First AI install needs internet and can take several minutes.")
    code = run([str(PIP), "install", "-r", str(REQ)], env=env)
    if code != 0:
        print("Full AI install failed — installing core (app still runs, rule-based AI fallback)...")
        if REQ_CORE.exists():
            code = run([str(PIP), "install", "-r", str(REQ_CORE)], env=env)
        else:
            code = run(
                [
                    str(PIP), "install",
                    "Flask==3.0.3", "Flask-SQLAlchemy==3.1.1", "Flask-Migrate==4.0.7",
                    "Flask-Login==0.6.3", "Flask-WTF==1.2.1", "Flask-Mail==0.10.0",
                    "WTForms==3.1.2", "email-validator==2.2.0", "Pillow==10.4.0",
                    "python-dotenv==1.0.1", "SQLAlchemy==2.0.31", "opencv-python-headless>=4.8.0",
                ],
                env=env,
            )
        print("App will run; CLIP/BLIP load when torch is available.")
    return code


def download_wheels():
    if not PIP.exists():
        create_venv()
    print("Downloading wheels into wheels/ for offline reuse...")
    return run([str(PIP), "download", "-r", str(REQ), "-d", str(WHEELS)])


def install_seed_media() -> int:
    """
    Copy committed seed_assets/ into app/static/uploads/ using RELATIVE paths.

    Why feeds were empty on a new PC:
      - uploads/* and instance/*.db are gitignored
      - DB rows pointed at uploads/... files that did not exist after git clone
    This step fixes that on every install/repair/reset.
    """
    ensure_dirs()
    if not SEED_ASSETS.exists():
        print(f"WARNING: {SEED_ASSETS} missing — clone may be incomplete.")
        return 1

    copied = 0

    # Brand logos
    for src_name, dest_name in (
        ("nila_icon.png", "nila_icon.png"),
        ("nila_wordmark.png", "nila_wordmark.png"),
        ("nila_icon.png", "ig_pro_icon.png"),
        ("nila_wordmark.png", "ig_pro_wordmark.png"),
        ("nila_icon.png", "instagram_pro_logo.png"),
    ):
        src = SEED_ASSETS / src_name
        if not src.exists():
            # fall back to older names in seed_assets
            alt = SEED_ASSETS / ("instagram_pro_logo.png" if "icon" in dest_name or "logo" in dest_name else src_name)
            src = alt if alt.exists() else src
        if src.exists():
            shutil.copy2(src, IMAGES / dest_name)
            copied += 1

    mapping = {
        "profiles": list(SEED_ASSETS.glob("seed_profile_*.png")),
        "posts": list(SEED_ASSETS.glob("seed_post_*.png")),
        "stories": list(SEED_ASSETS.glob("seed_post_*.png")),
        "reels": list(SEED_ASSETS.glob("seed_reel_*.png")) + list(SEED_ASSETS.glob("seed_post_*.png")),
    }
    for folder, files in mapping.items():
        dest_dir = UPLOADS / folder
        dest_dir.mkdir(parents=True, exist_ok=True)
        for f in files:
            shutil.copy2(f, dest_dir / f.name)
            copied += 1

    # Optional: build short MP4 reels if ffmpeg is on PATH
    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg:
        print("ffmpeg found — generating short MP4 reels from seed images...")
        reel_pairs = [
            ("seed_reel_houseboat.png", "seed_reel_houseboat.mp4"),
            ("seed_reel_tea.png", "seed_reel_tea.mp4"),
            ("seed_reel_beach.png", "seed_reel_beach.mp4"),
            ("seed_post_pooram.png", "seed_reel_pooram.mp4"),
            ("seed_post_dosa.png", "seed_reel_dosa.mp4"),
        ]
        for png, mp4 in reel_pairs:
            src = UPLOADS / "reels" / png
            dst = UPLOADS / "reels" / mp4
            if not src.exists():
                continue
            if dst.exists() and dst.stat().st_size > 10_000:
                continue
            cmd = [
                ffmpeg, "-y", "-loop", "1", "-i", str(src),
                "-vf", "scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280",
                "-t", "4", "-c:v", "libx264", "-pix_fmt", "yuv420p",
                "-movflags", "+faststart", str(dst),
            ]
            subprocess.call(cmd, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if dst.exists():
                copied += 1
    else:
        print("ffmpeg not found — reels will use image stills (still playable in the app).")

    print(f"Seed media ready ({copied} files) under app/static/uploads/ (portable relative paths).")
    return 0


def refresh_database_media() -> int:
    """Update DB filenames to local uploads/* and enrich demo activity."""
    if not PY.exists():
        print("venv missing")
        return 1
    script = ROOT / "tools" / "refresh_seed_media.py"
    if script.exists():
        return run([str(PY), str(script)])
    return 0


def init_database(force_reset: bool = False):
    ensure_dirs()
    install_seed_media()
    if force_reset and DB.exists():
        DB.unlink()
        print("Deleted existing database.")

    env = os.environ.copy()
    env["FLASK_ENV"] = "development"
    # create_app() creates tables + run_seed() when empty
    code = run(
        [
            str(PY),
            "-c",
            (
                "from app import create_app; "
                "from app.models.user import User; "
                "from app.models.post import Post; "
                "from app.models.reel import Reel; "
                "app=create_app(); "
                "ctx=app.app_context(); ctx.push(); "
                "print('Users:', User.query.count()); "
                "print('Posts:', Post.query.count()); "
                "print('Reels:', Reel.query.count()); "
                "print('Ready. Sign up to create an account.')"
            ),
        ],
        env=env,
    )
    if code != 0:
        return code
    # Always refresh media paths / activity so images resolve after git clone
    return refresh_database_media()


def reset_database():
    print("This will DELETE all posts, users, messages and reseed Kerala demo data.")
    ans = input("Type YES to reset: ").strip()
    if ans != "YES":
        print("Cancelled.")
        return 0
    return init_database(force_reset=True)


def start_server(open_browser: bool = True):
    if not PY.exists():
        print("Not installed yet. Running installer first...")
        if one_click_install() != 0:
            return 1
    ensure_dirs()
    # Ensure media exists even if user only pulled git and skipped full install
    if not any((UPLOADS / "posts").glob("seed_post_*.png")):
        print("Seed images missing — installing media...")
        install_seed_media()
        refresh_database_media()

    env = os.environ.copy()
    env["FLASK_ENV"] = "development"
    env["HF_HUB_DISABLE_TELEMETRY"] = "1"
    hf = Path.home() / ".cache" / "huggingface" / "hub"
    if hf.exists():
        env["HF_HUB_OFFLINE"] = "1"
        env["TRANSFORMERS_OFFLINE"] = "1"
        print("Hugging Face cache found — AI models will load offline.")
    else:
        print("No HF model cache yet — AI uses OpenCV/EXIF + rule fallbacks until CLIP downloads.")

    print(f"\nStarting {APP_NAME} at {APP_URL}")
    print("Sign up to create your account.")
    print("Press Ctrl+C to stop.\n")
    if open_browser:
        try:
            webbrowser.open(APP_URL)
        except Exception:
            pass
    return subprocess.call([str(PY), str(ROOT / "run.py")], cwd=str(ROOT), env=env)


def repair():
    print("Repair: clean + reinstall deps + seed media + verify DB...")
    clean_junk()
    if not PY.exists():
        create_venv()
    code = install_deps(offline_preferred=True)
    if code != 0:
        print("WARNING: dependency install had errors; continuing.")
    return init_database(force_reset=False)


def one_click_install():
    banner()
    print("\n[1/6] Preparing folders...")
    ensure_dirs()
    print("[2/6] Cleaning junk files...")
    clean_junk()
    print("[3/6] Creating virtual environment...")
    if create_venv() != 0:
        return 1
    print("[4/6] Installing Python packages (core + AI)...")
    if install_deps(offline_preferred=True) != 0:
        print("WARNING: some packages failed; continuing with whatever installed.")
    print("[5/6] Installing seed photos/logos into uploads (fixes empty feed on new PCs)...")
    install_seed_media()
    print("[6/6] Creating / verifying local database + demo accounts...")
    if init_database(force_reset=False) != 0:
        return 1
    MARKER.write_text(f"{APP_NAME} installed\n", encoding="utf-8")
    print(f"\n✓ {APP_NAME} installed successfully!")
    print("  Run:  NilaSocial.bat   (or START.bat)")
    print("  Login: ananya@kerala.app / password123")
    print("  Images use relative paths under app/static/uploads/ — works on any PC.")
    print("  Fully local SQLite — no internet required to browse after setup.")
    return 0


def menu():
    while True:
        banner()
        print(f"""
  1) One-click Install (venv + AI deps + seed media + DB)
  2) Start {APP_NAME}
  3) Reset Database (wipe + reseed + media)
  4) Repair / Bug-fix
  5) Clean junk files only
  6) Download wheels for offline install
  7) Re-copy seed media only (fix broken images)
  8) Open app in browser
  0) Exit
""")
        choice = input("Select option: ").strip()
        if choice == "1":
            one_click_install()
        elif choice == "2":
            start_server(True)
        elif choice == "3":
            reset_database()
        elif choice == "4":
            repair()
        elif choice == "5":
            clean_junk()
        elif choice == "6":
            if not PY.exists():
                create_venv()
            download_wheels()
        elif choice == "7":
            install_seed_media()
            refresh_database_media()
        elif choice == "8":
            webbrowser.open(APP_URL)
        elif choice == "0":
            break
        else:
            print("Invalid option.")
        input("\nPress Enter to continue...")


def main(argv=None):
    argv = list(argv or sys.argv[1:])
    if not argv:
        menu()
        return 0
    cmd = argv[0].lower()
    if cmd in ("install", "setup"):
        return one_click_install()
    if cmd in ("start", "run"):
        return start_server(True)
    if cmd == "reset-db":
        if "--yes" in argv:
            return init_database(force_reset=True)
        return reset_database()
    if cmd == "repair":
        return repair()
    if cmd == "clean":
        clean_junk()
        return 0
    if cmd == "wheels":
        return download_wheels()
    if cmd in ("seed-media", "media"):
        code = install_seed_media()
        if code == 0 and PY.exists():
            refresh_database_media()
        return code
    print("Usage: python tools/installer.py [install|start|reset-db|repair|clean|wheels|seed-media]")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
