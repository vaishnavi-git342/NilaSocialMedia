@echo off
title Nila Social
cd /d "%~dp0"

:menu
cls
echo.
echo  ============================================
echo     Nila Social  -  Local Control Panel
echo  ============================================
echo.
echo    1. Start App (http://127.0.0.1:5000)
echo    2. One-Click Install / Setup
echo    3. Reset Database (demo data + media)
echo    4. Repair / Fix bugs
echo    5. Clean junk files
echo    6. Download offline wheels
echo    7. Re-copy seed media (fix empty images)
echo    8. Open in browser
echo    0. Exit
echo.
set /p choice=Select: 

if "%choice%"=="1" goto start
if "%choice%"=="2" goto install
if "%choice%"=="3" goto reset
if "%choice%"=="4" goto repair
if "%choice%"=="5" goto clean
if "%choice%"=="6" goto wheels
if "%choice%"=="7" goto media
if "%choice%"=="8" goto browser
if "%choice%"=="0" exit /b 0
goto menu

:start
python tools\installer.py start
pause
goto menu

:install
python tools\installer.py install
pause
goto menu

:reset
python tools\installer.py reset-db
pause
goto menu

:repair
python tools\installer.py repair
pause
goto menu

:clean
python tools\installer.py clean
pause
goto menu

:wheels
python tools\installer.py wheels
pause
goto menu

:media
python tools\installer.py seed-media
pause
goto menu

:browser
start http://127.0.0.1:5000
goto menu
