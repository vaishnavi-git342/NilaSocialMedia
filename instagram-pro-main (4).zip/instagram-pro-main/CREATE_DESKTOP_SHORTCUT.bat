@echo off
REM Create a Desktop shortcut to Instagram Pro control panel
set TARGET=%~dp0InstagramPro.bat
set SHORTCUT=%USERPROFILE%\Desktop\Instagram Pro.lnk
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%SHORTCUT%'); $s.TargetPath = '%TARGET%'; $s.WorkingDirectory = '%~dp0'; $s.Description = 'Instagram Pro Local'; $s.Save()"
echo Desktop shortcut created: %SHORTCUT%
pause
